'use strict';
const SUPABASE_URL  = 'https://vrtjopgjwlzogicmtade.supabase.co';
const SUPABASE_ANON = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZydGpvcGdqd2x6b2dpY210YWRlIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzc2NTA2ODMsImV4cCI6MjA5MzIyNjY4M30.TCDk_o8a3fPo0LxXFRncT51E6E5SJwvVOQemJthkI_k';
const REST = SUPABASE_URL + '/rest/v1';
const HDR  = {'apikey':SUPABASE_ANON,'Authorization':'Bearer '+SUPABASE_ANON,'Content-Type':'application/json'};

const FUNCTIONS_URL = SUPABASE_URL + '/functions/v1';
async function callFn(name, payload){
  try{
    const r = await fetch(`${FUNCTIONS_URL}/${name}`, {method:'POST', headers:HDR, body:JSON.stringify(payload||{})});
    return await r.json().catch(()=>({success:false,error:'bad_response'}));
  }catch(e){ return {success:false,error:'network_error'}; }
}

let selectedPlan={}, selectedMethod='bkash', pendingTxnId=null;
let settings={bkash_number:'01XXXXXXXXX',nagad_number:'01XXXXXXXXX',rocket_number:'01XXXXXXXXX',bank_account:'Contact support'};
let dbPlans=[];

function sGet(k){return new Promise(r=>{if(typeof chrome!=='undefined'&&chrome.storage)chrome.storage.local.get(k,r);else r({});})}
function sSet(o){return new Promise(r=>{if(typeof chrome!=='undefined'&&chrome.storage)chrome.storage.local.set(o,r);else r();})}

async function fetchSettings(){
  try{
    const r=await fetch(`${REST}/settings?select=key,value`,{headers:HDR});
    const rows=await r.json();
    if(Array.isArray(rows))rows.forEach(row=>{if(row.key&&row.value)settings[row.key]=row.value;});
    const r2=await fetch(`${REST}/plans?is_active=eq.true&order=sort_order&select=*`,{headers:HDR});
    dbPlans=await r2.json();
    if(Array.isArray(dbPlans)){
      // Plan overrides: force these values regardless of DB state
      const OV={
        trial:    {credits:300},
        basic:    {credits:10000,price:1350,name:'Basic',     duration_days:30,badge:'',        save_text:''},
        pro:      {credits:20000,price:2250,name:'Premium',   duration_days:30,badge:'popular', save_text:'Save 20%'},
        lifetime: {credits:50000,price:4500,name:'Pro Hunter',duration_days:30,badge:'best',    save_text:'Save 50%'}
      };
      dbPlans.forEach(p=>{
        if(OV[p.slug])Object.assign(p,OV[p.slug]);
        const c=document.getElementById('card-'+p.slug);
        if(c){c.dataset.planId=p.id;c.dataset.price=p.price;c.dataset.credits=p.credits;}
        if(p.slug==='trial'){
          const tc=document.getElementById('card-trial');
          if(tc){tc.dataset.planId=p.id;tc.dataset.credits=p.credits;
            const td=document.getElementById('trial-desc');
            if(td)td.textContent=`${Number(p.credits).toLocaleString()} credits · ${p.duration_days||3} days · Activates instantly`;}
        }
        const pp=document.querySelector(`#card-${p.slug} .pc-price`);
        if(pp)pp.textContent='৳'+Number(p.price).toLocaleString();
        const pc=document.querySelector(`#card-${p.slug} .pc-credits`);
        if(pc&&p.slug!=='trial')pc.textContent=Number(p.credits).toLocaleString();
      });
    }
    updatePaymentDisplay();
  }catch(e){}
}

function selectPlan(card,slug,name,price,credits){
  document.querySelectorAll('.trial-card,.plan-card').forEach(c=>c.classList.remove('selected'));
  card.classList.add('selected');
  const finalPrice=parseInt(card.dataset.price)||price;
  const finalCredits=parseInt(card.dataset.credits)||credits;
  const planId=card.dataset.planId||slug;
  selectedPlan={id:planId,slug,name,price:finalPrice,credits:finalCredits};
  document.getElementById('ps-name').textContent=name;
  document.getElementById('ps-credits').textContent=Number(finalCredits).toLocaleString()+' credits';
  document.getElementById('ps-price').textContent=finalPrice===0?'FREE':'৳'+Number(finalPrice).toLocaleString();
  document.getElementById('plan-summary').classList.add('visible');
  const btn=document.getElementById('btn-proceed');
  btn.style.display='flex';
  document.getElementById('btn-proceed-txt').textContent=finalPrice===0?'🎁 Start Free Trial →':'Continue to Payment →';
}

function proceedToPayment(){
  if(!selectedPlan.slug)return;
  if(selectedPlan.price===0){activateFreeTrial();return;}
  document.getElementById('pay-plan-name').textContent=selectedPlan.name+' Plan';
  document.getElementById('pay-plan-credits').textContent=Number(selectedPlan.credits).toLocaleString()+' credits';
  document.getElementById('pay-plan-price').textContent='৳'+Number(selectedPlan.price).toLocaleString();
  document.getElementById('pay-amount').textContent='৳'+Number(selectedPlan.price).toLocaleString();
  document.getElementById('step-amount').textContent='৳'+Number(selectedPlan.price).toLocaleString();
  updatePaymentDisplay();
  showView('view-payment');
}

async function activateFreeTrial(){
  const btn=document.getElementById('btn-proceed');
  const name=(document.getElementById('inp-name')?.value||'').trim();
  const phone=(document.getElementById('inp-phone')?.value||'').trim();
  if(!name||!phone||phone.length<10){
    alert('Please enter your name and WhatsApp number to start the trial.');
    return;
  }
  btn.disabled=true;btn.innerHTML='<span class="spin"></span> Setting up…';
  try{
    const res=await callFn('create-trial',{name,phone});
    if(!res||res.success!==true){
      const msg=res?.error==='trial_already_used'?'This number has already used a free trial.'
        :res?.error==='invalid_phone'?'Please enter a valid WhatsApp number.'
        :'Trial setup failed. Please try again.';
      btn.disabled=false;btn.innerHTML='🎁 Start Free Trial →';
      alert(msg);
      return;
    }
    const key=res.license_key;
    const lic={status:'active',plan_name:res.plan_name||'3-Day Trial',plan_slug:'trial',
      credits_remaining:res.credits_remaining,credits_total:res.credits_remaining,
      credits_used:0,activated_at:new Date().toISOString(),expires_at:res.expires_at};
    await sSet({licenseKey:key,licenseData:lic,creditsRemaining:res.credits_remaining});
    document.getElementById('success-key').textContent=key;
    document.getElementById('success-credits').textContent=Number(res.credits_remaining).toLocaleString();
    document.getElementById('success-plan').textContent='Trial';
    showView('view-success');
  }catch(e){
    btn.disabled=false;btn.innerHTML='🎁 Start Free Trial →';
    alert('Trial activation failed: '+e.message);
  }
}

function selectMethod(tab){
  document.querySelectorAll('.method-tab').forEach(t=>t.classList.remove('active'));
  tab.classList.add('active');selectedMethod=tab.dataset.method;updatePaymentDisplay();
}
function updatePaymentDisplay(){
  const nums={bkash:settings.bkash_number||'01XXXXXXXXX',nagad:settings.nagad_number||'01XXXXXXXXX',rocket:settings.rocket_number||'01XXXXXXXXX',bank:settings.bank_account||'Contact support'};
  const labels={bkash:'bKash',nagad:'Nagad',rocket:'Rocket',bank:'Bank Transfer'};
  const num=nums[selectedMethod]||'01XXXXXXXXX';
  const lbl=labels[selectedMethod]||'bKash';
  ['pay-number','step-number'].forEach(id=>{const el=document.getElementById(id);if(el)el.textContent=num;});
  const m=document.getElementById('step-method-txt');
  if(m)m.innerHTML=`Open <strong>${lbl}</strong> → Send Money`;
}
function copyNumber(){
  const n=document.getElementById('pay-number').textContent;
  navigator.clipboard.writeText(n).then(()=>{
    const b=document.querySelector('.copy-btn');
    b.textContent='Copied!';b.style.color='var(--green)';
    setTimeout(()=>{b.textContent='Copy';b.style.color='';},1500);
  });
}

async function submitPayment(){
  const name=document.getElementById('inp-name').value.trim();
  const phone=document.getElementById('inp-phone').value.trim();
  const txn=document.getElementById('inp-txn').value.trim().replace(/\s/g,'');
  hideStatus('pay-status');
  if(!phone||phone.length<10){flashField('inp-phone');showStatus('pay-status','error','Enter your phone number.');return;}
  if(!txn||txn.length<5){flashField('inp-txn');showStatus('pay-status','error','Enter your Transaction ID.');return;}
  const btn=document.getElementById('btn-submit');
  btn.disabled=true;document.getElementById('btn-submit-txt').innerHTML='<span class="spin"></span> Checking…';
  try{
    document.getElementById('btn-submit-txt').innerHTML='<span class="spin"></span> Submitting…';
    const res=await callFn('submit-payment',{customer_name:name||null,customer_phone:phone,
      plan_id:selectedPlan.id||null,payment_method:selectedMethod,transaction_id:txn});
    if(!res||res.success!==true){
      const msg=res?.error==='duplicate'?(res.status==='approved'?'TrxID already approved.':'TrxID already under review.')
        :res?.error==='invalid_plan'?'Invalid plan selected.'
        :res?.error==='missing_fields'?'Please fill all fields.'
        :'Submission failed. Try again.';
      showStatus('pay-status','error',msg);
      btn.disabled=false;document.getElementById('btn-submit-txt').textContent='Submit Payment';return;
    }
    pendingTxnId=txn;
    await sSet({pendingPaymentTxn:txn,pendingPlanName:selectedPlan.name});
    document.getElementById('poll-txn-display').textContent=txn;
    startPollTimer();showView('view-pending');
  }catch(e){showStatus('pay-status','error',e.message||'Connection error.');}
  btn.disabled=false;document.getElementById('btn-submit-txt').textContent='Submit Payment';
}

async function checkPaymentStatus(){
  const txn=pendingTxnId||(await sGet(['pendingPaymentTxn'])).pendingPaymentTxn;
  if(!txn){showStatus('poll-status','error','No pending payment found.');return;}
  const btn=document.getElementById('btn-check');
  btn.disabled=true;btn.innerHTML='<span class="spin"></span> Checking…';
  hideStatus('poll-status');
  try{
    const res=await callFn('check-payment',{transaction_id:txn});
    if(!res||res.success!==true){showStatus('poll-status','error','Could not check status.');btn.disabled=false;btn.innerHTML='🔄 Check Approval Status';return;}
    if(res.status==='approved'){
      const licKey=res.license_key;const u=res.license;
      if(licKey&&u){
        const lic={status:'active',plan_name:u.plan_name||'Pro',plan_slug:u.plan_slug||'pro',
          credits_remaining:u.credits_remaining||0,credits_total:u.credits_total||0,
          credits_used:u.credits_used||0,activated_at:u.activated_at,expires_at:u.expires_at};
        await sSet({licenseKey:licKey,licenseData:lic,creditsRemaining:lic.credits_remaining,pendingPaymentTxn:null});
        document.getElementById('success-key').textContent=licKey;
        document.getElementById('success-credits').textContent=Number(lic.credits_remaining).toLocaleString();
        document.getElementById('success-plan').textContent=lic.plan_name;
        clearInterval(_pollInterval);showView('view-success');return;
      }
      showStatus('poll-status','ok','✅ Approved! License activating… check again shortly.');
    }else if(res.status==='rejected'){
      await sSet({pendingPaymentTxn:null});pendingTxnId=null;
      showStatus('poll-status','error','❌ Rejected: '+(res.reason||'Contact support.'));
      setTimeout(()=>showView('view-pricing'),3000);
    }else{
      showStatus('poll-status','warn','⏳ Still pending. Admin will verify within 24 hours.');
    }
  }catch(e){showStatus('poll-status','error','Connection error: '+e.message);}
  btn.disabled=false;btn.innerHTML='🔄 Check Approval Status';
}

let _pollInterval;
function startPollTimer(){
  const t0=Date.now();clearInterval(_pollInterval);
  _pollInterval=setInterval(()=>{
    const s=Math.floor((Date.now()-t0)/1000);
    const el=document.getElementById('poll-timer');
    if(el)el.textContent=`Waiting… (${Math.floor(s/60)}m ${s%60}s elapsed)`;
  },1000);
}

async function activateLicense(){
  const key=(document.getElementById('inp-license').value||'').trim().toUpperCase().replace(/[^A-Z0-9-]/g,'');
  if(!key||key.length<8){flashField('inp-license');showStatus('lic-status','error','Enter a valid license key.');return;}
  const btn=document.getElementById('btn-activate');
  btn.disabled=true;document.getElementById('btn-activate-txt').innerHTML='<span class="spin"></span> Verifying…';
  hideStatus('lic-status');
  try{
    const res=await callFn('license-verify',{license_key:key});
    if(!res||res.success!==true){
      const map={license_key_not_found:'❌ License key not found.',account_suspended:'❌ License suspended. Contact support.',
        payment_pending:'⏳ Payment pending — credits added within 24h.',connection_failed:'Connection failed.',network_error:'Connection failed.'};
      const warn=res?.error==='payment_pending';
      showStatus('lic-status',warn?'warn':'error',map[res?.error]||'Verification failed.');
      btn.disabled=false;document.getElementById('btn-activate-txt').textContent='Activate Now →';return;
    }
    const l=res.license;
    const lic={status:l.status,plan_name:l.plan_name||l.plan_slug||'Active',plan_slug:l.plan_slug,
      credits_remaining:l.credits_remaining||0,credits_total:l.credits_total||0,credits_used:l.credits_used||0,
      activated_at:l.activated_at,expires_at:l.expires_at};
    await sSet({licenseKey:key,licenseData:lic,creditsRemaining:lic.credits_remaining});
    document.getElementById('success-key').textContent=key;
    document.getElementById('success-credits').textContent=Number(lic.credits_remaining).toLocaleString();
    document.getElementById('success-plan').textContent=lic.plan_name;
    showView('view-success');
  }catch(e){showStatus('lic-status','error','Connection error: '+e.message);}
  btn.disabled=false;document.getElementById('btn-activate-txt').textContent='Activate Now →';
}

function launchDashboard(){
  if(typeof chrome!=='undefined'&&chrome.runtime){
    chrome.runtime.sendMessage({action:'onboardingComplete'});
    // Redirect back to popup.html (the main dashboard)
    window.location.href = chrome.runtime.getURL('popup.html');
  }
}
function copyKey(){
  navigator.clipboard.writeText(document.getElementById('success-key').textContent).then(()=>{
    const b=document.querySelector('.key-copy');
    b.textContent='Copied!';b.style.background='var(--green)';b.style.color='#fff';
    setTimeout(()=>{b.textContent='Copy Key';b.style.background='';b.style.color='';},1800);
  });
}

const VIEWS=['view-pricing','view-payment','view-pending','view-activate','view-success'];
const PROG={'view-pricing':25,'view-payment':60,'view-pending':80,'view-activate':50,'view-success':100};
const STEPS={'view-pricing':'Step 1 of 3','view-payment':'Step 2 of 3','view-pending':'Step 3 of 3','view-activate':'Activation','view-success':'Done ✓'};
function showView(id){
  VIEWS.forEach(v=>{const el=document.getElementById(v);if(el){el.style.display='none';el.classList.remove('active');}});
  const t=document.getElementById(id);if(t){t.style.display='flex';t.classList.add('active');}
  document.getElementById('progress').style.width=(PROG[id]||50)+'%';
  document.getElementById('step-label').textContent=STEPS[id]||'';
  const f=document.getElementById('footer-note');if(f)f.style.display=id==='view-success'?'none':'';
}
function showStatus(id,type,msg){
  const el=document.getElementById(id);if(!el)return;
  el.className='status-box '+type+' visible';
  el.querySelector('.si').textContent={success:'✅',ok:'✅',error:'❌',warn:'⚠️',pending:'⏳',info:'ℹ️'}[type]||'ℹ️';
  el.querySelector('.sm').textContent=msg;
}
function hideStatus(id){const el=document.getElementById(id);if(el)el.className='status-box';}
function flashField(id){const el=document.getElementById(id);if(!el)return;el.classList.add('error');el.focus();setTimeout(()=>el.classList.remove('error'),1500);}

document.getElementById('inp-license')?.addEventListener('input',function(){
  let v=this.value.replace(/[^A-Z0-9a-z]/g,'').toUpperCase();
  v=v.startsWith('LHP')?'LHP-'+v.slice(3).replace(/(.{4})/g,'$1-').slice(0,14):v.replace(/(.{4})/g,'$1-').slice(0,19);
  this.value=v.replace(/-+$/,'');
});

(async()=>{
  const d=await sGet(['licenseKey','licenseData','creditsRemaining','pendingPaymentTxn']);
  if(d.licenseKey&&d.licenseData?.status==='active'){
    document.getElementById('success-key').textContent=d.licenseKey;
    document.getElementById('success-credits').textContent=Number(d.creditsRemaining||0).toLocaleString();
    document.getElementById('success-plan').textContent=d.licenseData.plan_name||'Active';
    showView('view-success');return;
  }
  if(d.pendingPaymentTxn){
    pendingTxnId=d.pendingPaymentTxn;
    document.getElementById('poll-txn-display').textContent=d.pendingPaymentTxn;
    startPollTimer();showView('view-pending');
    setTimeout(()=>checkPaymentStatus(),1500);
    await fetchSettings();return;
  }
  showView('view-pricing');
  await fetchSettings();
})();

// ── Event delegation for MV3 CSP compliance ──
document.addEventListener('click', function(e) {
  const el = e.target.closest('[data-action]');
  if (!el) return;
  e.preventDefault();
  const raw = el.getAttribute('data-action') || '';
  const match = raw.match(/^([\w.]+)\(([^)]*)\)$/);
  if (!match) {
    if (raw === "showView('view-pricing')") { showView('view-pricing'); return; }
    if (raw === "showView('view-activate')") { showView('view-activate'); return; }
    if (raw === "showView('view-payment')") { showView('view-payment'); return; }
    return;
  }
  const fnName = match[1];
  const argsRaw = match[2];
  let args = [];
  if (argsRaw.trim()) {
    args = argsRaw.split(',').map(a => {
      a = a.trim();
      if ((a.startsWith("'") && a.endsWith("'")) || (a.startsWith('"') && a.endsWith('"'))) return a.slice(1,-1);
      if (a === 'this') return el;
      const n = Number(a); return isNaN(n) ? a : n;
    });
  }
  const fn = window[fnName];
  if (typeof fn === 'function') fn(...args);
});

document.getElementById('inp-license')?.addEventListener('input', function() {
  let v = this.value.replace(/[^A-Z0-9a-z]/g,'').toUpperCase();
  v = v.startsWith('LHP') ? 'LHP-' + v.slice(3).replace(/(.{4})/g,'$1-').slice(0,14) : v.replace(/(.{4})/g,'$1-').slice(0,19);
  this.value = v.replace(/-+$/,'');
});
