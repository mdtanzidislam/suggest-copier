// ════════════════════════════════════════════════════════════════
// LEAD HUNTER PRO — Content Script v2.1 (Leadoutfy-engine port)
// Anti-Bot Human Emulation + Proven Google Maps Lead Scraper
// ════════════════════════════════════════════════════════════════
'use strict';

(function () {

  // ────────────────────────────────────────────────────────────
  // STATE
  // ────────────────────────────────────────────────────────────
  let scraping = false;
  let stopRequested = false;
  let collected = [];
  let panel = null;
  let humanBehavior = null;
  let antiBot = null;
  let smartScroll = null;

  // Stale-panel tracking (Leadoutfy v45)
  let _lastWebsiteSeen = '';
  let _sameWebsiteCount = 0;
  const MAX_SAME_WEBSITE = 4;

  const DASH = '\u2014';

  const COUNTRY_CODES = {
    'Bangladesh':'880','India':'91','Pakistan':'92','USA':'1','UK':'44',
    'UAE':'971','Canada':'1','Australia':'61','Germany':'49','Saudi Arabia':'966',
    'Turkey':'90','Indonesia':'62','Malaysia':'60','Nigeria':'234','Egypt':'20',
    'Philippines':'63','China':'86','Japan':'81','South Korea':'82','Brazil':'55',
    'Mexico':'52','France':'33','Italy':'39','Spain':'34','Netherlands':'31',
    'Sweden':'46','Norway':'47','Denmark':'45','Finland':'358','Poland':'48',
    'Switzerland':'41','Austria':'43','Belgium':'32','Portugal':'351','Greece':'30',
    'Israel':'972','Qatar':'974','Kuwait':'965','Bahrain':'973','Oman':'968',
    'Sri Lanka':'94','Nepal':'977','Thailand':'66','Vietnam':'84','Singapore':'65',
    'New Zealand':'64','South Africa':'27','Kenya':'254','Ghana':'233','Morocco':'212'
  };

  // ────────────────────────────────────────────────────────────
  // SAFE CHROME HELPERS
  // ────────────────────────────────────────────────────────────
  function isContextAlive() {
    try { return !!(chrome && chrome.runtime && chrome.runtime.id); } catch(e) { return false; }
  }
  function safeStorageGet(keys, cb) {
    if (!isContextAlive()) { cb({}); return; }
    try { chrome.storage.local.get(keys, cb); } catch(e) { cb({}); }
  }
  function safeStorageSet(obj, cb) {
    if (!isContextAlive()) { if (cb) cb(); return; }
    try { chrome.storage.local.set(obj, cb); } catch(e) { if (cb) cb(); }
  }
  function safeSendMessage(msg, cb) {
    if (!isContextAlive()) { if (cb) cb(null); return; }
    try {
      chrome.runtime.sendMessage(msg, (resp) => {
        try { void chrome.runtime.lastError; } catch(e) {}
        if (cb) cb(resp);
      });
    } catch(e) { if (cb) cb(null); }
  }
  function sleep(ms) {
    return new Promise(r => {
      if (ms <= 200) { setTimeout(r, ms); return; }
      const start = Date.now();
      function tick() {
        const elapsed = Date.now() - start;
        if (elapsed >= ms) { r(); return; }
        setTimeout(tick, Math.min(200, ms - elapsed));
      }
      setTimeout(tick, Math.min(200, ms));
    });
  }
  async function checkStop() {
    return new Promise(r => safeStorageGet(['stopRequested'], d => r(d.stopRequested === true)));
  }

  // ────────────────────────────────────────────────────────────
  // HUMAN BEHAVIOR EMULATION ENGINE
  // ────────────────────────────────────────────────────────────
  class HumanBehaviorEngine {
    constructor() {
      this.sessionStartTime = Date.now();
      this.actionCount = 0;
      this.scrollingPattern = this.generateScrollPattern();
      this.dailyLimits = { maxLeadsPerSession: 500, maxActionsPerMinute: 15, maxScrollsPerMinute: 25 };
      this.behaviorState = {
        isResting: false, restStartTime: null, currentBurst: 0, totalActions: 0,
        lastActionTime: 0, mousePosition: { x: 0, y: 0 }, suspiciousActivityScore: 0
      };
      this.initMouseTracking();
    }
    generateScrollPattern() {
      const patterns = ['smooth_continuous','burst_scroll','variable_speed','hesitant_scroll','reader_pattern'];
      return patterns[Math.floor(Math.random() * patterns.length)];
    }
    initMouseTracking() {
      try {
        document.addEventListener('mousemove', (e) => {
          this.behaviorState.mousePosition = { x: e.clientX, y: e.clientY };
        });
      } catch(e) {}
    }
    generateDelay(type = 'normal', minMs = 2000, maxMs = 6000) {
      const patterns = {
        normal:      () => this.gaussianRandom(minMs, maxMs, 0.3),
        thinking:    () => this.gaussianRandom(3000, 8000, 0.4),
        reading:     () => this.gaussianRandom(1500, 4000, 0.25),
        scrolling:   () => this.gaussianRandom(800, 2500, 0.35),
        clicking:    () => this.gaussianRandom(200, 800, 0.4),
        typing:      () => this.gaussianRandom(100, 300, 0.3),
        fatigue:     () => this.gaussianRandom(4000, 12000, 0.5),
        break:       () => this.gaussianRandom(15000, 45000, 0.3),
        micro_pause: () => this.gaussianRandom(50, 200, 0.2)
      };
      const delay = Math.max(100, patterns[type] ? patterns[type]() : patterns.normal());
      const sessionMinutes = (Date.now() - this.sessionStartTime) / 60000;
      const fatigueMultiplier = 1 + (sessionMinutes * 0.02);
      return Math.floor(delay * fatigueMultiplier);
    }
    gaussianRandom(min, max, skew = 0.3) {
      let u = 0, v = 0;
      while(u === 0) u = Math.random();
      while(v === 0) v = Math.random();
      const z = Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
      const value = min + (max - min) * (0.5 + skew * z);
      return Math.max(min, Math.min(max, value));
    }
    shouldTakeBreak() {
      const sessionMinutes = (Date.now() - this.sessionStartTime) / 60000;
      if (this.actionCount > 200) return { shouldBreak: true, reason: 'high_activity', duration: 30000 };
      if (sessionMinutes > 45) return { shouldBreak: true, reason: 'long_session', duration: 60000 };
      if (this.behaviorState.suspiciousActivityScore > 80) return { shouldBreak: true, reason: 'suspicious', duration: 45000 };
      if (Math.random() < 0.01) return { shouldBreak: true, reason: 'random', duration: this.generateDelay('break') };
      return { shouldBreak: false };
    }
    async takeBreak(duration = 30000, reason = 'fatigue') {
      this.behaviorState.isResting = true;
      this.behaviorState.restStartTime = Date.now();
      updateStatus(`\ud83d\ude34 Human break (${Math.round(duration/1000)}s)...`);
      await sleep(duration);
      this.behaviorState.isResting = false;
      this.behaviorState.restStartTime = null;
      this.actionCount = Math.max(0, this.actionCount - 50);
      this.behaviorState.suspiciousActivityScore *= 0.7;
    }
    recordAction(actionType, data = {}) {
      const now = Date.now();
      this.actionCount++;
      this.behaviorState.totalActions++;
      const timeSinceLastAction = now - (this.behaviorState.lastActionTime || now);
      if (timeSinceLastAction < 500) this.behaviorState.suspiciousActivityScore += 5;
      if (timeSinceLastAction > 30000) this.behaviorState.suspiciousActivityScore = Math.max(0, this.behaviorState.suspiciousActivityScore - 10);
      this.behaviorState.lastActionTime = now;
    }
    sleep(ms) { return sleep(ms); }
  }

  // ────────────────────────────────────────────────────────────
  // ANTI-BOT (kept for risk display)
  // ────────────────────────────────────────────────────────────
  class AntiBotSystem {
    constructor(humanBehavior) {
      this.human = humanBehavior;
      this.lastEvasion = 0;
    }
    assessRisk() {
      const risks = [];
      const sessionDuration = Date.now() - this.human.sessionStartTime;
      if (sessionDuration > 3600000) risks.push({ type: 'long_session', severity: 'medium' });
      if (this.human.actionCount > 300) risks.push({ type: 'high_frequency', severity: 'high' });
      return {
        totalRisk: risks.reduce((s, r) => s + (r.severity === 'high' ? 3 : r.severity === 'medium' ? 2 : 1), 0),
        risks
      };
    }
    async executeEvasion(riskAssessment) {
      if (riskAssessment.totalRisk < 5) return;
      const now = Date.now();
      if (now - this.lastEvasion < 60000) return;
      this.lastEvasion = now;
      const hasHighFrequency = riskAssessment.risks.some(r => r.type === 'high_frequency');
      if (hasHighFrequency) await this.human.takeBreak(this.human.generateDelay('break'), 'anti_detection');
    }
  }

  // ────────────────────────────────────────────────────────────
  // SCROLL — Leadoutfy proven feed scroll + smart fallback
  // ────────────────────────────────────────────────────────────
  async function scrollFeedLeadoutfy() {
    const containers = [
      document.querySelector('[role="feed"]'),
      document.querySelector('.m6QErb[aria-label]'),
      document.querySelector('.DxyBCb'),
      document.querySelector('.m6QErb'),
    ].filter(Boolean);
    for (const fp of containers) {
      const before = fp.scrollTop;
      fp.scrollTop += 1000;
      await sleep(500);
      if (fp.scrollTop > before) return true;
    }
    const winBefore = window.scrollY;
    window.scrollBy(0, 1000);
    await sleep(500);
    if (window.scrollY !== winBefore) return true;
    return false;
  }

  // ────────────────────────────────────────────────────────────
  // LISTING DISCOVERY — Leadoutfy selectors (current Maps stable)
  // ────────────────────────────────────────────────────────────
  // Find the search-results FEED container only. Never select listings from
  // a business panel sidebar (which would cause accidental navigation away
  // from the search results).
  // LeadOutfy v45 proven listing discovery — document-wide with priority order.
  // Maps SPA এ direct .click() panel খোলে, navigation করে না।
  function getListings() {
    const selectors = ['a[href*="/maps/place/"]', '[role="article"]', '.Nv2PK', '.hfpxzc'];
    for (const s of selectors) {
      const els = document.querySelectorAll(s);
      if (els.length > 1) return Array.from(els);
    }
    return [];
  }

  // Detect ONLY hard navigation away from search (full place page URL with no feed).
  function isOnSearchFeed() {
    if (document.querySelector('div[role="feed"]')) return true;
    if (document.querySelector('a[href*="/maps/place/"]')) return true; // listings still visible
    const p = location.pathname || '';
    return p.includes('/maps/search/');
  }

  // Recover only if truly lost (no feed AND no listings AND on /maps/place/ URL).
  async function recoverFeedIfLost(initialSearchUrl) {
    if (isOnSearchFeed()) return true;
    try { history.back(); } catch(e) {}
    for (let i = 0; i < 10; i++) {
      await sleep(400);
      if (isOnSearchFeed()) return true;
    }
    if (initialSearchUrl) {
      try { location.replace(initialSearchUrl); } catch(e) {}
      for (let i = 0; i < 20; i++) {
        await sleep(500);
        if (isOnSearchFeed()) return true;
      }
    }
    return isOnSearchFeed();
  }

  function getListingName(el) {
    try {
      const n = el.querySelector('.qBF1Pd, .fontHeadlineSmall, .NrDZNb');
      if (n && n.textContent.trim()) return n.textContent.trim();
      const aria = el.getAttribute('aria-label');
      if (aria && aria.trim()) return aria.split('·')[0].trim().substring(0, 60);
      return (el.textContent || '').trim().substring(0, 60);
    } catch(e) { return ''; }
  }

  // ────────────────────────────────────────────────────────────
  // PANEL LOAD WAIT — name-matched polling (Leadoutfy v45)
  // ────────────────────────────────────────────────────────────
  function getPanelHeading() {
    for (const s of ['h1.DUwDvf','h1.fontHeadlineLarge','h1[class*="fontHeadlineLarge"]','h1']) {
      const el = document.querySelector(s);
      if (el && el.textContent.trim()) return el.textContent.trim();
    }
    return '';
  }
  async function waitForPanelToLoad(expectedName, baseDelay = 2500) {
    const maxWait = Math.max(baseDelay, 4000);
    const start = Date.now();
    const norm = s => String(s || '').toLowerCase().replace(/[^a-z0-9]/g,'').substring(0,20);
    const namePart = norm(expectedName).substring(0,12);
    while (Date.now() - start < maxWait) {
      const heading = getPanelHeading();
      if (heading) {
        const hNorm = norm(heading);
        if (namePart && (hNorm.includes(namePart) || namePart.includes(hNorm.substring(0,10)))) return true;
      }
      await sleep(300);
    }
    const elapsed = Date.now() - start;
    if (elapsed < baseDelay) await sleep(baseDelay - elapsed);
    return true;
  }

  // ────────────────────────────────────────────────────────────
  // EXTRACTION — Leadoutfy v45/v46 logic
  // ────────────────────────────────────────────────────────────
  async function extractLead(fallbackName, countryCode, opts) {
    opts = opts || {};
    await sleep(500);
    const lead = {
      name: DASH, phone: DASH, whatsapp: DASH, email: DASH,
      website: DASH, address: DASH, rating: DASH, category: DASH
    };

    lead.name = getPanelHeading() || fallbackName;

    // Rating
    for (const sel of ['.F7nice span[aria-hidden="true"]','.MW4etd','.ceNzKf']) {
      const el = document.querySelector(sel);
      if (el) {
        const m = (el.getAttribute('aria-label') || el.textContent).match(/(\d+\.?\d*)/);
        if (m && +m[1] >= 1 && +m[1] <= 5) { lead.rating = m[1]; break; }
      }
    }

    // Category
    for (const s of ['button.DkEaL','.DkEaL','.skqShb .fontBodyMedium','.YhemCb']) {
      const el = document.querySelector(s);
      if (el && el.textContent.trim()) { lead.category = el.textContent.trim(); break; }
    }

    // Address
    const ae = document.querySelector('button[data-item-id*="address"] .Io6YTe,[data-tooltip="Copy address"] .Io6YTe');
    if (ae) {
      lead.address = ae.textContent.trim();
    } else {
      for (const el of document.querySelectorAll('.Io6YTe')) {
        const t = el.textContent.trim();
        if (t.length > 12 && /\d/.test(t) && !t.startsWith('+') && !t.startsWith('http') && !t.includes('@')) {
          lead.address = t; break;
        }
      }
    }

    // Phone
    lead.phone = extractPhone();

    // Website (full URL with path)
    lead.website = extractWebsite();

    // Stale-panel detection
    if (lead.website !== DASH && lead.website) {
      if (lead.website === _lastWebsiteSeen) {
        _sameWebsiteCount++;
        if (_sameWebsiteCount >= MAX_SAME_WEBSITE) {
          lead.website = DASH;
        }
      } else {
        _lastWebsiteSeen = lead.website;
        _sameWebsiteCount = 1;
      }
    } else {
      _lastWebsiteSeen = '';
      _sameWebsiteCount = 0;
    }

    // Email — Maps-page first; website-fetch only if user enabled it
    let websiteEmail = DASH;
    if (opts.findEmailFromWeb && lead.website !== DASH && lead.website) {
      websiteEmail = await fetchEmailFromWebsite(lead.website);
    }
    const mapsEmail = extractEmailFromPage();
    if (websiteEmail && websiteEmail !== DASH) lead.email = websiteEmail;
    else if (mapsEmail && mapsEmail !== DASH) lead.email = mapsEmail;
    else lead.email = DASH;

    // WhatsApp number normalize
    if (lead.phone !== DASH && lead.phone) {
      let d = lead.phone.replace(/[^\d]/g, '');
      if (d.startsWith('0')) d = d.substring(1);
      if (countryCode && !d.startsWith(countryCode)) d = countryCode + d;
      lead.whatsapp = d;
    }

    return lead;
  }

  function isPhone(t) { return !!(t && /^\d{7,15}$/.test(t.replace(/[\s\-().+]/g,''))); }

  function extractPhone() {
    for (const s of [
      'button[data-item-id*="phone"] .Io6YTe',
      'button[data-item-id*="phone"] .rogA2c',
      '[data-item-id*="phone:tel"] .Io6YTe',
      'button[aria-label*="hone:"] .fontBodyMedium',
    ]) {
      const el = document.querySelector(s);
      if (el && isPhone(el.textContent.trim())) return el.textContent.trim();
    }
    const tel = document.querySelector('a[href^="tel:"]');
    if (tel) { const n = tel.href.replace('tel:','').trim(); if (isPhone(n)) return n; }
    for (const el of document.querySelectorAll('.Io6YTe,.rogA2c')) {
      if (isPhone(el.textContent.trim())) return el.textContent.trim();
    }
    try {
      for (const m of (document.body.innerText.match(/(?:\+?\d[\d\s\-()+]{7,18}\d)/g) || [])) {
        if (/^\d{7,15}$/.test(m.replace(/[\s\-().+]/g,''))) return m.trim();
      }
    } catch(e) {}
    return DASH;
  }

  function cleanUrl(u) {
    try {
      const parsed = new URL(u);
      const path = parsed.pathname.replace(/\/$/, '');
      return parsed.origin + (path || '');
    } catch { return u; }
  }
  function isGoodUrl(u) {
    if (!u || !u.startsWith('http')) return false;
    const blocked = [
      'google.com','goo.gl','maps.google','googleapis',
      'googleusercontent','google-analytics','facebook.com',
      'twitter.com','instagram.com','youtube.com','linkedin.com'
    ];
    return !blocked.some(b => u.toLowerCase().includes(b));
  }
  function extractWebsite() {
    const auth = document.querySelector('a[data-item-id*="authority"]');
    if (auth && auth.href && isGoodUrl(auth.href)) return cleanUrl(auth.href);
    for (const el of document.querySelectorAll('a[aria-label]')) {
      const lbl = (el.getAttribute('aria-label')||'').toLowerCase();
      if ((lbl.includes('website') || lbl.includes('web site')) && isGoodUrl(el.href)) return cleanUrl(el.href);
    }
    const tw = document.querySelector('[data-tooltip="Open website"],[data-tooltip="Visit website"]');
    if (tw) {
      const a2 = tw.tagName === 'A' ? tw : (tw.closest('a') || tw.querySelector('a'));
      if (a2 && a2.href && isGoodUrl(a2.href)) return cleanUrl(a2.href);
    }
    return DASH;
  }

  function isGoodEmail(e) {
    if (!e || e.length > 80 || !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(e)) return false;
    const bl = [
      'google.com','gmail.com','googlemail.com','sendgrid.com','example.com',
      'noreply@','no-reply@','donotreply@','test@','cdn.','static.','assets.',
      '.png','.jpg','.gif','sentry.io','wixpress.com','squarespace.com',
      'amazonaws.com','cloudflare.com','akamaitech.net',
      '@2x','@3x','notification','webmaster@','postmaster@','abuse@',
      'your@','name@','email@','user@','username@','someone@','person@',
      'yourname@','youremail@','myemail@','myname@','sample@','demo@',
      'placeholder@','dummy@','fake@','account@'
    ];
    return !bl.some(b => e.toLowerCase().includes(b));
  }
  function extractEmailFromPage() {
    try {
      for (const el of document.querySelectorAll('a[href^="mailto:"]')) {
        const e = el.href.replace('mailto:','').split('?')[0].trim().toLowerCase();
        if (isGoodEmail(e)) return e;
      }
      const re = /[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}/g;
      for (const e of (document.body.innerText.match(re)||[])) { if (isGoodEmail(e)) return e.toLowerCase(); }
      for (const e of (document.body.innerHTML.match(re)||[])) { if (isGoodEmail(e)) return e.toLowerCase(); }
    } catch(e) {}
    return DASH;
  }
  async function fetchEmailFromWebsite(url) {
    return new Promise(resolve => {
      if (!isContextAlive() || !url || url === DASH) { resolve(DASH); return; }
      const timeout = setTimeout(() => resolve(DASH), 9000);
      try {
        // Try both action names (Lead Hunter + Leadoutfy compatible)
        chrome.runtime.sendMessage({ action: 'extractEmailFromWebsite', url }, resp => {
          try { void chrome.runtime.lastError; } catch(e) {}
          if (resp && resp.email && resp.email !== DASH) {
            clearTimeout(timeout); resolve(resp.email); return;
          }
          // Fallback action name
          try {
            chrome.runtime.sendMessage({ action: 'fetchWebsite', url }, resp2 => {
              clearTimeout(timeout);
              try { void chrome.runtime.lastError; } catch(e) {}
              resolve((resp2 && resp2.email) || DASH);
            });
          } catch(e) { clearTimeout(timeout); resolve(DASH); }
        });
      } catch(e) { clearTimeout(timeout); resolve(DASH); }
    });
  }

  // ────────────────────────────────────────────────────────────
  // DEDUP
  // ────────────────────────────────────────────────────────────
  function makeDedupeKey(lead) {
    const norm = s => String(s || '').toLowerCase().replace(/[^a-z0-9]/g,'').substring(0,30);
    return norm(lead.name) + '||' + norm(lead.phone).substring(0,15);
  }

  // ────────────────────────────────────────────────────────────
  // FILTERS
  // ────────────────────────────────────────────────────────────
  function passesFilters(lead, filters) {
    const noVal = (v) => !v || v === DASH || String(v).trim() === '';
    if (filters.skipNoPhone   && noVal(lead.phone))   return false;
    if (filters.skipNoEmail   && noVal(lead.email))   return false;
    if (filters.skipNoWebsite && noVal(lead.website)) return false;
    if (filters.skipNoAddress && noVal(lead.address)) return false;
    return true;
  }

  // ────────────────────────────────────────────────────────────
  // CONFIG
  // ────────────────────────────────────────────────────────────
  async function loadConfiguration() {
    return new Promise(resolve => {
      safeStorageGet([
        'licenseKey','licenseData','creditsRemaining',
        'maxResults','country','scrapeDelay',
        'skipNoPhone','skipNoEmail','skipNoWebsite','skipNoAddress','findEmailFromWeb',
        'settings'
      ], data => {
        const s = data.settings || {};
        resolve({
          maxResults:  data.maxResults || 50,
          delay:       parseInt(data.scrapeDelay) || parseInt(s.min_scrape_delay_ms) || 2500,
          licenseKey:  data.licenseKey  || '',
          country:     data.country     || 'Bangladesh',
          countryCode: COUNTRY_CODES[data.country || 'Bangladesh'] || '880',
          filters: {
            skipNoPhone:   data.skipNoPhone   || false,
            skipNoEmail:   data.skipNoEmail   || false,
            skipNoWebsite: data.skipNoWebsite || false,
            skipNoAddress: data.skipNoAddress || false,
          },
          findEmailFromWeb: data.findEmailFromWeb !== false, // default ON (LeadOutfy v46)
          creditsRemaining: data.creditsRemaining || 0,
          licenseStatus:    (data.licenseData && data.licenseData.status) || 'active',
        });
      });
    });
  }

  // ────────────────────────────────────────────────────────────
  // CREDIT GATE (Lead Hunter background)
  // ────────────────────────────────────────────────────────────
  async function deductCredit(licenseKey) {
    return new Promise(resolve => {
      const t = setTimeout(() => resolve({ ok: true, error: 'timeout_passthrough' }), 4000);
      // Try both action names for compatibility
      try {
        chrome.runtime.sendMessage({ action: 'verifyCredits', licenseKey }, resp => {
          try { void chrome.runtime.lastError; } catch(e) {}
          if (resp && (resp.ok || resp.success)) { clearTimeout(t); resolve({ ok: true }); return; }
          try {
            chrome.runtime.sendMessage({ action: 'deductCredit', licenseKey }, resp2 => {
              clearTimeout(t);
              try { void chrome.runtime.lastError; } catch(e) {}
              resolve(resp2 || { ok: true });
            });
          } catch(e) { clearTimeout(t); resolve({ ok: true }); }
        });
      } catch(e) { clearTimeout(t); resolve({ ok: true }); }
    });
  }

  // ────────────────────────────────────────────────────────────
  // MAIN SCRAPING ENGINE — Leadoutfy proven loop
  // ────────────────────────────────────────────────────────────
  async function startHumanizedScraping() {
    if (scraping) {
      updateStatus('\u26a0\ufe0f Already scraping...');
      return;
    }

    updateStatus('\u23f3 Loading configuration...');
    const config = await loadConfiguration();
    const { maxResults, delay, filters, licenseKey, licenseStatus, countryCode } = config;

    if (!licenseKey) {
      updateStatus('\u274c No active license. Please activate in the extension popup.');
      safeStorageSet({ scraping: false, statusText: '\u274c No license key found.' });
      return;
    }

    console.log('[Lead Hunter Pro] Starting humanized scraping engine...');

    humanBehavior = new HumanBehaviorEngine();
    antiBot = new AntiBotSystem(humanBehavior);

    scraping = true;
    stopRequested = false;
    collected = [];
    _lastWebsiteSeen = '';
    _sameWebsiteCount = 0;

    safeStorageSet({ leads: [], scraping: true, stopRequested: false, statusText: '\ud83c\udfaf Initializing...' });
    setPanelScrapingState(true);
    updateStatus(`\ud83c\udfaf Starting — Max ${maxResults} leads`);
    await sleep(2500);

    // Cross-session phone dedup
    const _huntedData = await new Promise(r => safeStorageGet(['huntedPhones'], r));
    const _huntedPhones = new Set(Array.isArray(_huntedData.huntedPhones) ? _huntedData.huntedPhones : []);
    const _normPhone = (v) => String(v || '').replace(/[^\d]/g, '').slice(-10);

    const seenKeys = new Set();
    const seenElements = new WeakSet();
    const seenHrefs = new Set();
    let scrollRetries = 0;
    let lastRiskCheck = Date.now();
    // Snapshot the original search URL so we can recover if Maps navigates
    // us into a place page accidentally.
    const initialSearchUrl = location.href;

    try {
      mainLoop: while (true) {
        if (collected.length >= maxResults) break mainLoop;
        if (stopRequested || await checkStop()) { updateStatus('\u26d4 Stopped by user'); break mainLoop; }

        if (!isContextAlive()) {
          let r = 0;
          while (r < 5) { await sleep(2000); r++; if (isContextAlive()) break; }
          if (!isContextAlive()) { updateStatus('\u26a0\ufe0f Extension context lost — reload Maps tab'); break mainLoop; }
        }

        // Periodic risk check
        if (Date.now() - lastRiskCheck > 60000) {
          const risk = antiBot.assessRisk();
          await antiBot.executeEvasion(risk);
          updateRiskDisplay(risk.totalRisk);
          lastRiskCheck = Date.now();
        }

        // Break check
        const breakCheck = humanBehavior.shouldTakeBreak();
        if (breakCheck.shouldBreak) {
          await humanBehavior.takeBreak(breakCheck.duration, breakCheck.reason);
          // After a long break Maps may have lost the feed — recover.
          if (!isOnSearchFeed()) {
            updateStatus('\ud83d\udd04 Restoring search after break...');
            await recoverFeedIfLost(initialSearchUrl);
          }
        }

        // Pre-loop guard: make sure we're still on the search feed
        if (!isOnSearchFeed()) {
          updateStatus('\ud83d\udd04 Search feed lost — recovering...');
          const ok = await recoverFeedIfLost(initialSearchUrl);
          if (!ok) { await sleep(2000); continue; }
        }

        let listings = [];
        try { listings = getListings(); } catch(e) { await sleep(2000); continue; }

        let processedNewThisPass = 0;

        for (let i = 0; i < listings.length; i++) {
          if (collected.length >= maxResults) break;
          if (stopRequested || await checkStop()) break;
          if (!isContextAlive()) { await sleep(1500); if (!isContextAlive()) break mainLoop; }

          const listing = listings[i];
          if (!listing || !document.body.contains(listing)) continue;
          if (seenElements.has(listing)) continue;

          // Stable dedup by href (survives DOM re-renders)
          const href = (listing.getAttribute && listing.getAttribute('href')) || '';
          if (href && seenHrefs.has(href)) { seenElements.add(listing); continue; }

          let rawName = '';
          try { rawName = getListingName(listing); } catch(e) { continue; }
          if (!rawName) continue;

          seenElements.add(listing);
          processedNewThisPass++;

          const idx = collected.length + 1;
          const maxLabel = maxResults >= 9999 ? '\u221e' : maxResults;
          updateStatus(`\u26a1 ${idx}/${maxLabel}: ${rawName.slice(0,28)}`);
          updatePanelStats(collected.length, maxResults);

          try {
            // LeadOutfy v45 proven: direct click. Maps SPA opens panel,
            // does not navigate. preventDefault hacks break it.
            await sleep(humanBehavior.generateDelay('clicking', 150, 500));
            try { listing.scrollIntoView({ block: 'center' }); } catch(e) {}
            try { listing.click(); } catch(e) {
              const par = listing.closest && listing.closest('[jsaction]');
              if (par) par.click();
            }

            // Wait for panel matching this business
            await waitForPanelToLoad(rawName, delay);

            // Mark href ONLY after click attempt (so failed retries can re-try later isn't possible
            // anyway with WeakSet, but at least successful loads are tracked)
            if (href) seenHrefs.add(href);

            // Recover only if Maps actually navigated to a place page (rare).
            if (!isOnSearchFeed()) {
              updateStatus('\ud83d\udd04 Recovering feed...');
              await recoverFeedIfLost(initialSearchUrl);
            }

            const lead = await extractLead(rawName, countryCode, { findEmailFromWeb: config.findEmailFromWeb });

            // Local dedup
            const dedupeKey = makeDedupeKey(lead);
            if (seenKeys.has(dedupeKey)) {
              updateStatus('\u23ed Duplicate skip — continuing...');
              await sleep(150); continue;
            }
            seenKeys.add(dedupeKey);

            // Cross-session phone dedup
            const _leadPhoneKey = _normPhone(lead.phone);
            if (_leadPhoneKey && _leadPhoneKey.length >= 6 && _huntedPhones.has(_leadPhoneKey)) {
              updateStatus('\u23ed Already hunted — skip: ' + rawName.slice(0,25));
              await sleep(120); continue;
            }

            // Filters
            if (!passesFilters(lead, filters)) {
              updateStatus(`\u23ed Filtered: ${rawName.slice(0,25)}`);
              await sleep(150); continue;
            }

            // Deduct 1 credit per scraped lead
            const cr = await deductCredit(licenseKey);
            if (cr && cr.error === 'insufficient_credits') {
              updateStatus('❌ Credits exhausted — stopping');
              break mainLoop;
            }

            const finalLead = {
              ...lead,
              _scraped_at: new Date().toISOString(),
            };
            collected.push(finalLead);

            const snapshot = collected.map(l => Object.assign({}, l));
            safeStorageSet({
              leads: snapshot,
              scraping: true,
              statusText: `\u2705 ${collected.length} leads collected`,
              lastUpdate: Date.now(),
            });

            if (_leadPhoneKey && _leadPhoneKey.length >= 6) {
              _huntedPhones.add(_leadPhoneKey);
              safeStorageSet({ huntedPhones: Array.from(_huntedPhones) });
            }

            updatePanelStats(collected.length, maxResults);
            updateStatus(`\u2705 ${collected.length}/${maxLabel}: ${(lead.name || rawName).slice(0,28)}`);

            humanBehavior.recordAction('listing_process');
          } catch(err) {
            console.warn('[Lead Hunter Pro] listing error:', err && err.message);
            if (stopRequested) break mainLoop;
          }

          await sleep(humanBehavior.generateDelay('normal', delay * 0.6, delay * 1.3));
        }

        if (collected.length >= maxResults) break mainLoop;
        if (stopRequested || await checkStop()) break mainLoop;

        // Scroll for more
        let scrolled = false;
        try { scrolled = await scrollFeedLeadoutfy(); } catch(e) { scrolled = false; }

        if (scrolled) {
          scrollRetries = 0;
          await sleep(humanBehavior.generateDelay('scrolling', 1500, 2500));
        } else {
          if (processedNewThisPass > 0) scrollRetries = 0;
          else scrollRetries++;
          const waitMs = scrollRetries > 30 ? 5000 : scrollRetries > 10 ? 3000 : 2000;
          updateStatus(`\u23f3 Loading more... (${collected.length} found)`);
          await sleep(waitMs);
          if (scrollRetries > 50) {
            updateStatus(`\u2705 No more results. ${collected.length} leads collected.`);
            break mainLoop;
          }
        }
      }
    } catch(err) {
      console.error('[Lead Hunter Pro] fatal:', err);
      updateStatus('\u274c Error: ' + (err && err.message));
    } finally {
      scraping = false;
      safeStorageSet({ scraping: false, stopRequested: false, statusText: `\u2705 Done! ${collected.length} leads collected.` });
      setPanelScrapingState(false);
      updateStatus(`\u2705 Done! ${collected.length} leads collected.`);
    }
  }

  function stopScraping() {
    stopRequested = true;
    scraping = false;
    safeStorageSet({ scraping: false, stopRequested: true });
    updateStatus('\ud83d\uded1 Stopping...');
    setPanelScrapingState(false);
  }

  // ────────────────────────────────────────────────────────────
  // STATUS / STATS UI
  // ────────────────────────────────────────────────────────────
  function updateStatus(message) {
    try { console.log(`[LHP] ${message}`); } catch(e) {}
    if (panel) {
      const el = panel.querySelector('#lhp-status');
      if (el) el.textContent = message;
    }
    safeStorageSet({ statusText: message });
  }
  function updatePanelStats(current, max) {
    if (!panel) return;
    const el = panel.querySelector('#lhp-count');
    if (el) el.textContent = `${current}/${max || '?'}`;
  }
  function updateRiskDisplay(totalRisk) {
    if (!panel) return;
    const el = panel.querySelector('#lhp-risk');
    if (!el) return;
    if (totalRisk >= 5) el.textContent = 'HIGH';
    else if (totalRisk >= 2) el.textContent = 'MED';
    else el.textContent = 'LOW';
  }
  function setPanelScrapingState(active) {
    if (!panel) return;
    const startBtn = panel.querySelector('#lhp-btn-start');
    const stopBtn  = panel.querySelector('#lhp-btn-stop');
    if (startBtn) {
      startBtn.disabled = active;
      startBtn.textContent = active ? '\u23f3 Hunting...' : '\ud83d\ude80 Start Hunt';
    }
  }

  // ────────────────────────────────────────────────────────────
  // PANEL UI INJECT (unchanged design)
  // ────────────────────────────────────────────────────────────
  function injectHumanEmulationPanel() {
    if (document.getElementById('lhp-panel')) {
      panel = document.getElementById('lhp-panel');
      return;
    }
    const p = document.createElement('div');
    p.id = 'lhp-panel';
    p.innerHTML = `
      <style>
        #lhp-panel {
          position: fixed; top: 20px; right: 20px; z-index: 2147483647;
          width: 320px; background: rgba(0,0,0,0.92); color: #fff;
          border-radius: 12px; padding: 16px; font-family: 'Segoe UI', sans-serif;
          font-size: 13px; box-shadow: 0 8px 32px rgba(0,0,0,0.5);
          backdrop-filter: blur(10px); border: 1px solid rgba(255,255,255,0.1);
        }
        #lhp-header { display: flex; align-items: center; gap: 8px; margin-bottom: 12px;
          padding-bottom: 8px; border-bottom: 1px solid rgba(255,255,255,0.1); }
        #lhp-logo { font-size: 18px; }
        #lhp-title { font-size: 14px; font-weight: 600; color: #F16232; }
        #lhp-subtitle { font-size: 10px; color: rgba(255,255,255,0.6); }
        #lhp-stats { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-bottom: 12px; }
        .stat-box { background: rgba(241,98,50,0.1); border: 1px solid rgba(241,98,50,0.3);
          padding: 8px; border-radius: 6px; text-align: center; }
        .stat-number { font-size: 16px; font-weight: 700; color: #F16232; }
        .stat-label { font-size: 10px; color: rgba(255,255,255,0.7); }
        #lhp-status { background: rgba(255,255,255,0.05); padding: 8px; border-radius: 6px;
          font-size: 11px; margin-bottom: 12px; border: 1px solid rgba(255,255,255,0.1);
          word-break: break-word; line-height: 1.4; }
        #lhp-controls { display: flex; gap: 8px; }
        .btn { flex: 1; padding: 8px 12px; border: none; border-radius: 6px;
          font-size: 11px; font-weight: 600; cursor: pointer; transition: all 0.2s; }
        .btn-start { background: linear-gradient(135deg, #F16232, #E0521A); color: white; }
        .btn-stop { background: rgba(255,255,255,0.1); color: #fff; border: 1px solid rgba(255,255,255,0.2); }
        .btn:hover { transform: translateY(-1px); }
        .btn:disabled { opacity: 0.6; cursor: not-allowed; transform: none; }
        #lhp-emulation { margin-top: 8px; font-size: 10px; color: rgba(255,255,255,0.5); text-align: center; }
      </style>
      <div id="lhp-header">
        <div id="lhp-logo">\ud83c\udfaf</div>
        <div>
          <div id="lhp-title">Lead Hunter Pro</div>
          <div id="lhp-subtitle">Human Emulation Active</div>
        </div>
      </div>
      <div id="lhp-stats">
        <div class="stat-box"><div class="stat-number" id="lhp-count">0/0</div><div class="stat-label">Leads</div></div>
        <div class="stat-box"><div class="stat-number" id="lhp-risk">LOW</div><div class="stat-label">Risk Level</div></div>
      </div>
      <div id="lhp-status">Ready to start human-like scraping...</div>
      <div id="lhp-controls">
        <button class="btn btn-start" id="lhp-btn-start">\ud83d\ude80 Start Hunt</button>
        <button class="btn btn-stop"  id="lhp-btn-stop">\u23f9\ufe0f Stop</button>
      </div>
      <div id="lhp-emulation">\ud83e\udd16 Anti-Detection \u2022 \ud83e\udde0 Smart Scrolling \u2022 \u23f0 Human Timing</div>
    `;
    document.body.appendChild(p);
    panel = p;

    const btnStart = p.querySelector('#lhp-btn-start');
    const btnStop  = p.querySelector('#lhp-btn-stop');
    if (btnStart) btnStart.addEventListener('click', () => {
      startHumanizedScraping().catch(e => updateStatus('\u274c ' + e.message));
    });
    if (btnStop) btnStop.addEventListener('click', () => stopScraping());
  }

  // ────────────────────────────────────────────────────────────
  // MESSAGE LISTENER (popup → content)
  // ────────────────────────────────────────────────────────────
  try {
    chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
      if (!msg) { try { sendResponse({ ok: false }); } catch(e) {} return true; }
      if (msg.action === 'stopScraping') {
        stopScraping();
        try { sendResponse({ ok: true }); } catch(e) {}
        return true;
      }
      if (msg.action === 'startScraping' || msg.action === 'startHunt') {
        startHumanizedScraping();
        try { sendResponse({ ok: true }); } catch(e) {}
        return true;
      }
      if (msg.action === 'ping' || msg.action === 'keepAlive') {
        try { sendResponse({ ok: true, scraping }); } catch(e) {}
        return true;
      }
      try { sendResponse({ ok: true }); } catch(e) {}
      return true;
    });
  } catch(e) {}

  // ────────────────────────────────────────────────────────────
  // INIT — inject panel + AUTO-START hook (the main fix)
  // ────────────────────────────────────────────────────────────
  function bootstrap() {
    if (!window.location.href.includes('google.com/maps')) return;

    // Inject panel after Maps loads
    setTimeout(() => {
      try { injectHumanEmulationPanel(); } catch(e) { console.warn('panel inject:', e); }
      console.log('[Lead Hunter Pro v2.1] Loaded \u2705');

      // Read auto-start flags from storage
      safeStorageGet(['autoStart','scraping','stopRequested','maxResults','licenseKey'], (data) => {
        const shouldAutoStart =
          (data.autoStart === true) ||
          (data.scraping === true && data.stopRequested !== true);

        if (!shouldAutoStart) return;
        if (!data.licenseKey) {
          updateStatus('\u274c No license — open popup to activate.');
          return;
        }

        // Clear autoStart flag so it doesn't re-fire on reload
        safeStorageSet({ autoStart: false });
        updateStatus('\ud83d\udd0d Auto-starting in 4s...');
        setTimeout(() => {
          startHumanizedScraping().catch(e => updateStatus('\u274c ' + e.message));
        }, 4000);
      });
    }, 2000);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bootstrap);
  } else {
    bootstrap();
  }

  // Storage change listener — sync collected when popup updates
  try {
    chrome.storage.onChanged.addListener((changes) => {
      if (changes.stopRequested && changes.stopRequested.newValue === true) {
        stopRequested = true;
      }
    });
  } catch(e) {}

  // Expose globals for debugging
  window.startHumanizedScraping = startHumanizedScraping;
  window.stopScraping = stopScraping;

})();
