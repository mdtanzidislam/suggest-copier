// ════════════════════════════════════════════════════════════════
// LEAD HUNTER PRO — Background Service Worker v2.0
// Human Emulation Support + Advanced Anti-Detection
// ════════════════════════════════════════════════════════════════

'use strict';

// ────────────────────────────────────────────────────────────
// CONFIGURATION & CONSTANTS
// ────────────────────────────────────────────────────────────

// ────────────────────────────────────────────────────────────
// CONFIGURATION & CONSTANTS — Supabase Direct Mode
// ────────────────────────────────────────────────────────────

const SUPABASE_URL  = 'https://vrtjopgjwlzogicmtade.supabase.co';
const SUPABASE_ANON = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZydGpvcGdqd2x6b2dpY210YWRlIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzc2NTA2ODMsImV4cCI6MjA5MzIyNjY4M30.TCDk_o8a3fPo0LxXFRncT51E6E5SJwvVOQemJthkI_k';
const REST_URL = SUPABASE_URL + '/rest/v1';

// All sensitive operations now go through server-side Edge Functions.
// The extension NEVER writes to the DB directly anymore.
const FUNCTIONS_URL = SUPABASE_URL + '/functions/v1';

// The anon key is only used to authenticate the call to the Edge Function
// gateway — the function itself uses service_role internally (server side).
const FN_HEADERS = {
  'apikey': SUPABASE_ANON,
  'Authorization': 'Bearer ' + SUPABASE_ANON,
  'Content-Type': 'application/json',
};

// Helper: call an Edge Function and return parsed JSON (or a safe error).
async function callFunction(name, payload) {
  try {
    const r = await fetch(`${FUNCTIONS_URL}/${name}`, {
      method: 'POST',
      headers: FN_HEADERS,
      body: JSON.stringify(payload || {}),
    });
    const data = await r.json().catch(() => ({}));
    return data;
  } catch (e) {
    return { success: false, error: 'network_error' };
  }
}

// NOTE: SB_HEADERS retained ONLY for reads that are still allowed under
// RLS (e.g. public `plans` pricing). It can no longer write to `users`.
const SB_HEADERS = {
  'apikey': SUPABASE_ANON,
  'Authorization': 'Bearer ' + SUPABASE_ANON,
  'Content-Type': 'application/json',
};

const API_BASE = SUPABASE_URL;  // Backwards compatibility
// WhatsApp now sends via DOM injection on web.whatsapp.com — no external server.
const EMAIL_API = '';

// ── WhatsApp Web tab tracking & ban protection ────────────────
let waTabId = null;
let waReady = false;
let waPhone = '';
let campaignRunning = false;
let campaignStats = { sent: 0, failed: 0, pending: 0, total: 0 };

const BAN_PROTECTION = {
  minDelayMs: 8000,
  maxDelayMs: 25000,
  dailyLimit: 80,
  hourlyLimit: 20,
  burstLimit: 5,
  burstBreakMs: 120000,
  sessionMaxMs: 7200000
};

function gaussianDelay(min, max) {
  const u = Math.random() || 0.0001, v = Math.random() || 0.0001;
  const z = Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
  const mean = (min + max) / 2;
  const std  = (max - min) / 6;
  return Math.max(min, Math.min(max, Math.round(mean + z * std)));
}

function processSpintax(text) {
  if (!text) return '';
  let prev;
  do {
    prev = text;
    text = text.replace(/\{([^{}]+)\}/g, (_, group) => {
      const opts = group.split('|');
      return opts[Math.floor(Math.random() * opts.length)];
    });
  } while (text !== prev);
  return text;
}

// ── IndexedDB log ────────────────────────────────────────────
const LHP_DB = 'lhp_wa_logs';
function openLogDB() {
  return new Promise((res, rej) => {
    const req = indexedDB.open(LHP_DB, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains('logs')) {
        const s = db.createObjectStore('logs', { keyPath:'id', autoIncrement:true });
        s.createIndex('date', 'date'); s.createIndex('status','status');
      }
    };
    req.onsuccess = () => res(req.result);
    req.onerror   = () => rej(req.error);
  });
}
async function addLog(entry) {
  try {
    const db = await openLogDB();
    return new Promise((res) => {
      const tx = db.transaction('logs','readwrite');
      tx.objectStore('logs').add({
        ...entry,
        timestamp: Date.now(),
        date: new Date().toISOString().slice(0,10)
      });
      tx.oncomplete = () => res(true);
      tx.onerror = () => res(false);
    });
  } catch(e) { return false; }
}
async function getLogs(limit = 500) {
  try {
    const db = await openLogDB();
    return new Promise((res) => {
      const tx = db.transaction('logs','readonly');
      const req = tx.objectStore('logs').getAll();
      req.onsuccess = () => res((req.result || []).slice(-limit).reverse());
      req.onerror   = () => res([]);
    });
  } catch(e) { return []; }
}
async function clearLogs() {
  try {
    const db = await openLogDB();
    return new Promise((res) => {
      const tx = db.transaction('logs','readwrite');
      tx.objectStore('logs').clear();
      tx.oncomplete = () => res(true);
    });
  } catch(e) { return false; }
}

// Anti-detection settings
const RATE_LIMITS = {
  MAX_CREDITS_PER_MINUTE: 20,
  MAX_API_CALLS_PER_HOUR: 300,
  MIN_DELAY_BETWEEN_CALLS: 1000,
  BURST_PROTECTION_THRESHOLD: 50
};

// Human emulation timing
const HUMAN_TIMING = {
  MIN_SCRAPE_DELAY: 3000,      // 3 seconds minimum between leads
  MAX_SCRAPE_DELAY: 8000,      // 8 seconds maximum
  THINKING_DELAY: 2000,        // Delay for "thinking" actions
  BREAK_INTERVAL: 1800000,     // 30 minutes = break time
  BREAK_DURATION: 300000,      // 5 minutes break
  SESSION_MAX_DURATION: 7200000 // 2 hours max session
};

// ────────────────────────────────────────────────────────────
// STATE MANAGEMENT
// ────────────────────────────────────────────────────────────

let sessionData = {
  startTime: Date.now(),
  totalActions: 0,
  lastAction: 0,
  breakssTaken: 0,
  suspiciousActivityScore: 0,
  rateLimit: {
    apiCalls: [],
    creditDeductions: []
  }
};

let messageQueues = {
  whatsapp: [],
  email: [],
  webhook: []
};

let queueProcessing = {
  whatsapp: false,
  email: false,
  webhook: false
};

// ────────────────────────────────────────────────────────────
// HUMAN EMULATION UTILITIES
// ────────────────────────────────────────────────────────────

class BackgroundHumanEmulation {
  static generateDelay(type = 'normal') {
    const patterns = {
      normal: () => this.gaussianRandom(3000, 6000),
      thinking: () => this.gaussianRandom(2000, 5000),
      network: () => this.gaussianRandom(1000, 3000),
      typing: () => this.gaussianRandom(100, 500),
      break: () => this.gaussianRandom(15000, 45000)
    };
    
    const delay = patterns[type] ? patterns[type]() : patterns.normal();
    
    // Apply session fatigue (delays increase over time)
    const sessionMinutes = (Date.now() - sessionData.startTime) / 60000;
    const fatigueMultiplier = 1 + (sessionMinutes * 0.01); // 1% increase per minute
    
    return Math.floor(delay * fatigueMultiplier);
  }

  static gaussianRandom(min, max) {
    let u = 0, v = 0;
    while(u === 0) u = Math.random();
    while(v === 0) v = Math.random();
    const z = Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
    const value = min + (max - min) * (0.5 + 0.3 * z);
    return Math.max(min, Math.min(max, value));
  }

  static shouldTakeBreak() {
    const now = Date.now();
    const sessionDuration = now - sessionData.startTime;
    
    // Mandatory breaks
    if (sessionDuration > HUMAN_TIMING.SESSION_MAX_DURATION) {
      return { required: true, reason: 'max_session', duration: HUMAN_TIMING.BREAK_DURATION * 2 };
    }
    
    if (sessionData.totalActions > 300) {
      return { required: true, reason: 'high_activity', duration: HUMAN_TIMING.BREAK_DURATION };
    }
    
    // Probabilistic breaks (human spontaneity)
    if (Math.random() < 0.02) { // 2% chance each check
      return { required: true, reason: 'random', duration: this.generateDelay('break') };
    }
    
    return { required: false };
  }

  static recordAction(type, metadata = {}) {
    const now = Date.now();
    sessionData.totalActions++;
    sessionData.lastAction = now;
    
    // Calculate suspicious activity score
    if (sessionData.lastAction && (now - sessionData.lastAction) < 500) {
      sessionData.suspiciousActivityScore += 5; // Too fast
    }
    
    // Decay suspicion over time
    if (sessionData.suspiciousActivityScore > 0) {
      sessionData.suspiciousActivityScore = Math.max(0, sessionData.suspiciousActivityScore - 0.1);
    }
    
    console.log(`[Human Emulation] Action recorded: ${type}, Suspicion: ${Math.round(sessionData.suspiciousActivityScore)}`);
  }

  static async enforceRateLimit(type, limit, windowMs) {
    const now = Date.now();
    const window = sessionData.rateLimit[type] || [];
    
    // Remove old entries outside window
    sessionData.rateLimit[type] = window.filter(time => now - time < windowMs);
    
    // Check if we're at the limit
    if (sessionData.rateLimit[type].length >= limit) {
      const oldestInWindow = Math.min(...sessionData.rateLimit[type]);
      const waitTime = windowMs - (now - oldestInWindow);
      
      console.log(`[Rate Limit] ${type} rate limit hit, waiting ${waitTime}ms`);
      await this.sleep(waitTime + this.generateDelay('network'));
    }
    
    // Record this action
    sessionData.rateLimit[type].push(now);
  }

  static sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

// ────────────────────────────────────────────────────────────
// API COMMUNICATION WITH ANTI-DETECTION
// ────────────────────────────────────────────────────────────

async function secureApiCall(endpoint, method = 'GET', body = null, includeAuth = true) {
  await BackgroundHumanEmulation.enforceRateLimit('apiCalls', RATE_LIMITS.MAX_API_CALLS_PER_HOUR, 3600000);
  
  // Generate security headers
  const headers = {
    'Content-Type': 'application/json',
    'X-LHP-Version': '2.0.0',
    'X-LHP-Timestamp': Date.now().toString(),
    'X-LHP-Session': generateSessionId()
  };

  // Add authentication if available
  if (includeAuth) {
    const auth = await getStoredAuth();
    if (auth.licenseKey) {
      headers['Authorization'] = `Bearer ${auth.licenseKey}`;
    }
  }

  // Anti-fingerprinting: Randomize request timing
  const jitter = BackgroundHumanEmulation.generateDelay('network') / 10;
  await BackgroundHumanEmulation.sleep(jitter);

  try {
    const response = await fetch(`${API_BASE}${endpoint}`, {
      method,
      headers,
      body: body ? JSON.stringify(body) : null
    });

    if (!response.ok) {
      throw new Error(`API Error: ${response.status}`);
    }

    const data = await response.json();
    BackgroundHumanEmulation.recordAction('api_call', { endpoint, method });
    
    return { success: true, data };
  } catch (error) {
    console.error(`[API] Error calling ${endpoint}:`, error);
    return { success: false, error: error.message };
  }
}

function generateSessionId() {
  if (!sessionData.sessionId) {
    sessionData.sessionId = 'lhp_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
  }
  return sessionData.sessionId;
}

async function getStoredAuth() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['licenseKey', 'userProfile'], (data) => {
      resolve({
        licenseKey: data.licenseKey || '',
        userProfile: data.userProfile || null
      });
    });
  });
}

// ────────────────────────────────────────────────────────────
// CREDIT MANAGEMENT WITH BATCH PROCESSING
// ────────────────────────────────────────────────────────────

let creditBatch = {
  pending: 0,
  licenseKey: '',
  lastFlush: Date.now(),
  BATCH_SIZE: 10,
  MAX_WAIT_TIME: 30000 // 30 seconds
};

async function recordCreditUsage(licenseKey) {
  await BackgroundHumanEmulation.enforceRateLimit('creditDeductions', RATE_LIMITS.MAX_CREDITS_PER_MINUTE, 60000);
  
  creditBatch.licenseKey = licenseKey;
  creditBatch.pending++;
  
  console.log(`[Credits] Batch pending: ${creditBatch.pending}/${creditBatch.BATCH_SIZE}`);
  
  // Flush if batch is full or timeout reached
  const shouldFlush = creditBatch.pending >= creditBatch.BATCH_SIZE ||
                     (Date.now() - creditBatch.lastFlush) > creditBatch.MAX_WAIT_TIME;
  
  if (shouldFlush) {
    return await flushCreditBatch();
  }
  
  return { success: true, batched: true };
}

async function flushCreditBatch() {
  if (creditBatch.pending === 0) return { success: true };

  const batchSize = creditBatch.pending;
  const licKey = creditBatch.licenseKey;
  creditBatch.pending = 0;
  creditBatch.lastFlush = Date.now();

  console.log(`[Credits] Flushing batch of ${batchSize} credits`);

  try {
    // All credit logic now runs server-side in one atomic transaction.
    // The extension cannot compute, skip, or fake the deduction.
    const res = await callFunction('deduct-credits', {
      license_key: licKey,
      amount: batchSize,
    });

    if (!res || res.success !== true) {
      // Stop scraping on any failure (inactive / insufficient / error)
      const remaining = typeof res?.remaining === 'number' ? res.remaining : 0;
      const msg = res?.error === 'insufficient_credits' ? 'Credits exhausted'
                : res?.error === 'inactive'             ? 'License inactive'
                : 'Credit verification failed';
      chrome.storage.local.set({
        stopRequested: true,
        scraping: false,
        statusMessage: msg,
        creditsRemaining: remaining,
      });
      notifyAllTabs({ action: 'creditsExhausted' });
      return { success: false, error: res?.error || 'deduct_failed' };
    }

    const newRemaining = res.credits_remaining ?? 0;

    // Update stored credits
    chrome.storage.local.set({
      creditsRemaining: newRemaining,
      lastCreditUpdate: Date.now(),
    });

    // Stop if exhausted
    if (newRemaining <= 0) {
      chrome.storage.local.set({ stopRequested: true, scraping: false, statusMessage: 'Credits exhausted' });
      notifyAllTabs({ action: 'creditsExhausted' });
    }

    return { success: true, creditsRemaining: newRemaining };

  } catch (e) {
    console.error('[Credits] Flush failed:', e.message);
    chrome.storage.local.set({ stopRequested: true, scraping: false, statusMessage: 'Credit verification failed' });
    return { success: false, error: e.message };
  }
}

// ────────────────────────────────────────────────────────────
// LICENSE VERIFICATION WITH HUMAN TIMING
// ────────────────────────────────────────────────────────────

async function verifyLicense(licenseKey) {
  console.log('[License] Verifying license via Edge Function...');

  // Simulate human delay
  await BackgroundHumanEmulation.sleep(BackgroundHumanEmulation.generateDelay('thinking'));

  try {
    const res = await callFunction('license-verify', { license_key: licenseKey });

    if (!res || res.success !== true) {
      // Map server error codes to user-facing messages
      const map = {
        license_key_not_found: 'License key not found',
        account_suspended:     'Account suspended',
        payment_pending:       'Payment pending — credits added within 24h',
        license_key_required:  'License key required',
        connection_failed:     'Connection failed',
        network_error:         'Connection failed',
      };
      return { success: false, error: map[res?.error] || 'Verification failed' };
    }

    const lic = res.license;
    const licenseData = {
      status:            lic.status,
      plan_name:         lic.plan_name || lic.plan_slug || 'Active',
      plan_slug:         lic.plan_slug,
      credits_remaining: lic.credits_remaining || 0,
      credits_total:     lic.credits_total     || 0,
      credits_used:      lic.credits_used      || 0,
      activated_at:      lic.activated_at,
      expires_at:        lic.expires_at,
      features:          lic.features || [],
    };

    // Store license data
    chrome.storage.local.set({
      licenseKey: licenseKey,
      licenseData: licenseData,
      creditsRemaining: licenseData.credits_remaining,
      licenseVerifiedAt: Date.now(),
      userProfile: { plan: licenseData.plan_name, status: licenseData.status, expiresAt: licenseData.expires_at },
    });

    BackgroundHumanEmulation.recordAction('license_verify', { plan: licenseData.plan_name });

    return { success: true, license: licenseData, message: 'License verified successfully' };

  } catch (e) {
    return { success: false, error: e.message };
  }
}

// ────────────────────────────────────────────────────────────
// MESSAGING QUEUES WITH HUMAN-LIKE DELAYS
// ────────────────────────────────────────────────────────────

async function queueLeadForMessaging(lead, messageTypes = ['whatsapp', 'email']) {
  console.log(`[Queue] Adding lead to messaging queue:`, lead.name);
  
  if (messageTypes.includes('whatsapp')) {
    messageQueues.whatsapp.push({
      lead,
      addedAt: Date.now(),
      attempts: 0
    });
  }
  
  if (messageTypes.includes('email')) {
    messageQueues.email.push({
      lead,
      addedAt: Date.now(),
      attempts: 0
    });
  }
  
  // Start processors if not already running
  if (!queueProcessing.whatsapp && messageQueues.whatsapp.length > 0) {
    processWhatsAppQueue();
  }
  
  if (!queueProcessing.email && messageQueues.email.length > 0) {
    processEmailQueue();
  }
}

async function processWhatsAppQueue() {
  if (queueProcessing.whatsapp) return;
  queueProcessing.whatsapp = true;
  
  console.log('[WhatsApp Queue] Starting processor...');
  
  while (messageQueues.whatsapp.length > 0) {
    const item = messageQueues.whatsapp.shift();
    
    try {
      // Check if WhatsApp is still enabled
      const settings = await getMessagingSettings();
      if (!settings.whatsappEnabled) break;
      
      // Human-like delay before sending
      const delay = BackgroundHumanEmulation.generateDelay('normal');
      console.log(`[WhatsApp] Waiting ${delay}ms before sending to ${item.lead.name}...`);
      await BackgroundHumanEmulation.sleep(delay);
      
      // Send WhatsApp message
      const result = await sendWhatsAppMessage(item.lead, settings);
      
      if (result.success) {
        console.log(`[WhatsApp] ✅ Sent to ${item.lead.name}`);
        
        // Record successful send
        await recordMessageSent('whatsapp', item.lead);
        
        BackgroundHumanEmulation.recordAction('whatsapp_send', { 
          phone: item.lead.phone,
          success: true
        });
      } else {
        console.error(`[WhatsApp] ❌ Failed to send to ${item.lead.name}:`, result.error);
        
        // Retry logic for failed messages
        if (item.attempts < 3) {
          item.attempts++;
          messageQueues.whatsapp.push(item); // Re-queue for retry
        }
      }
      
      // Break check
      const breakCheck = BackgroundHumanEmulation.shouldTakeBreak();
      if (breakCheck.required) {
        console.log(`[WhatsApp Queue] Taking break: ${breakCheck.reason}`);
        await BackgroundHumanEmulation.sleep(breakCheck.duration);
      }
      
    } catch (error) {
      console.error('[WhatsApp Queue] Error:', error);
    }
  }
  
  queueProcessing.whatsapp = false;
  console.log('[WhatsApp Queue] Processor finished');
}

async function processEmailQueue() {
  if (queueProcessing.email) return;
  queueProcessing.email = true;
  
  console.log('[Email Queue] Starting processor...');
  
  while (messageQueues.email.length > 0) {
    const item = messageQueues.email.shift();
    
    try {
      // Check if Email is still enabled
      const settings = await getMessagingSettings();
      if (!settings.emailEnabled) break;
      
      // Human-like delay before sending
      const delay = BackgroundHumanEmulation.generateDelay('normal');
      console.log(`[Email] Waiting ${delay}ms before sending to ${item.lead.name}...`);
      await BackgroundHumanEmulation.sleep(delay);
      
      // Send Email
      const result = await sendEmailMessage(item.lead, settings);
      
      if (result.success) {
        console.log(`[Email] ✅ Sent to ${item.lead.name}`);
        
        // Record successful send
        await recordMessageSent('email', item.lead);
        
        BackgroundHumanEmulation.recordAction('email_send', {
          email: item.lead.email,
          success: true
        });
      } else {
        console.error(`[Email] ❌ Failed to send to ${item.lead.name}:`, result.error);
        
        // Retry logic
        if (item.attempts < 3) {
          item.attempts++;
          messageQueues.email.push(item);
        }
      }
      
      // Break check
      const breakCheck = BackgroundHumanEmulation.shouldTakeBreak();
      if (breakCheck.required) {
        console.log(`[Email Queue] Taking break: ${breakCheck.reason}`);
        await BackgroundHumanEmulation.sleep(breakCheck.duration);
      }
      
    } catch (error) {
      console.error('[Email Queue] Error:', error);
    }
  }
  
  queueProcessing.email = false;
  console.log('[Email Queue] Processor finished');
}

// ────────────────────────────────────────────────────────────
// MESSAGE SENDING IMPLEMENTATIONS
// ────────────────────────────────────────────────────────────

// ── WhatsApp Web tab helpers ──────────────────────────────────
async function findWhatsAppTab() {
  try {
    const tabs = await chrome.tabs.query({ url: 'https://web.whatsapp.com/*' });
    return tabs && tabs[0] ? tabs[0] : null;
  } catch(e) { return null; }
}

async function tabExists(tabId) {
  if (!tabId) return false;
  try { const t = await chrome.tabs.get(tabId); return !!t; }
  catch(e) { return false; }
}

async function checkWhatsAppReady() {
  const tab = await findWhatsAppTab();
  if (!tab) { waTabId = null; waReady = false; return { connected:false, ready:false, hasTab:false }; }
  try {
    const r = await chrome.tabs.sendMessage(tab.id, { action:'WA_CHECK_READY' });
    waTabId = tab.id;
    waReady = !!(r && r.ready);
    return { connected: waReady, ready: waReady, hasTab:true, tabId: tab.id };
  } catch(e) {
    return { connected:false, ready:false, hasTab:true };
  }
}

async function openWhatsAppWebTab() {
  try {
    const existing = await findWhatsAppTab();
    if (existing) {
      try { await chrome.tabs.update(existing.id, { active:true }); } catch(_){}
      return { ok:true, tabId: existing.id };
    }
    const t = await chrome.tabs.create({ url:'https://web.whatsapp.com/', active:true });
    return { ok:true, tabId: t.id };
  } catch(e) {
    return { ok:false, error: e.message };
  }
}

// ════════════════════════════════════════════════════
// WA SENDER PRO — BROADCASTING ENGINE (Ported)
// ════════════════════════════════════════════════════

function processSpintaxLHP(text) {
  return text.replace(/\{([^{}]+)\}/g, function(_, inner) {
    const parts = inner.split('|');
    return parts[Math.floor(Math.random() * parts.length)];
  });
}

async function injectSoftNavigateLHP(tabId, phone) {
  // DEPRECATED — kept for compatibility. Old version did a real anchor-click
  // navigation which caused web.whatsapp.com to blank out / reload.
  // Now a no-op: navigation is performed by wa-content.js navigateToChat()
  // inside the WA_SEND_MESSAGE handler.
  void tabId; void phone;
  return { ok:true, skipped:true };
}

async function injectedSendLogicLHP(tabId, contact, text, imagesArray = [], shouldShuffle = true) {
  const results = await chrome.scripting.executeScript({
    target: { tabId },
    func: async (contact, text, imagesArray, shouldShuffle) => {
      return new Promise(async (resolve) => {
        const wait = ms => new Promise(r => setTimeout(r, ms));
        if (shouldShuffle && imagesArray && imagesArray.length > 1) {
          let cloned = [...imagesArray];
          for (let i = cloned.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [cloned[i], cloned[j]] = [cloned[j], cloned[i]];
          }
          imagesArray = cloned;
        }
        let attempts = 0;
        while (attempts < 20) {
          const modal = document.querySelector('[data-animate-modal-popup="true"]');
          if (modal) {
            const modalText = modal.innerText.toLowerCase();
            if (modalText.includes('invalid') || modalText.includes('not on whatsapp') || modalText.includes('link')) {
              const okBtn = modal.querySelector('button');
              if (okBtn) okBtn.click();
              return resolve({ success: false, reason: 'Invalid or missing WhatsApp number.' });
            }
          }
          const chatInput =
            document.querySelector('footer div[contenteditable="true"]') ||
            document.querySelector('div[contenteditable="true"][data-tab="10"]') ||
            document.querySelector('div[title="Type a message"]');
          if (chatInput) break;
          await wait(500);
          attempts++;
        }
        if (attempts >= 20) return resolve({ success: false, reason: 'Timeout: chat UI did not load.' });
        try {
          const chatBox =
            document.querySelector('footer div[contenteditable="true"]') ||
            document.querySelector('div[contenteditable="true"][data-tab="10"]') ||
            document.querySelector('div[title="Type a message"]');
          if (imagesArray && imagesArray.length > 0) {
            const dt = new DataTransfer();
            for (const img of imagesArray) {
              const byteString = atob(img.data.split(',')[1]);
              const ab = new ArrayBuffer(byteString.length);
              const ia = new Uint8Array(ab);
              for (let i = 0; i < byteString.length; i++) ia[i] = byteString.charCodeAt(i);
              const blob = new Blob([ab], { type: img.type || 'image/png' });
              const file = new File([blob], img.name || 'image.png', { type: img.type || 'image/png' });
              dt.items.add(file);
            }
            if (chatBox) chatBox.focus();
            const pasteEvent = new ClipboardEvent('paste', { clipboardData: dt, bubbles: true });
            (chatBox || document).dispatchEvent(pasteEvent);
            await wait(3500);
            let captionBox = null;
            const allEditables = Array.from(document.querySelectorAll('div[contenteditable="true"]'));
            for (const el of allEditables) {
              if (el.getAttribute('data-tab') === '10') continue;
              if (el.offsetHeight === 0) continue;
              const inDialog =
                el.closest('[role="dialog"]') ||
                el.closest('[data-testid="media-caption-input-container"]') ||
                el.closest('[data-testid="compose-box-input"]');
              if (inDialog || allEditables.length === 2) { captionBox = el; break; }
            }
            if (!captionBox) {
              captionBox = allEditables.filter(el =>
                el.getAttribute('data-tab') !== '10' && el.offsetHeight > 0
              ).pop();
            }
            if (text && captionBox) {
              captionBox.focus();
              await wait(300);
              const dataTransfer = new DataTransfer();
              dataTransfer.setData('text/plain', text);
              captionBox.dispatchEvent(new ClipboardEvent('paste', {
                clipboardData: dataTransfer, bubbles: true, cancelable: true
              }));
              await wait(200);
              document.execCommand('insertText', false, ' ');
              document.execCommand('delete', false, null);
              await wait(500);
            }
            let sendBtn =
              document.querySelector('div[role="button"][aria-label="Send"]') ||
              document.querySelector('button[aria-label="Send"]');
            if (!sendBtn) {
              const sendIcon =
                document.querySelector('span[data-icon="send"]') ||
                document.querySelector('span[data-icon="wds-ic-send-filled"]') ||
                document.querySelector('[data-testid="send"]');
              if (sendIcon) {
                sendBtn = sendIcon.closest('div[role="button"]') ||
                          sendIcon.closest('button') ||
                          sendIcon.parentElement;
              }
            }
            if (sendBtn) {
              sendBtn.click();
              await wait(2500);
              const stillSend = document.querySelector('span[data-icon="send"]');
              if (stillSend) {
                const retryBtn = stillSend.closest('div[role="button"]') ||
                                 stillSend.closest('button') || stillSend.parentElement;
                if (retryBtn) retryBtn.click();
                await wait(2000);
              }
            } else if (captionBox) {
              captionBox.focus();
              captionBox.dispatchEvent(new KeyboardEvent('keydown', {
                key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true
              }));
              await wait(2000);
            }
            await wait(500);
            return resolve({ success: true });
          }
          if (!chatBox) return resolve({ success: false, reason: 'Chat input box not found.' });
          if (!text || text.trim().length === 0) return resolve({ success: false, reason: 'Template text is empty.' });
          chatBox.focus();
          await wait(300);
          const dataTransfer = new DataTransfer();
          dataTransfer.setData('text/plain', text);
          chatBox.dispatchEvent(new ClipboardEvent('paste', {
            clipboardData: dataTransfer, bubbles: true, cancelable: true
          }));
          await wait(300);
          document.execCommand('insertText', false, ' ');
          document.execCommand('delete', false, null);
          await wait(500);
          let sendBtn = null;
          let sRetries = 5;
          while (sRetries > 0 && !sendBtn) {
            sendBtn =
              document.querySelector('span[data-icon="send"]')?.closest('button') ||
              document.querySelector('button[aria-label="Send"]') ||
              document.querySelector('div[role="button"][aria-label="Send"]') ||
              document.querySelector('[data-testid="send"]')?.closest('button');
            if (sendBtn) break;
            await wait(300);
            sRetries--;
          }
          if (sendBtn) {
            sendBtn.click();
          } else {
            chatBox.focus();
            chatBox.dispatchEvent(new KeyboardEvent('keydown', {
              key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true
            }));
          }
          await wait(1500);
          return resolve({ success: true });
        } catch (err) {
          return resolve({ success: false, reason: err.message });
        }
      });
    },
    args: [contact, text, imagesArray, shouldShuffle]
  });
  return results?.[0]?.result || { success: false, reason: 'Script injection returned empty.' };
}

async function sendWhatsAppMessage(lead, settings) {
  const phone = (lead.phone || lead.whatsapp || '').toString().replace(/\D/g,'');
  if (!phone) return { success:false, error:'No phone number' };

  // Ban-protection limit checks
  const today = new Date().toDateString();
  const hourKey = new Date().toISOString().slice(0,13);
  const st = await new Promise(r => chrome.storage.local.get(
    ['waDailyCount','waDailyDate','waHourlyCount','waHourlyHour',
     'waMinDelay','waMaxDelay','waDailyLimit','waHourlyLimit','waBurstSent','waLastBurstReset','waTypingMs'], r));

  let waDailyCount  = st.waDailyDate === today ? (st.waDailyCount  || 0) : 0;
  let waHourlyCount = st.waHourlyHour === hourKey ? (st.waHourlyCount || 0) : 0;
  const dailyLimit  = st.waDailyLimit  || BAN_PROTECTION.dailyLimit;
  const hourlyLimit = st.waHourlyLimit || BAN_PROTECTION.hourlyLimit;
  if (waDailyCount  >= dailyLimit)  return { success:false, error:`Daily limit reached (${dailyLimit}/day)` };
  if (waHourlyCount >= hourlyLimit) return { success:false, error:`Hourly limit reached (${hourlyLimit}/hr)` };

  // Burst check
  let burstSent = st.waBurstSent || 0;
  const lastBurstReset = st.waLastBurstReset || 0;
  if (Date.now() - lastBurstReset > BAN_PROTECTION.burstBreakMs) burstSent = 0;
  if (burstSent >= BAN_PROTECTION.burstLimit) {
    console.log('[WA] Burst limit hit — taking break');
    await BackgroundHumanEmulation.sleep(BAN_PROTECTION.burstBreakMs);
    burstSent = 0;
    await chrome.storage.local.set({ waBurstSent:0, waLastBurstReset: Date.now() });
  }

  // Resolve WA tab
  const ready = await checkWhatsAppReady();
  if (!ready.ready) return { success:false, error:'WhatsApp Web not ready / not logged in' };

  // Build message: template + variables + spintax
  const tmpl = settings.whatsappTemplate || settings.waTemplate || '';
  const filled  = fillTemplate(tmpl, lead);
  const message = processSpintax(filled);
  if (!message.trim()) return { success:false, error:'Empty message' };

  const typingMs = st.waTypingMs || 1500;

  // ── Delegate to wa-content.js (DOM-only, no URL navigation) ──────
  // The content script's navigateToChat() uses search/new-chat DOM flows,
  // so WhatsApp Web does NOT reload/blank-out.
  console.log('[LHP-BG] Dispatching WA send job for:', phone);
  const result = await dispatchWaJob(waTabId, {
    phone,
    text: message,
    typingMs,
    attachDataUrl: settings.waAttachDataUrl || null,
    attachMeta:    settings.waAttachMeta    || null,
  });

  // Persist log
  await addLog({
    phone, name: lead.name || '', message,
    status: result?.success ? 'sent' : 'failed',
    reason: result?.success ? null : (result?.reason || 'unknown'),
    channel: 'whatsapp'
  });

  if (result?.success) {
    await chrome.storage.local.set({
      waDailyCount:  waDailyCount + 1,  waDailyDate: today,
      waHourlyCount: waHourlyCount + 1, waHourlyHour: hourKey,
      waBurstSent:   burstSent + 1,
      waLastBurstReset: lastBurstReset || Date.now()
    });
    return { success:true };
  }
  return { success:false, error: result?.reason || 'send failed' };
}

// ── Storage-based WA job dispatcher (resilient to channel close) ──
function dispatchWaJob(tabId, payload, timeoutMs = 90000) {
  return new Promise(async (resolve) => {
    const jobId = 'waj_' + Date.now() + '_' + Math.random().toString(36).slice(2,8);
    const resultKey = 'waJobResult_' + jobId;
    let settled = false;
    const finish = (res) => {
      if (settled) return;
      settled = true;
      try { chrome.storage.onChanged.removeListener(onChange); } catch(_){}
      try { chrome.storage.local.remove([resultKey]); } catch(_){}
      resolve(res);
    };
    const onChange = (chg, area) => {
      if (area !== 'local') return;
      if (chg[resultKey] && chg[resultKey].newValue) {
        finish(chg[resultKey].newValue);
      }
    };
    chrome.storage.onChanged.addListener(onChange);

    // Re-resolve a valid WA tab (tabId may be stale → "No tab with id")
    let resolvedTabId = tabId;
    if (!(await tabExists(resolvedTabId))) {
      const t = await findWhatsAppTab();
      if (!t) { return finish({ success:false, reason:'WhatsApp tab not found' }); }
      resolvedTabId = t.id;
      waTabId = t.id;
    }

    // Fire the message — ignore reply / channel-closed errors entirely.
    const sendPayload = {
      action: 'WA_SEND_MESSAGE',
      jobId, phone: payload.phone, text: payload.text, typingMs: payload.typingMs,
      attachDataUrl: payload.attachDataUrl || null,
      attachMeta:    payload.attachMeta    || null,
    };
    try {
      chrome.tabs.sendMessage(resolvedTabId, sendPayload).catch(() => {});
    } catch(e) {
      try {
        await chrome.scripting.executeScript({ target:{ tabId: resolvedTabId }, files:['wa-content.js'] });
        chrome.tabs.sendMessage(resolvedTabId, sendPayload).catch(()=>{});
      } catch(_){}
    }

    setTimeout(() => finish({ success:false, reason:'Send timeout (90s)' }), timeoutMs);
  });
}

async function sendEmailMessage(lead, settings) {
  if (!lead.email || lead.email === '—') {
    return { success: false, error: 'No email address' };
  }

  // Fill templates
  const subject = fillTemplate(settings.emailSubject, lead);
  const body    = fillTemplate(settings.emailBody, lead);

  try {
    const token = await getValidGmailAccessToken();
    if (!token) return { success: false, error: 'Gmail not connected' };
    return await sendGmailDirect({
      to: lead.email, subject, body, token,
      senderName:  settings.senderName  || '',
      senderEmail: settings.senderEmail || '',
      attachDataUrl: settings.emailAttachDataUrl || null,
      attachMeta:    settings.emailAttachMeta    || null,
    });
  } catch (error) {
    return { success: false, error: error.message };
  }
}

// ── Gmail access-token (implicit grant via chrome.identity.launchWebAuthFlow in popup) ──
// Background can't run interactive auth, so it returns the cached token if still valid.
// On 401 the popup will re-auth on next open via ensureGmailToken().
async function getValidGmailAccessToken() {
  const d = await new Promise(r => chrome.storage.local.get(
    ['gmailToken', 'gmailTokenExpiry', 'gmailAccessTokenExpiry'], r
  ));
  const exp = d.gmailTokenExpiry || d.gmailAccessTokenExpiry || 0;
  const now = Date.now();
  if (d.gmailToken && exp && exp - 60000 > now) return d.gmailToken;
  // Token missing/expired — flag for popup to re-auth
  chrome.storage.local.set({ gmailNeedsReauth: true });
  return d.gmailToken || null;
}

// Send via Gmail API (RFC 2822 base64-url)
async function sendGmailDirect({ to, subject, body, token, senderName, senderEmail, attachDataUrl, attachMeta }) {
  try {
    let fromName = senderName || '';
    let fromEmail = senderEmail || '';
    if (!fromEmail) {
      try {
        const u = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
          headers: { Authorization: `Bearer ${token}` }
        }).then(r => r.json());
        fromEmail = u.email || '';
        fromName  = fromName || u.name || (fromEmail.split('@')[0]);
      } catch (e) { /* ignore */ }
    }

    const subjB64 = btoa(unescape(encodeURIComponent(subject))).replace(/=+$/,'');
    const bodyB64 = btoa(unescape(encodeURIComponent(body))).replace(/(.{76})/g, '$1\n');
    const fromHeader = fromEmail ? `From: ${fromName} <${fromEmail}>` : 'From: me';

    const hasAttach = !!(attachDataUrl && attachMeta);

    let lines;
    if (!hasAttach) {
      lines = [
        fromHeader,
        `To: ${to}`,
        `Subject: =?UTF-8?B?${subjB64}?=`,
        'MIME-Version: 1.0',
        'Content-Type: text/plain; charset=UTF-8',
        'Content-Transfer-Encoding: base64',
        '',
        bodyB64
      ];
    } else {
      const boundary = 'LHP_' + Math.random().toString(36).slice(2, 14);
      const base64Data = (attachDataUrl.split(',')[1] || '').replace(/(.{76})/g, '$1\n');
      const mimeType   = attachMeta.type || 'application/octet-stream';
      const fileName   = attachMeta.name || 'attachment';
      lines = [
        fromHeader,
        `To: ${to}`,
        `Subject: =?UTF-8?B?${subjB64}?=`,
        'MIME-Version: 1.0',
        `Content-Type: multipart/mixed; boundary="${boundary}"`,
        '',
        `--${boundary}`,
        'Content-Type: text/plain; charset=UTF-8',
        'Content-Transfer-Encoding: base64',
        '',
        bodyB64,
        '',
        `--${boundary}`,
        `Content-Type: ${mimeType}; name="${fileName}"`,
        'Content-Transfer-Encoding: base64',
        `Content-Disposition: attachment; filename="${fileName}"`,
        '',
        base64Data,
        '',
        `--${boundary}--`,
      ];
    }
    const raw = btoa(unescape(encodeURIComponent(lines.join('\r\n'))))
      .replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');

    const res = await fetch('https://gmail.googleapis.com/gmail/v1/users/me/messages/send', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ raw })
    });
    const data = await res.json();
    if (data.id) return { success: true, id: data.id };
    return { success: false, error: data.error?.message || 'Gmail send failed' };
  } catch (e) {
    return { success: false, error: e.message };
  }
}

function fillTemplate(template, lead) {
  if (!template) return '';
  
  return template
    .replace(/\{\{name\}\}/gi, lead.name || '')
    .replace(/\{\{business\}\}/gi, lead.name || '')
    .replace(/\{\{phone\}\}/gi, lead.phone || '')
    .replace(/\{\{whatsapp\}\}/gi, lead.whatsapp || lead.phone || '')
    .replace(/\{\{email\}\}/gi, lead.email || '')
    .replace(/\{\{website\}\}/gi, lead.website || '')
    .replace(/\{\{address\}\}/gi, lead.address || '')
    .replace(/\{\{rating\}\}/gi, lead.rating || '')
    .replace(/\{\{category\}\}/gi, lead.category || '');
}

async function getMessagingSettings() {
  return new Promise((resolve) => {
    chrome.storage.local.get([
      'whatsappEnabled', 'whatsappToken', 'whatsappTemplate',
      'emailEnabled', 'emailSubject', 'emailBody',
      'senderName', 'senderEmail',
      'waAttachDataUrl', 'waAttachMeta',
      'emailAttachDataUrl', 'emailAttachMeta'
    ], (data) => {
      resolve({
        whatsappEnabled: data.whatsappEnabled !== false,
        whatsappToken: data.whatsappToken || '',
        whatsappTemplate: data.whatsappTemplate || '',
        emailEnabled: data.emailEnabled !== false,
        emailSubject: data.emailSubject || '',
        emailBody: data.emailBody || '',
        senderName: data.senderName || '',
        senderEmail: data.senderEmail || '',
        waAttachDataUrl:    data.waAttachDataUrl    || null,
        waAttachMeta:       data.waAttachMeta       || null,
        emailAttachDataUrl: data.emailAttachDataUrl || null,
        emailAttachMeta:    data.emailAttachMeta    || null
      });
    });
  });
}

async function recordMessageSent(type, lead) {
  // Record in daily stats
  const today = new Date().toISOString().split('T')[0];
  const key = `${type}Sent_${today}`;
  
  chrome.storage.local.get([key], (data) => {
    const count = (data[key] || 0) + 1;
    chrome.storage.local.set({ [key]: count });
  });
  
  // Also record in overall stats
  chrome.storage.local.get(['totalMessagesSent'], (data) => {
    const total = (data.totalMessagesSent || 0) + 1;
    chrome.storage.local.set({ totalMessagesSent: total });
  });
}

// ────────────────────────────────────────────────────────────
// WEBSITE EMAIL EXTRACTION WITH ANTI-DETECTION
// ────────────────────────────────────────────────────────────

// ✅ FIX (user request): visually open a real browser tab (background tab) like the
// original Lead Hunter extension — fetch() alone fails on JS-rendered sites and
// CORS-blocked hosts. We open a hidden tab, run an extractor, then close it.
async function extractEmailFromWebsite(websiteUrl) {
  console.log(`[Email Extract] Visiting site (tab mode): ${websiteUrl}`);

  if (!websiteUrl || !/^https?:\/\//i.test(websiteUrl)) {
    return { success: false, email: '—' };
  }

  // STAGE 1 — fast HTTP fetch (no tab) for static sites
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 5000);
    const r = await fetch(websiteUrl, {
      method: 'GET',
      signal: ctrl.signal,
      credentials: 'omit',
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
      }
    });
    clearTimeout(t);
    if (r.ok) {
      const html = await r.text();
      const e = extractBestEmailFromHTML(html);
      if (e && e !== '—') return { success: true, email: e };
    }
  } catch (_) { /* fall through to tab mode */ }

  // STAGE 2 — open real tab (background, inactive) and inject extractor
  return await fetchEmailViaTab(websiteUrl);
}

function fetchEmailViaTab(url) {
  return new Promise(async (resolve) => {
    let tab = null;
    const cleanup = () => { try { if (tab) chrome.tabs.remove(tab.id); } catch(e) {} };
    try {
      tab = await chrome.tabs.create({ url, active: false });
      // Wait until tab finishes loading (max 9s)
      await new Promise(res => {
        const start = Date.now();
        const check = () => {
          if (Date.now() - start > 9000) return res();
          chrome.tabs.get(tab.id, (t) => {
            if (chrome.runtime.lastError || !t) return res();
            if (t.status === 'complete') return setTimeout(res, 600);
            setTimeout(check, 350);
          });
        };
        check();
      });
      let email = '—';
      try {
        const out = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: function () {
            const text = (document.body && document.body.innerText) || '';
            const html = document.documentElement.innerHTML || '';
            const re = /[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,6}/g;
            const blocked = ['example.com','test.com','domain.com','email.com','yourname',
              'sentry.io','wixpress.com','googleapis.com','schema.org','w3.org',
              '@2x','.png','.jpg','.svg','.gif','sentry-cdn','cloudfront'];
            const all = [...new Set([...(text.match(re)||[]), ...(html.match(re)||[])])];
            const filtered = all.filter(e => {
              const l = e.toLowerCase();
              return !blocked.some(b => l.includes(b))
                && !l.startsWith('noreply')
                && !l.startsWith('no-reply')
                && !l.startsWith('donotreply')
                && e.length < 60;
            });
            const pri = filtered.find(e => /^(info|contact|hello|support|mail|admin|office|sales|hi)@/i.test(e));
            return pri || filtered[0] || '';
          }
        });
        email = (out && out[0] && out[0].result) ? String(out[0].result).toLowerCase() : '—';
      } catch (e) { /* page blocked scripting */ }
      cleanup();
      if (email && email.includes('@')) resolve({ success: true, email });
      else resolve({ success: false, email: '—' });
    } catch (err) {
      cleanup();
      resolve({ success: false, email: '—' });
    }
  });
}

function extractBestEmailFromHTML(html) {
  // Priority 1: mailto: links (most reliable)
  const mailtoMatch = html.match(/href=["']mailto:([^"'?#\s<>]+)/gi);
  if (mailtoMatch) {
    for (const match of mailtoMatch) {
      const email = match.replace(/href=["']mailto:/i, '').toLowerCase();
      if (isValidBusinessEmail(email)) return email;
    }
  }
  
  // Priority 2: Contact-style emails in text
  const emailPattern = /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g;
  const allEmails = (html.match(emailPattern) || [])
    .map(e => e.toLowerCase())
    .filter(isValidBusinessEmail);
  
  if (allEmails.length === 0) return '—';
  
  // Prefer business-style emails
  const businessPrefixes = ['info@', 'contact@', 'hello@', 'support@', 'sales@'];
  for (const prefix of businessPrefixes) {
    const businessEmail = allEmails.find(e => e.startsWith(prefix));
    if (businessEmail) return businessEmail;
  }
  
  return allEmails[0];
}

function isValidBusinessEmail(email) {
  if (!email || email.length > 80) return false;
  if (!/^[^\s@]+@[^\s@]+\.[a-zA-Z]{2,}$/.test(email)) return false;
  
  const blockedDomains = [
    'gmail.com', 'yahoo.com', 'hotmail.com', 'outlook.com',
    'google.com', 'example.com', 'test.com', 'localhost'
  ];
  
  const blockedPrefixes = [
    'noreply@', 'no-reply@', 'donotreply@', 'test@', 'admin@',
    'webmaster@', 'postmaster@', 'sample@', 'demo@'
  ];
  
  return !blockedDomains.some(domain => email.includes(domain)) &&
         !blockedPrefixes.some(prefix => email.startsWith(prefix));
}

// ────────────────────────────────────────────────────────────
// SYSTEM MONITORING & HEALTH CHECK
// ────────────────────────────────────────────────────────────

function setupSystemMonitoring() {
  // Health check every 5 minutes
  chrome.alarms.create('healthCheck', { periodInMinutes: 5 });
  
  // Session monitoring every minute
  chrome.alarms.create('sessionMonitor', { periodInMinutes: 1 });
  
  // Batch credit flush timer
  chrome.alarms.create('creditFlushCheck', { periodInMinutes: 0.5 }); // 30 seconds
}

chrome.alarms.onAlarm.addListener(async (alarm) => {
  switch (alarm.name) {
    case 'healthCheck':
      await performHealthCheck();
      break;
      
    case 'sessionMonitor':
      await monitorSession();
      break;
      
    case 'creditFlushCheck':
      if (creditBatch.pending > 0) {
        const timeWaiting = Date.now() - creditBatch.lastFlush;
        if (timeWaiting > creditBatch.MAX_WAIT_TIME) {
          await flushCreditBatch();
        }
      }
      break;
  }
});

async function performHealthCheck() {
  try {
    // Ping Supabase via simple settings query
    const r = await fetch(`${REST_URL}/settings?select=key&limit=1`, { headers: SB_HEADERS });
    const ok = r.ok;

    chrome.storage.local.set({
      lastHealthCheck: Date.now(),
      systemStatus: ok ? 'healthy' : 'degraded',
      apiConnectivity: ok,
    });

    console.log(`[Health] System status: ${ok ? 'healthy' : 'degraded'}`);

  } catch (error) {
    console.error('[Health] Health check failed:', error);
    chrome.storage.local.set({ systemStatus: 'degraded', apiConnectivity: false });
  }
}

async function monitorSession() {
  const sessionDuration = Date.now() - sessionData.startTime;
  const sessionHours = sessionDuration / (1000 * 60 * 60);
  
  console.log(`[Session] Duration: ${sessionHours.toFixed(1)}h, Actions: ${sessionData.totalActions}, Suspicion: ${Math.round(sessionData.suspiciousActivityScore)}`);
  
  // Auto-break if session is too long
  if (sessionDuration > HUMAN_TIMING.SESSION_MAX_DURATION) {
    console.log('[Session] Maximum session duration reached - forcing break');
    
    chrome.storage.local.set({
      stopRequested: true,
      scraping: false,
      statusMessage: 'Session limit reached - taking a break'
    });
    
    notifyAllTabs({ action: 'sessionLimitReached' });
  }
}

// ────────────────────────────────────────────────────────────
// MESSAGE HANDLERS
// ────────────────────────────────────────────────────────────

// ────────────────────────────────────────────────────────────
// CAMPAIGN LOOP — sends WhatsApp + Email with ban protection
// ────────────────────────────────────────────────────────────
async function startCampaignLoop(opts) {
  if (campaignRunning) { console.log('[Campaign] already running'); return; }
  campaignRunning = true;
  const leads = opts.leads || [];
  campaignStats = {
    sent:0, failed:0, pending: leads.length, total: leads.length,
    waSent:0, waFail:0, emSent:0, emFail:0,
  };
  await chrome.storage.local.set({
    campaignSent:0, campaignFail:0, campaignPend:leads.length,
    campaignTotal:leads.length, campaignLastLog:'Starting…',
    campaignWaSent:0, campaignWaFail:0,
    campaignEmSent:0, campaignEmFail:0,
    campaignRunning:true, campaignChannels:{
      wa: !!opts.waEnabled, em: !!opts.emailEnabled
    }
  });

  // ── Inject floating progress panel on active tab + WhatsApp tab ──
  await injectProgressPanelEverywhere({
    title: 'Lead Hunter — Campaign',
    sub:   `${leads.length} leads · ${[opts.waEnabled&&'WhatsApp', opts.emailEnabled&&'Email'].filter(Boolean).join(' + ')}`
  });

  const settings = {
    whatsappTemplate: opts.waTemplate || '',
    waTemplate:       opts.waTemplate || '',
    emailSubject:     opts.emailSubject || '',
    emailBody:        opts.emailBody || '',
    senderName:       opts.senderName || '',
    senderEmail:      opts.senderEmail || '',
    gmailToken:       opts.gmailToken  || '',
    waAttachDataUrl:  opts.waAttachDataUrl || null,
    waAttachMeta:     opts.waAttachMeta    || null,
    emailAttachDataUrl: opts.emailAttachDataUrl || null,
    emailAttachMeta:    opts.emailAttachMeta    || null,
  };
  // Persist user delay overrides
  const minDelay = Math.max(3000, (opts.waDelaySec || 8) * 1000);
  const maxDelay = Math.max(minDelay + 2000, (opts.waMaxDelaySec || Math.max(opts.waDelaySec || 8, 15)) * 1000);
  await chrome.storage.local.set({
    waMinDelay: minDelay, waMaxDelay: maxDelay,
    waTypingMs: opts.waTypingMs || 1500
  });

  // Per-lead messaged tracker (resets per campaign run).
  // 1 credit per lead that received at least one successful message
  // (WhatsApp + Email combined → still 1 credit).
  const messagedLeads = new Set();
  const licenseKey = opts.licenseKey || (await new Promise(r => chrome.storage.local.get(['licenseKey'], d => r(d.licenseKey || ''))));

  for (const lead of leads) {
    if (!campaignRunning) break;

    let log = '';
    let leadAnySuccess = false;
    const who = lead.name || lead.phone || '—';
    if (opts.waEnabled) {
      await chrome.storage.local.set({ campaignLastLog: `🔍 Searching: ${lead.phone || ''} (${who})…` });
      const r = await sendWhatsAppMessage(lead, settings);
      if (r.success) {
        campaignStats.sent++; campaignStats.waSent++;
        leadAnySuccess = true;
        log = `✅ WA sent → ${who} (${lead.phone||''})`;
      } else {
        campaignStats.failed++; campaignStats.waFail++;
        log = `❌ WA failed → ${who}: ${r.error}`;
      }
    }
    if (opts.emailEnabled && lead.email && lead.email !== '—') {
      await chrome.storage.local.set({ campaignLastLog: `📧 Sending email to ${who}…` });
      const r = await sendEmailMessage(lead, settings);
      if (r.success) {
        campaignStats.sent++; campaignStats.emSent++;
        leadAnySuccess = true;
        log += (log?' | ':'') + `✅ Email sent → ${lead.email}`;
      } else {
        campaignStats.failed++; campaignStats.emFail++;
        log += (log?' | ':'') + `❌ Email fail → ${lead.email}: ${r.error}`;
      }
    }

    // Bump unique-leads-messaged counter + deduct 1 credit per lead messaged
    if (leadAnySuccess) {
      const leadKey = (lead.phone || lead.email || lead.name || '').toString().trim().toLowerCase();
      if (leadKey && !messagedLeads.has(leadKey)) {
        messagedLeads.add(leadKey);
        await bumpMessagedLeadCounters();
        if (licenseKey) {
          try {
            const cr = await recordCreditUsage(licenseKey);
            if (cr && cr.error === 'insufficient_credits') {
              campaignRunning = false;
              await chrome.storage.local.set({ campaignLastLog: '❌ Credits exhausted — campaign stopped' });
              break;
            }
          } catch(e) { console.warn('[Campaign] credit deduction failed:', e); }
        }
      }
    }


    campaignStats.pending = Math.max(0, campaignStats.pending - 1);
    await chrome.storage.local.set({
      campaignSent: campaignStats.sent,
      campaignFail: campaignStats.failed,
      campaignPend: campaignStats.pending,
      campaignWaSent: campaignStats.waSent,
      campaignWaFail: campaignStats.waFail,
      campaignEmSent: campaignStats.emSent,
      campaignEmFail: campaignStats.emFail,
      campaignLastLog: log
    });

    // Human-like inter-message delay
    if (campaignRunning && campaignStats.pending > 0) {
      const d = await new Promise(r => chrome.storage.local.get(['waMinDelay','waMaxDelay'], r));
      const wait = gaussianDelay(d.waMinDelay || BAN_PROTECTION.minDelayMs,
                                 d.waMaxDelay || BAN_PROTECTION.maxDelayMs);
      console.log(`[Campaign] waiting ${wait}ms`);
      await new Promise(r => setTimeout(r, wait));
    }
  }
  campaignRunning = false;
  try { await flushCreditBatch(); } catch(_){}
  console.log('[Campaign] finished', campaignStats);
}

// Lead-deduped Msgs Sent counter (totalMessagesSent / todayMessagesSent).
// Called once per lead that received at least one successful message.
function bumpMessagedLeadCounters() {
  return new Promise((resolve) => {
    const today = new Date().toISOString().split('T')[0];
    const todayKey = `messagedLeads_${today}`;
    chrome.storage.local.get(['totalMessagesSent', todayKey, 'lastMessagedDay'], (data) => {
      const total = (data.totalMessagesSent || 0) + 1;
      const todayCount = (data[todayKey] || 0) + 1;
      chrome.storage.local.set({
        totalMessagesSent: total,
        [todayKey]: todayCount,
        todayMessagesSent: todayCount,
        lastMessagedDay: today
      }, resolve);
    });
  });
}

// ────────────────────────────────────────────────────────────
// FLOATING PANEL INJECTION (any tab)
// ────────────────────────────────────────────────────────────
async function injectProgressPanelEverywhere(meta = {}) {
  const targets = new Set();

  // Active tab in current window
  try {
    const [active] = await chrome.tabs.query({ active:true, currentWindow:true });
    if (active && active.id && isInjectableUrl(active.url)) targets.add(active.id);
  } catch(e){}

  // WhatsApp Web tab(s)
  try {
    const waTabs = await chrome.tabs.query({ url: 'https://web.whatsapp.com/*' });
    for (const t of waTabs) if (t.id) targets.add(t.id);
  } catch(e){}

  for (const tabId of targets) {
    try {
      await chrome.scripting.executeScript({
        target: { tabId },
        files:  ['progress-panel.js']
      });
      if (meta && (meta.title || meta.sub)) {
        chrome.tabs.sendMessage(tabId, {
          action:'LHP_PANEL_META', title: meta.title, sub: meta.sub
        }).catch(()=>{});
      }
    } catch(e) {
      console.warn('[Panel] inject failed for tab', tabId, e.message);
    }
  }
}

function isInjectableUrl(url) {
  if (!url) return false;
  return /^https?:\/\//.test(url) || /^file:\/\//.test(url);
}

// Re-inject panel if the user switches tabs while a campaign is running
chrome.tabs.onActivated.addListener(async ({ tabId }) => {
  if (!campaignRunning) return;
  try {
    const t = await chrome.tabs.get(tabId);
    if (!isInjectableUrl(t.url)) return;
    await chrome.scripting.executeScript({
      target: { tabId }, files: ['progress-panel.js']
    });
  } catch(e){}
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const handleAsync = async () => {
    try {
      switch (message.action) {
        case 'verifyLicense':
          const licenseResult = await verifyLicense(message.licenseKey);
          sendResponse(licenseResult);
          break;
          
        case 'deductCredit':
          const creditResult = await recordCreditUsage(message.licenseKey);
          sendResponse(creditResult);
          break;
          
        case 'queueLead':
          await queueLeadForMessaging(message.lead, message.messageTypes || ['whatsapp', 'email']);
          sendResponse({ success: true });
          break;
          
        case 'extractEmailFromWebsite':
          const emailResult = await extractEmailFromWebsite(message.url);
          sendResponse(emailResult);
          break;

        case 'fetchWebsite': {
          // Leadoutfy-compatible alias
          const r = await extractEmailFromWebsite(message.url);
          sendResponse({ email: r.email || '—' });
          break;
        }
          
        case 'getSystemStatus':
          const status = {
            sessionDuration: Date.now() - sessionData.startTime,
            totalActions: sessionData.totalActions,
            suspiciousScore: Math.round(sessionData.suspiciousActivityScore),
            queueSizes: {
              whatsapp: messageQueues.whatsapp.length,
              email: messageQueues.email.length
            },
            creditBatch: {
              pending: creditBatch.pending,
              lastFlush: creditBatch.lastFlush
            }
          };
          sendResponse({ success: true, status });
          break;
          
        case 'flushCredits':
          const flushResult = await flushCreditBatch();
          sendResponse(flushResult);
          break;

        case 'sendGmailEmail': {
          const r = await sendGmailDirect({
            to:      message.to,
            subject: message.subject,
            body:    message.body,
            token:   message.token
          });
          sendResponse(r);
          break;
        }

        // ── WhatsApp Web ───────────────────────────────────
        case 'connectWhatsApp': {
          const r = await checkWhatsAppReady();
          if (!r.hasTab) { await openWhatsAppWebTab(); }
          const r2 = await checkWhatsAppReady();
          sendResponse({ success:r2.ready, connected:r2.ready, hasTab:true });
          break;
        }
        case 'disconnectWhatsApp':
          waTabId = null; waReady = false;
          await chrome.storage.local.set({ waConnected:false });
          sendResponse({ success:true });
          break;
        case 'waCheckReady':
          sendResponse(await checkWhatsAppReady());
          break;
        case 'openWhatsAppWeb':
          sendResponse(await openWhatsAppWebTab());
          break;
        case 'WA_STATUS_PUSH': {
          waReady = !!message.ready;
          if (sender.tab) waTabId = sender.tab.id;
          chrome.storage.local.set({ waConnected: waReady });
          sendResponse({ ok:true });
          break;
        }

        // ── Campaign control ───────────────────────────────
        case 'startCampaign':
          startCampaignLoop(message);
          sendResponse({ success:true });
          break;
        case 'stopCampaign':
          campaignRunning = false;
          chrome.storage.local.set({ campaignRunning:false });
          sendResponse({ success:true });
          break;
        case 'getCampaignStatus':
          sendResponse({ success:true, ...campaignStats, running: campaignRunning });
          break;

        // ── Logs ───────────────────────────────────────────
        case 'getWaLogs':
          sendResponse({ success:true, logs: await getLogs(message.limit || 500) });
          break;
        case 'clearWaLogs':
          await clearLogs();
          sendResponse({ success:true });
          break;
        case 'getWaCounters': {
          const today = new Date().toDateString();
          const hourKey = new Date().toISOString().slice(0,13);
          const d = await new Promise(r => chrome.storage.local.get(
            ['waDailyCount','waDailyDate','waHourlyCount','waHourlyHour','waDailyLimit','waHourlyLimit'], r));
          sendResponse({
            success:true,
            dailyCount:  d.waDailyDate === today ? (d.waDailyCount  || 0) : 0,
            hourlyCount: d.waHourlyHour === hourKey ? (d.waHourlyCount || 0) : 0,
            dailyLimit:  d.waDailyLimit  || BAN_PROTECTION.dailyLimit,
            hourlyLimit: d.waHourlyLimit || BAN_PROTECTION.hourlyLimit
          });
          break;
        }

        default:
          sendResponse({ success: false, error: 'Unknown action' });
      }
    } catch (error) {
      console.error('[Message Handler] Error:', error);
      sendResponse({ success: false, error: error.message });
    }
  };
  
  handleAsync();
  return true; // Indicate async response
});

// ────────────────────────────────────────────────────────────
// UTILITY FUNCTIONS
// ────────────────────────────────────────────────────────────

async function notifyAllTabs(message) {
  try {
    const tabs = await chrome.tabs.query({ url: '*://www.google.com/maps/*' });
    for (const tab of tabs) {
      chrome.tabs.sendMessage(tab.id, message).catch(() => {}); // Ignore errors
    }
  } catch (error) {
    console.error('[Notify] Error notifying tabs:', error);
  }
}

// ────────────────────────────────────────────────────────────
// INITIALIZATION
// ────────────────────────────────────────────────────────────

chrome.runtime.onInstalled.addListener(() => {
  console.log('[Lead Hunter Pro] Background service worker initialized v2.0');
  
  // Initialize storage
  chrome.storage.local.set({
    leads: [],
    scraping: false,
    stopRequested: false,
    creditsRemaining: 0,
    systemStatus: 'initializing',
    sessionStarted: Date.now()
  });
  
  // Setup monitoring
  setupSystemMonitoring();
});

// Reset session data on startup
chrome.runtime.onStartup.addListener(() => {
  sessionData = {
    startTime: Date.now(),
    totalActions: 0,
    lastAction: 0,
    breakssTaken: 0,
    suspiciousActivityScore: 0,
    rateLimit: {
      apiCalls: [],
      creditDeductions: []
    }
  };
  
  console.log('[Lead Hunter Pro] Session reset - new session started');
});

console.log('[Lead Hunter Pro] Background service worker loaded ✅');
