'use strict';

// ══════════════════════════════════════════
// CONFIG & STATE — Supabase Direct Mode
// ══════════════════════════════════════════
const SUPABASE_URL  = 'https://vrtjopgjwlzogicmtade.supabase.co';
const SUPABASE_ANON = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZydGpvcGdqd2x6b2dpY210YWRlIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzc2NTA2ODMsImV4cCI6MjA5MzIyNjY4M30.TCDk_o8a3fPo0LxXFRncT51E6E5SJwvVOQemJthkI_k';
const REST_URL = SUPABASE_URL + '/rest/v1';
const SB_HDR = {
  'apikey': SUPABASE_ANON,
  'Authorization': 'Bearer ' + SUPABASE_ANON,
  'Content-Type': 'application/json',
};

// Sensitive ops now go through server-side Edge Functions; the extension
// never writes users/payments/credits directly.
const FUNCTIONS_URL = SUPABASE_URL + '/functions/v1';
async function callFn(name, payload) {
  try {
    const r = await fetch(`${FUNCTIONS_URL}/${name}`, {
      method: 'POST', headers: SB_HDR, body: JSON.stringify(payload || {}),
    });
    return await r.json().catch(() => ({ success: false, error: 'bad_response' }));
  } catch (e) {
    return { success: false, error: 'network_error' };
  }
}

// Legacy URL kept for fallback
const API = SUPABASE_URL;  // Backwards compat for existing fetch() calls
// WhatsApp now uses DOM injection on web.whatsapp.com — no external server.
const EMAIL_API = '';  // Not used in Supabase-direct mode
const VARS = ['{{name}}','{{phone}}','{{business}}','{{rating}}','{{address}}','{{email}}','{{website}}','{{category}}'];
const STEPS = ['Home','Hunt','Leads','Campaign','Send','Export'];
const DELAY_MAP = {1:{min:1000,max:3000,label:'Fast'},2:{min:3000,max:6000,label:'Medium'},3:{min:6000,max:12000,label:'Slow'}};
const KW_SUGGESTIONS = ['Restaurant','Dentist','Hotel','Lawyer','Gym','Pharmacy','School','Salon'];

// Runtime state
let curStep = 0;
let leads = [];
let selectedLeads = new Set();
let filters = { phone:false, email:false, web:false };
let channels = { wa:false, em:false };
let waConnected = false, waToken = '', waPhone = '';
let gmailConnected = false, gmailToken = '', gmailAddr = '';
let gmailClientId = '';
let gmailClientSecret = '';
let gmailRefreshToken = '';
let scraping = false, campaignRunning = false;
let settings = {};
let licenseKey = '';
let licenseData = {};
let selectedPlan = null;
let selectedMethod = 'bkash';
let pendingTxnId = '';
let crmLeads = [];
let sendStats = { sent:0, fail:0, pend:0, total:0 };
let campaignActive = false;
let campaignLeads = [];

// Lead folder system
let folders = {};            // { folderId: { id, name, leadIds: [] } }
let activeFolderFilter = ''; // '' = all
let importedRows = [];       // staged for import

// ══════════════════════════════════════════
// CHROME STORAGE HELPERS
// ══════════════════════════════════════════
function sGet(keys) {
  return new Promise(r => {
    if (typeof chrome !== 'undefined' && chrome.storage)
      chrome.storage.local.get(keys, r);
    else r({});
  });
}
function sSet(obj) {
  return new Promise(r => {
    if (typeof chrome !== 'undefined' && chrome.storage)
      chrome.storage.local.set(obj, r);
    else r();
  });
}
function sendBg(msg) {
  return new Promise(r => {
    if (typeof chrome !== 'undefined' && chrome.runtime)
      chrome.runtime.sendMessage(msg, res => r(res || {}));
    else r({});
  });
}

// ══════════════════════════════════════════
// INIT
// ══════════════════════════════════════════
async function init() {
  // Load persisted state
  const d = await sGet([
    'licenseKey','licenseData','creditsRemaining',
    'leads','huntedPhones','crmLeads',
    'waToken','waConnected','waPhone',
    'gmailToken','gmailConnected','gmailAddr',
    'gmailClientId','gmailClientSecret','gmailRefreshToken',
    'waMsgTemplate','gmailSubject','gmailBody',
    'waDelaySec','emailDelaySec',
    'country','scrapeDelay',
    'skipNoPhone','skipNoEmail','skipNoWebsite','findEmailFromWeb',
    'waAutoSend','gmailAutoSend',
    'webhookUrl',
    'totalLeadsCollected','todayLeadsCollected','totalMessagesSent','todayMessagesSent',
    'settings','selectedPlan','folders','activeFolderFilter'
  ]);

  licenseKey  = d.licenseKey  || '';
  licenseData = d.licenseData || {};
  leads       = d.leads       || [];
  folders     = d.folders     || {};
  activeFolderFilter = d.activeFolderFilter || '';
  crmLeads    = d.crmLeads    || [];
  waToken     = d.waToken     || '';
  waConnected = d.waConnected || false;
  waPhone     = d.waPhone     || '';
  gmailToken  = d.gmailToken  || '';
  gmailConnected = d.gmailConnected || false;
  gmailAddr   = d.gmailAddr   || '';
  gmailClientId = d.gmailClientId || '';
  gmailClientSecret = d.gmailClientSecret || '';
  gmailRefreshToken = d.gmailRefreshToken || '';

  // Restore settings
  if (d.settings) settings = d.settings;

  // Restore form values
  if (d.country)  { const el = document.getElementById('country'); if(el) el.value = d.country; }
  if (d.scrapeDelay) { const el = document.getElementById('delay-slider'); if(el) { el.value = d.scrapeDelay; setDelay(d.scrapeDelay); } }
  if (d.skipNoPhone)   toggleElState('tog-phone',   true);
  if (d.skipNoEmail)   toggleElState('tog-email',   true);
  if (d.skipNoWebsite) toggleElState('tog-website', true);
  if (d.findEmailFromWeb) toggleElState('tog-find-email', true);
  
  if (d.waMsgTemplate) { const el = document.getElementById('wa-msg'); if(el) { el.value = d.waMsgTemplate; updateWAPreview(); } }
  if (d.gmailSubject)  { const el = document.getElementById('email-subject'); if(el) el.value = d.gmailSubject; }
  if (d.gmailBody)     { const el = document.getElementById('email-body'); if(el) { el.value = d.gmailBody; updateEmailPreview(); } }
  if (d.waDelaySec)  { const s = document.getElementById('wa-delay'); if(s) { s.value = d.waDelaySec; setWADelay(d.waDelaySec); } }
  if (d.emailDelaySec) { const s = document.getElementById('em-delay'); if(s) { s.value = d.emailDelaySec; setEMDelay(d.emailDelaySec); } }
  if (d.webhookUrl) { const el = document.getElementById('webhook-url'); if(el) el.value = d.webhookUrl; }

  // Update credits display
  updateCreditsDisplay(d.creditsRemaining);

  // Home stats
  document.getElementById('stat-total').textContent = fmtNum(d.totalLeadsCollected || leads.length);
  document.getElementById('stat-today').textContent = fmtNum(d.todayLeadsCollected || 0);
  document.getElementById('stat-sent').textContent  = fmtNum(d.totalMessagesSent   || 0);
  const stToday = document.getElementById('stat-sent-today');
  if (stToday) stToday.textContent = `Today: ${fmtNum(d.todayMessagesSent || 0)}`;

  // WA connect UI
  updateWAStatus();
  updateGmailStatus();

  // Leads table
  renderLeads();
  renderHomeRecent();
  updateExportCount();
  renderCRM();

  // Fetch fresh settings from server
  fetchSettings();

  // Verify license if exists
  if (licenseKey) {
    const cr = document.getElementById('credit-count');
    if (cr) cr.textContent = fmtNum(d.creditsRemaining ?? '?');
  }

  // Check if currently scraping
  const stateData = await sGet(['scraping','stopRequested','statusText','huntedPhones']);
  if (stateData.scraping && !stateData.stopRequested) {
    showHuntStatus(true);
    startStoragePolling();
  }

  // Update step nav
  renderStepNav();
}

// ══════════════════════════════════════════
// SETTINGS
// ══════════════════════════════════════════
async function fetchSettings() {
  try {
    const r1 = await fetch(`${REST_URL}/settings?select=key,value`, { headers: SB_HDR });
    const rows = await r1.json();
    const s = {};
    (rows || []).forEach(row => { s[row.key] = row.value; });

    const r2 = await fetch(`${REST_URL}/plans?is_active=eq.true&order=sort_order&select=*`, { headers: SB_HDR });
    const plans = await r2.json();

    settings = {
      bkash_number:  s.bkash_number  || '',
      nagad_number:  s.nagad_number  || '',
      rocket_number: s.rocket_number || '',
      bank_account:  s.bank_account  || '',
      max_daily_scrape:    parseInt(s.max_daily_scrape    || '500'),
      min_scrape_delay_ms: parseInt(s.min_scrape_delay_ms || '3000'),
      max_scrape_delay_ms: parseInt(s.max_scrape_delay_ms || '8000'),
      maintenance_mode:    s.maintenance_mode === 'true',
      plans: plans || [],
    };
    await sSet({ settings });
    buildPlanCards(plans || []);

    // Also update Plans panel with live data
    if (Array.isArray(plans)) obUpdatePlanCards(plans);

  } catch(e) { console.error('[fetchSettings]', e); buildPlanCards([]); }
}

// ══════════════════════════════════════════
// PLANS PANEL (STEP 99) — Onboarding Flow
// ══════════════════════════════════════════
let obSelectedPlan = null;
let obPayMethod    = 'bkash';
let obPendingTxn   = null;
let obPollTimer    = null;

function obInit() {
  // Load settings if not already loaded
  if (!settings.plans || settings.plans.length === 0) {
    fetchSettings();
  }
  // Check if pending payment
  sGet(['pendingPaymentTxn']).then(d => {
    if (d.pendingPaymentTxn) {
      obPendingTxn = d.pendingPaymentTxn;
      document.getElementById('ob-poll-txn').textContent = d.pendingPaymentTxn;
      obStartPollTimer();
      obShowView('ob-pending');
    } else {
      obShowView('ob-pricing');
    }
  });
  obSetProgress(25);
}

function obShowView(id) {
  ['ob-pricing','ob-payment','ob-pending','ob-activate'].forEach(v => {
    const el = document.getElementById(v);
    if (el) el.style.display = 'none';
  });
  const t = document.getElementById(id);
  if (t) t.style.display = 'flex';
  const prog = { 'ob-pricing':25,'ob-payment':60,'ob-pending':80,'ob-activate':50 };
  obSetProgress(prog[id] || 25);
}

function obSetProgress(pct) {
  const el = document.getElementById('ob-progress-fill');
  if (el) el.style.width = pct + '%';
}

// ── Plan overrides: force these values regardless of DB state ──
const PLAN_OVERRIDES = {
  trial:    { credits: 300 },
  basic:    { credits: 10000, price: 1350, name: 'Basic',      duration_days: 30, badge: '',         save_text: ''         },
  pro:      { credits: 20000, price: 2250, name: 'Premium',    duration_days: 30, badge: 'popular',  save_text: 'Save 20%' },
  lifetime: { credits: 50000, price: 4500, name: 'Pro Hunter', duration_days: 30, badge: 'best',     save_text: 'Save 50%' },
};
function applyPlanOverride(p) {
  if (p && p.slug && PLAN_OVERRIDES[p.slug]) Object.assign(p, PLAN_OVERRIDES[p.slug]);
  return p;
}

function obUpdatePlanCards(plans) {
  plans.forEach(p => {
    applyPlanOverride(p);
    const card = document.getElementById('ob-card-' + p.slug);
    if (!card) return;
    card.dataset.price   = p.price;
    card.dataset.credits = p.credits;
    card.dataset.planId  = p.id;
    if (p.name) card.dataset.name = p.name;
    if (p.slug === 'trial') {
      const desc = document.getElementById('ob-trial-desc');
      if (desc) desc.textContent = `${fmtNum(p.credits)} credits · ${p.duration_days || 3} days · Activates instantly`;
    }
    const priceEl = card.querySelector('[class*="pc-price"], .pc-price');
    if (priceEl) priceEl.textContent = '৳' + fmtNum(p.price);
  });
}

function obSelectPlan(card) {
  document.querySelectorAll('#ob-card-trial,#ob-card-basic,#ob-card-pro,#ob-card-lifetime').forEach(c => {
    c.style.borderColor = c.id === 'ob-card-trial'     ? 'rgba(34,197,94,.28)' :
                          c.id === 'ob-card-pro'       ? 'var(--or-glow)'      :
                          c.id === 'ob-card-lifetime'  ? 'rgba(168,85,247,.35)' : 'var(--gbr)';
    c.style.background  = c.id === 'ob-card-trial' ? 'linear-gradient(135deg,rgba(34,197,94,.10),rgba(241,98,50,.07))' : 'var(--gb)';
  });
  card.style.borderColor = card.id === 'ob-card-trial' ? 'rgba(34,197,94,.6)' : 'var(--or)';
  card.style.background  = card.id === 'ob-card-trial' ? 'rgba(34,197,94,.14)' : 'var(--or-dim)';

  const price   = parseInt(card.dataset.price)   || 0;
  const credits = parseInt(card.dataset.credits) || 0;
  const name    = card.dataset.name;
  const slug    = card.dataset.slug;
  const planId  = card.dataset.planId || slug;

  obSelectedPlan = { id: planId, slug, name, price, credits };

  // Show/hide trial user form
  const trialForm = document.getElementById('ob-trial-form');
  if (trialForm) trialForm.style.display = slug === 'trial' ? 'flex' : 'none';

  const sum = document.getElementById('ob-summary');
  if (sum) sum.style.display = 'flex';
  const sn = document.getElementById('ob-sum-name');    if(sn) sn.textContent = name;
  const sc = document.getElementById('ob-sum-credits'); if(sc) sc.textContent = fmtNum(credits) + ' credits';
  const sp = document.getElementById('ob-sum-price');   if(sp) sp.textContent = price === 0 ? 'FREE' : '৳' + fmtNum(price);

  const btn = document.getElementById('ob-proceed-btn');
  if (btn) btn.style.display = 'block';
  const btxt = document.getElementById('ob-proceed-txt');
  if (btxt) btxt.textContent = price === 0 ? '🎁 Start Free Trial →' : 'Continue to Payment →';
}

function obProceed() {
  if (!obSelectedPlan) return;
  if (obSelectedPlan.price === 0) { obActivateTrial(); return; }
  // Setup payment view
  const pn = document.getElementById('ob-pay-plan-name');    if(pn) pn.textContent = obSelectedPlan.name + ' Plan';
  const pc = document.getElementById('ob-pay-plan-credits'); if(pc) pc.textContent = fmtNum(obSelectedPlan.credits) + ' credits';
  const pp = document.getElementById('ob-pay-plan-price');   if(pp) pp.textContent = '৳' + fmtNum(obSelectedPlan.price);
  const pa = document.getElementById('ob-pay-amount');       if(pa) pa.textContent = '৳' + fmtNum(obSelectedPlan.price);
  const sa = document.getElementById('ob-step-amount');      if(sa) sa.textContent = '৳' + fmtNum(obSelectedPlan.price);
  obUpdatePayDisplay();
  obShowView('ob-payment');
}

function obShowPricing()  { obShowView('ob-pricing');  }
function obShowActivate() { obShowView('ob-activate'); }

function obSelectMethod(tab) {
  document.querySelectorAll('.ob-mtab').forEach(t => {
    t.style.background  = 'var(--gb)';
    t.style.borderColor = 'var(--gbr)';
    t.style.color       = 'var(--w60)';
  });
  tab.style.background  = 'var(--or-dim)';
  tab.style.borderColor = 'var(--or)';
  tab.style.color       = 'var(--or)';
  obPayMethod = tab.dataset.method;
  obUpdatePayDisplay();
}

function obUpdatePayDisplay() {
  const nums = {
    bkash:  settings.bkash_number  || '01XXXXXXXXX',
    nagad:  settings.nagad_number  || '01XXXXXXXXX',
    rocket: settings.rocket_number || '01XXXXXXXXX',
    bank:   settings.bank_account  || 'Contact support',
  };
  const labels = { bkash:'bKash', nagad:'Nagad', rocket:'Rocket', bank:'Bank Transfer' };
  const num = nums[obPayMethod] || '01XXXXXXXXX';
  const lbl = labels[obPayMethod] || 'bKash';
  const pn = document.getElementById('ob-pay-number'); if(pn) pn.textContent = num;
  const sn = document.getElementById('ob-step-number'); if(sn) sn.textContent = num;
  const st = document.getElementById('ob-step1-txt');
  if (st) st.innerHTML = `Open <strong style="color:#fff">${lbl}</strong> → Send Money`;
}

function obCopyNumber() {
  const num = document.getElementById('ob-pay-number')?.textContent || '';
  navigator.clipboard.writeText(num).then(() => {
    const btn = document.querySelector('[data-action="obCopyNumber()"]');
    if (btn) { btn.textContent = 'Copied!'; setTimeout(() => btn.textContent = 'Copy', 1500); }
  });
}

async function obActivateTrial() {
  // Validate name and WhatsApp
  const nameVal = document.getElementById('ob-trial-name')?.value?.trim();
  const waVal   = document.getElementById('ob-trial-wa')?.value?.trim();

  if (!nameVal || nameVal.length < 2) {
    flashInput('ob-trial-name');
    obShowStatus('ob-pricing-status', 'err', 'Please enter your full name.');
    return;
  }
  if (!waVal || waVal.length < 10) {
    flashInput('ob-trial-wa');
    obShowStatus('ob-pricing-status', 'err', 'Please enter your WhatsApp number.');
    return;
  }

  const btn = document.getElementById('ob-proceed-btn');
  if (btn) { btn.disabled = true; btn.textContent = '⏳ Setting up…'; }

  try {
    // Trial is now minted server-side (create-trial). The server decides
    // the key, credits, and status — and enforces one trial per phone.
    const res = await callFn('create-trial', { name: nameVal, phone: waVal });

    if (!res || res.success !== true) {
      const msg = res?.error === 'trial_already_used'
        ? 'This number has already used a free trial.'
        : res?.error === 'invalid_phone'
        ? 'Please enter a valid WhatsApp number.'
        : 'Trial setup failed. Please try again.';
      if (btn) { btn.disabled = false; btn.textContent = '🎁 Start Free Trial →'; }
      obShowStatus('ob-pricing-status', 'err', msg);
      return;
    }

    const key = res.license_key;
    licenseKey  = key;
    licenseData = {
      status:            'active',
      plan_name:         res.plan_name || 'Free Trial',
      plan_slug:         'trial',
      credits_remaining: res.credits_remaining,
      credits_total:     res.credits_remaining,
      credits_used:      0,
      activated_at:      new Date().toISOString(),
      expires_at:        res.expires_at,
    };

    await sSet({ licenseKey: key, licenseData, creditsRemaining: res.credits_remaining });
    updateCreditsDisplay(res.credits_remaining);
    obShowActivationSuccess(key, res.credits_remaining, 'Trial');

  } catch(e) {
    if (btn) { btn.disabled = false; btn.textContent = '🎁 Start Free Trial →'; }
    obShowStatus('ob-pricing-status', 'err', 'Trial setup failed: ' + e.message);
  }
}

async function obSubmitPayment() {
  const name  = document.getElementById('ob-inp-name')?.value?.trim();
  const phone = document.getElementById('ob-inp-phone')?.value?.trim();
  const txn   = document.getElementById('ob-inp-txn')?.value?.trim()?.replace(/\s/g, '');

  obHideStatus('ob-pay-status');
  if (!phone || phone.length < 10) {
    flashInput('ob-inp-phone');
    obShowStatus('ob-pay-status', 'err', 'Enter your phone number.');
    return;
  }
  if (!txn || txn.length < 5) {
    flashInput('ob-inp-txn');
    obShowStatus('ob-pay-status', 'err', 'Enter your Transaction ID.');
    return;
  }

  const btn = document.getElementById('ob-submit-btn');
  const txt = document.getElementById('ob-submit-txt');
  if (btn) btn.disabled = true;
  if (txt) txt.textContent = '⏳ Checking…';

  try {
    if (txt) txt.textContent = '⏳ Submitting…';

    // Server validates plan, forces pending status, guards duplicates.
    const res = await callFn('submit-payment', {
      customer_name:  name || null,
      customer_phone: phone,
      plan_id:        obSelectedPlan.id || null,
      payment_method: obPayMethod,
      transaction_id: txn,
    });

    if (!res || res.success !== true) {
      const msg = res?.error === 'duplicate'
        ? (res.status === 'approved' ? 'TrxID already approved.' : 'TrxID already under review.')
        : res?.error === 'invalid_plan' ? 'Invalid plan selected.'
        : res?.error === 'missing_fields' ? 'Please fill all fields.'
        : 'Submission failed. Try again.';
      obShowStatus('ob-pay-status', 'err', msg);
      if(btn) btn.disabled = false;
      if(txt) txt.textContent = 'Submit Payment';
      return;
    }

    obPendingTxn = txn;
    await sSet({ pendingPaymentTxn: txn, pendingPlanName: obSelectedPlan.name });

    document.getElementById('ob-poll-txn').textContent = txn;
    obStartPollTimer();
    obShowView('ob-pending');

  } catch(e) {
    obShowStatus('ob-pay-status', 'err', e.message || 'Connection error. Try again.');
  }

  if(btn) btn.disabled = false;
  if(txt) txt.textContent = 'Submit Payment';
}

async function obCheckStatus() {
  const txn = obPendingTxn || (await sGet(['pendingPaymentTxn'])).pendingPaymentTxn;
  if (!txn) { obShowStatus('ob-poll-status', 'err', 'No pending payment.'); return; }

  const btn = document.getElementById('ob-check-btn');
  if (btn) { btn.disabled = true; btn.textContent = '⏳ Checking…'; }
  obHideStatus('ob-poll-status');

  try {
    const res = await callFn('check-payment', { transaction_id: txn });

    if (!res || res.success !== true) {
      obShowStatus('ob-poll-status', 'err', 'Could not check status. Try again.');
      if(btn) { btn.disabled = false; btn.textContent = '🔄 Check Approval Status'; }
      return;
    }

    if (res.status === 'approved') {
      const licKey = res.license_key;
      const u = res.license;

      if (licKey && u) {
        const lic = {
          status:            'active',
          plan_name:         u.plan_name || 'Pro',
          plan_slug:         u.plan_slug || 'pro',
          credits_remaining: u.credits_remaining || 0,
          credits_total:     u.credits_total     || 0,
          credits_used:      u.credits_used      || 0,
          activated_at:      u.activated_at,
          expires_at:        u.expires_at,
        };
        licenseKey  = licKey;
        licenseData = lic;
        await sSet({ licenseKey: licKey, licenseData: lic, creditsRemaining: lic.credits_remaining, pendingPaymentTxn: null });
        clearInterval(obPollTimer);
        obShowActivationSuccess(licKey, lic.credits_remaining, lic.plan_name);
        return;
      }
      obShowStatus('ob-poll-status', 'ok', '✅ Approved! License activating… check again shortly.');

    } else if (res.status === 'rejected') {
      await sSet({ pendingPaymentTxn: null });
      obPendingTxn = null;
      obShowStatus('ob-poll-status', 'err', '❌ Rejected: ' + (res.reason || 'Contact support.'));
      setTimeout(() => obShowView('ob-pricing'), 3000);

    } else {
      obShowStatus('ob-poll-status', 'warn', '⏳ Still pending. Admin will verify within 24 hours.');
    }
  } catch(e) {
    obShowStatus('ob-poll-status', 'err', 'Connection error: ' + e.message);
  }

  if(btn) { btn.disabled = false; btn.textContent = '🔄 Check Approval Status'; }
}

async function obActivateLicense() {
  const key = (document.getElementById('ob-lic-input')?.value || '').trim().toUpperCase().replace(/[^A-Z0-9-]/g, '');
  if (!key || key.length < 8) {
    flashInput('ob-lic-input');
    obShowStatus('ob-lic-status', 'err', 'Enter a valid license key.');
    return;
  }

  const btn = document.getElementById('ob-activate-btn');
  const txt = document.getElementById('ob-activate-txt');
  if(btn) btn.disabled = true;
  if(txt) txt.textContent = '⏳ Verifying…';
  obHideStatus('ob-lic-status');

  try {
    const res = await callFn('license-verify', { license_key: key });

    if (!res || res.success !== true) {
      const map = {
        license_key_not_found: '❌ License key not found.',
        account_suspended:     '❌ License suspended. Contact support.',
        payment_pending:       '⏳ Payment pending — credits added within 24h.',
        connection_failed:     'Connection failed.',
        network_error:         'Connection failed.',
      };
      const isWarn = res?.error === 'payment_pending';
      obShowStatus('ob-lic-status', isWarn ? 'warn' : 'err', map[res?.error] || 'Verification failed.');
      if(btn) btn.disabled = false; if(txt) txt.textContent = 'Activate Now →'; return;
    }

    const l = res.license;
    const lic = {
      status:            l.status,
      plan_name:         l.plan_name || l.plan_slug || 'Active',
      plan_slug:         l.plan_slug,
      credits_remaining: l.credits_remaining || 0,
      credits_total:     l.credits_total     || 0,
      credits_used:      l.credits_used      || 0,
      activated_at:      l.activated_at,
      expires_at:        l.expires_at,
    };

    licenseKey  = key;
    licenseData = lic;
    await sSet({ licenseKey: key, licenseData: lic, creditsRemaining: lic.credits_remaining });
    updateCreditsDisplay(lic.credits_remaining);

    obShowActivationSuccess(key, lic.credits_remaining, lic.plan_name);

  } catch(e) {
    obShowStatus('ob-lic-status', 'err', 'Connection error: ' + e.message);
  }
  if(btn) btn.disabled = false; if(txt) txt.textContent = 'Activate Now →';
}

function obShowActivationSuccess(key, credits, planName) {
  // Replace pricing view with a success card
  const pricingEl = document.getElementById('ob-pricing');
  if (pricingEl) {
    pricingEl.style.display = 'flex';
    pricingEl.innerHTML = `
      <div style="text-align:center;padding:20px 0">
        <div style="font-size:52px;margin-bottom:12px;animation:fadeIn .4s both">🎉</div>
        <div style="font-family:var(--font-d);font-size:20px;font-weight:800;margin-bottom:6px">You're all set!</div>
        <div style="font-size:12px;color:var(--w60);margin-bottom:18px">Lead Hunter Pro is activated and ready.</div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:16px">
          <div style="background:var(--gb);border:1px solid var(--gbr);border-radius:10px;padding:10px">
            <div style="font-family:var(--font-d);font-size:18px;font-weight:800;color:var(--or)">${fmtNum(credits)}</div>
            <div style="font-size:10px;color:var(--w60);text-transform:uppercase;letter-spacing:.06em">Credits</div>
          </div>
          <div style="background:var(--gb);border:1px solid var(--gbr);border-radius:10px;padding:10px">
            <div style="font-family:var(--font-d);font-size:14px;font-weight:800;color:var(--or)">${esc(planName)}</div>
            <div style="font-size:10px;color:var(--w60);text-transform:uppercase;letter-spacing:.06em">Plan</div>
          </div>
        </div>
        <div style="background:var(--bk2);border:1px solid var(--gbr);border-radius:9px;padding:8px 12px;display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:16px">
          <span style="font-family:monospace;font-size:11px;font-weight:700;color:var(--or-l);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(key)}</span>
          <span id="ob-copy-key-btn" data-action="obCopyKey()" style="padding:3px 9px;border-radius:999px;background:var(--or-dim);border:1px solid var(--or-glow);color:var(--or);font-size:10px;font-weight:800;cursor:pointer;flex-shrink:0">Copy</span>
        </div>
        <button class="btn-cta" data-action="obLaunch()" style="width:100%;font-size:13px">
          🚀 Start Hunting Leads →
        </button>
      </div>`;
  }
  obSetProgress(100);
  updateCreditsDisplay(credits);
}

function obCopyKey() {
  const panels = document.getElementById('panel-99');
  const mono   = panels?.querySelector('span[style*="monospace"]');
  if (mono) navigator.clipboard.writeText(mono.textContent.trim()).then(() => {
    const btn = document.getElementById('ob-copy-key-btn');
    if (btn) { btn.textContent = 'Copied!'; setTimeout(() => btn.textContent = 'Copy', 1500); }
  });
}

function obLaunch() {
  // Go to Home tab (step 0)
  goStep(0);
  // Refresh credits and stats
  refreshCredits();
  renderHomeRecent();
}

function obStartPollTimer() {
  const t0 = Date.now();
  clearInterval(obPollTimer);
  obPollTimer = setInterval(() => {
    const s  = Math.floor((Date.now() - t0) / 1000);
    const el = document.getElementById('ob-poll-timer');
    if (el) el.textContent = `Waiting… (${Math.floor(s/60)}m ${s%60}s)`;
  }, 1000);
}

function obShowStatus(boxId, type, msg) {
  const box = document.getElementById(boxId);
  if (!box) return;
  const icons = { ok:'✅', err:'❌', warn:'⚠️', inf:'ℹ️' };
  box.className = `status-box ${type} show`;
  box.querySelector('.si').textContent = icons[type] || 'ℹ️';
  const msgEl = box.querySelector('[id$="-msg"]') || box.querySelector('span:last-child');
  if (msgEl) msgEl.textContent = msg;
}
function obHideStatus(boxId) {
  const box = document.getElementById(boxId);
  if (box) box.className = 'status-box';
}

// ══════════════════════════════════════════
// STEP NAVIGATION
// ══════════════════════════════════════════
function goStep(n) {
  // Allow string expressions like "curStep+1" / "curStep-1" coming from data-action
  if (typeof n === 'string') {
    const m = n.match(/^curStep\s*([+\-])\s*(\d+)$/);
    if (m) {
      n = (m[1] === '+') ? curStep + parseInt(m[2]) : curStep - parseInt(m[2]);
    } else {
      n = parseInt(n);
    }
  }
  // Step 99 = Plans panel (special); 0..6 = main flow
  const validSteps = [99, 0, 1, 2, 3, 4, 5, 6];
  if (!validSteps.includes(n)) return;

  // If trying to go to steps 0-5 but no license → redirect to Plans
  if (n !== 99 && !licenseKey) {
    goStep(99);
    return;
  }

  const panels = document.querySelectorAll('.panel');
  panels.forEach(p => p.classList.remove('active'));
  const target = document.getElementById(`panel-${n}`);
  if (target) target.classList.add('active');
  curStep = n;
  renderStepNav();
  updateFooter();

  // Panel-specific actions
  if (n === 2) { renderLeads(); updateExportCount(); }
  if (n === 3) { renderCampaignFolderSelect(); }
  if (n === 4) { updateSendSummary(); renderCampaignFolderSelect(); }
  if (n === 5) { renderCRM(); updateExportCount(); }
  if (n === 0) { renderHomeRecent(); }
  if (n === 99) { obInit(); }
}

function renderStepNav() {
  const items = document.querySelectorAll('.snav-item');
  // Plans tab is index 0 in DOM (step 99), then Home=1, Hunt=2...
  items.forEach(item => {
    const step = parseInt(item.dataset.step);
    item.classList.remove('active', 'done');
    if (step === curStep) {
      item.classList.add('active');
    } else if (step !== 99 && curStep !== 99) {
      const stepOrder = [0, 1, 2, 3, 4, 5, 6];
      const curIdx  = stepOrder.indexOf(curStep);
      const itemIdx = stepOrder.indexOf(step);
      if (itemIdx < curIdx) item.classList.add('done');
    }
  });
  const labelMap = { 99:'Plans', 0:'Home', 1:'Hunt', 2:'Leads', 3:'Campaign', 4:'Send', 5:'Export', 6:'Guide' };
  document.getElementById('step-ind').textContent = labelMap[curStep] || '';
}

function updateFooter() {
  const prev = document.getElementById('prev-btn');
  const next = document.getElementById('next-btn');
  if (prev) prev.disabled = (curStep === 99 || curStep === 0);
  if (next) {
    next.disabled = (curStep === 6 || curStep === 99);
    next.textContent = curStep === 4 ? '→ Export' : curStep === 5 ? '📖 Guide' : curStep === 6 ? '✓ Done' : 'Next →';
  }
}

// ══════════════════════════════════════════
// HUNT (STEP 1)
// ══════════════════════════════════════════
function setKw(kw) { document.getElementById('keyword').value = kw; }

function toggleAdv() {
  const t = document.getElementById('adv-toggle');
  const b = document.getElementById('adv-body');
  t.classList.toggle('open');
  b.classList.toggle('open');
}

function setDelay(v) {
  const map = DELAY_MAP[v] || DELAY_MAP[2];
  document.getElementById('delay-lbl').textContent = map.label;
  document.getElementById('delay-desc').textContent = `Human-like delay: ${map.min/1000}s – ${map.max/1000}s`;
}

async function startHunt() {
  const keyword = document.getElementById('keyword').value.trim();
  const country  = document.getElementById('country').value;
  const city     = document.getElementById('city').value.trim();
  const maxR     = parseInt(document.getElementById('max-slider').value) || 50;

  if (!keyword) { flashInput('keyword'); showHuntMsg('Please enter a keyword.', 'err'); return; }
  if (!licenseKey) { showHuntMsg('No license found. Please activate first.', 'err'); openAcct(); return; }

  // Credit check
  const cr = await sGet(['creditsRemaining']);
  if ((cr.creditsRemaining || 0) < 1) {
    showHuntMsg('No credits remaining. Please purchase a plan.', 'err'); return;
  }

  const searchQuery = [keyword, city, country].filter(Boolean).join(' ');
  const delayLevel  = parseInt(document.getElementById('delay-slider').value) || 2;
  const delayMap    = DELAY_MAP[delayLevel] || DELAY_MAP[2];

  await sSet({
    licenseKey,
    maxResults:    maxR,
    country,
    scrapeDelay:   delayMap.min + Math.random() * (delayMap.max - delayMap.min),
    skipNoPhone:   document.getElementById('tog-phone').classList.contains('on'),
    skipNoEmail:   document.getElementById('tog-email').classList.contains('on'),
    skipNoWebsite: document.getElementById('tog-website').classList.contains('on'),
    findEmailFromWeb: document.getElementById('tog-find-email')?.classList.contains('on') || false,
    autoStart:     true,
    leads:         [],
    scraping:      true,
    stopRequested: false,
    statusText:    '🔍 Initializing…',
  });

  scraping = true;
  leads = [];
  showHuntStatus(true);
  document.getElementById('hunt-count').textContent = `0/${maxR}`;
  document.getElementById('hunt-progress').style.width = '0%';
  document.getElementById('hunt-status-txt').textContent = '🔍 Opening Google Maps…';
  document.getElementById('start-hunt-btn').disabled = true;

  // Open Google Maps tab
  const url = `https://www.google.com/maps/search/${encodeURIComponent(searchQuery)}`;
  if (typeof chrome !== 'undefined' && chrome.tabs)
    chrome.tabs.create({ url });
  else window.open(url, '_blank');

  startStoragePolling();
}

function stopHunt() {
  sSet({ stopRequested: true, scraping: false });
  scraping = false;
  document.getElementById('start-hunt-btn').disabled = false;
  document.getElementById('hunt-view-btn').style.display = '';
  showHuntStatus(false);
}

function showHuntStatus(show) {
  const bar = document.getElementById('hunt-status-bar');
  if (bar) bar.classList.toggle('show', show);
}

let pollTimer = null;
function startStoragePolling() {
  if (pollTimer) clearInterval(pollTimer);
  pollTimer = setInterval(async () => {
    const d = await sGet(['leads','scraping','stopRequested','statusText','creditsRemaining']);
    if (d.leads && d.leads.length > 0) {
      leads = d.leads;
      const maxR = parseInt(document.getElementById('max-slider').value) || 50;
      const pct  = Math.min(100, (leads.length / maxR) * 100);
      document.getElementById('hunt-count').textContent    = `${leads.length}/${maxR}`;
      document.getElementById('hunt-progress').style.width = `${pct}%`;
      document.getElementById('hunt-status-txt').textContent = d.statusText || `✅ ${leads.length} leads collected`;
      document.getElementById('stat-today').textContent    = fmtNum(leads.length);
      document.getElementById('stat-total').textContent    = fmtNum(leads.length);
      renderHomeRecent();
    }
    updateCreditsDisplay(d.creditsRemaining);
    if (!d.scraping || d.stopRequested) {
      clearInterval(pollTimer);
      scraping = false;
      document.getElementById('start-hunt-btn').disabled = false;
      document.getElementById('hunt-view-btn').style.display = '';
      if (d.leads?.length > 0) {
        document.getElementById('hunt-status-txt').textContent = `✅ Done! ${d.leads.length} leads collected`;
      }
    }
  }, 1000);
}

function showHuntMsg(msg, type='inf') {
  const box = document.getElementById('hunt-status-box');
  if (!box) return;
  const icon = {ok:'✅',err:'❌',inf:'ℹ️',warn:'⚠️'}[type] || 'ℹ️';
  box.className = `status-box ${type} show`;
  box.querySelector('.si').textContent = icon;
  document.getElementById('hunt-status-msg').textContent = msg;
  setTimeout(() => box.classList.remove('show'), 4000);
}

// ══════════════════════════════════════════
// LEADS REVIEW (STEP 2)
// ══════════════════════════════════════════
function renderLeads(list = null) {
  const data = list || getFilteredLeads();
  renderFolderSelect();
  const tbody = document.getElementById('leads-tbody');
  if (!tbody) return;

  if (data.length === 0) {
    tbody.innerHTML = `
      <div class="empty-leads">
        <div class="empty-icon">${leads.length === 0 ? '📋' : '🔍'}</div>
        <div class="empty-title">${leads.length === 0 ? 'No leads collected' : 'No matches found'}</div>
        <div class="empty-sub">${leads.length === 0 ? 'Go to Hunt to collect leads first' : 'Try different filters'}</div>
      </div>`;
    return;
  }

  tbody.innerHTML = data.map(l => {
    const sel = selectedLeads.has(l._id);
    return `<div class="lt-row${sel?' selected':''}" data-action="toggleLead('${l._id}')" data-id="${l._id}">
      <div class="lt-check">${sel?'✓':''}</div>
      <div>
        <div class="lt-name">${esc(l.name || '—')}</div>
        <div style="font-size:10px;color:var(--w60)">${esc(l.category || '')}</div>
      </div>
      <div class="lt-phone">${esc(l.phone || '—')}</div>
      <div class="lt-rating">${l.rating && l.rating!=='—' ? '★ '+l.rating : '—'}</div>
      <div class="lt-icons">
        <span class="li${l.phone&&l.phone!=='—'?' on':''}" title="Phone">📱</span>
        <span class="li${l.email&&l.email!=='—'?' on':''}" title="Email">📧</span>
        <span class="li${l.website&&l.website!=='—'?' on':''}" title="Web">🌐</span>
      </div>
    </div>`;
  }).join('');
}

// Returns leads not assigned to any folder
function getUnfolderedLeads() {
  const folderedIds = new Set();
  Object.values(folders).forEach(f => (f.leadIds || []).forEach(id => folderedIds.add(id)));
  return leads.filter(l => l._id && !folderedIds.has(l._id));
}

function getFilteredLeads() {
  // ✅ Persist a stable _id on each lead so folder membership survives reorders
  let mutated = false;
  leads.forEach((l, i) => {
    if (!l._id) {
      l._id = 'l_' + Date.now().toString(36) + '_' + i + '_' + Math.random().toString(36).slice(2,6);
      mutated = true;
    }
  });
  if (mutated) sSet({ leads });

  let data;
  if (activeFolderFilter && folders[activeFolderFilter]) {
    const ids = new Set(folders[activeFolderFilter].leadIds || []);
    data = leads.filter(l => ids.has(l._id)).map(l => ({ ...l }));
  } else {
    // "All Leads" view = leads NOT in any folder
    data = getUnfolderedLeads().map(l => ({ ...l }));
  }

  const search = (document.getElementById('leads-search')?.value || '').toLowerCase();
  if (search) data = data.filter(l =>
    [l.name, l.phone, l.email, l.category, l.address].some(v => (v||'').toLowerCase().includes(search)));
  if (filters.phone)   data = data.filter(l => l.phone   && l.phone   !== '—');
  if (filters.email)   data = data.filter(l => l.email   && l.email   !== '—');
  if (filters.web)     data = data.filter(l => l.website && l.website !== '—');
  return data;
}

function filterLeads() { renderLeads(); }

function toggleFilter(type) {
  filters[type] = !filters[type];
  const el = document.getElementById(`fc-${type}`);
  if (el) el.classList.toggle('on', filters[type]);
  renderLeads();
}

function toggleLead(id) {
  if (selectedLeads.has(id)) selectedLeads.delete(id);
  else selectedLeads.add(id);
  renderLeads();
  updateBulkBar();
}

function updateBulkBar() {
  const bar = document.getElementById('bulk-bar');
  const cnt = document.getElementById('sel-count');
  if (!bar) return;
  if (selectedLeads.size > 0) { bar.style.display='flex'; if(cnt) cnt.textContent = selectedLeads.size; }
  else bar.style.display = 'none';
}

function selectAll() {
  getFilteredLeads().forEach(l => selectedLeads.add(l._id));
  renderLeads(); updateBulkBar();
}

function clearSelection() { selectedLeads.clear(); renderLeads(); updateBulkBar(); }

function useSelectedLeads() {
  campaignLeads = getFilteredLeads().filter(l => selectedLeads.has(l._id));
  if (campaignLeads.length === 0) return;
  goStep(3);
}

function proceedWithAll() {
  campaignLeads = getFilteredLeads();
  if (campaignLeads.length === 0) { showHuntMsg('No leads to use.','warn'); return; }
  goStep(3);
}

function clearLeads() {
  if (!confirm('Clear all collected leads?')) return;
  leads = []; selectedLeads.clear();
  sSet({ leads: [] });
  renderLeads(); renderHomeRecent(); updateExportCount();
}

function renderHomeRecent() {
  const el = document.getElementById('home-recent');
  if (!el) return;
  const recent = leads.slice(-5).reverse();
  if (recent.length === 0) {
    el.innerHTML = `<div class="empty-leads" style="padding:16px"><div class="empty-icon">📍</div><div class="empty-title">No leads yet</div><div class="empty-sub">Start a Hunt</div></div>`;
    return;
  }
  el.innerHTML = recent.map(l => `
    <div class="rl-row">
      <div class="rl-name">${esc(l.name||'—')}</div>
      <div class="rl-phone">${esc(l.phone||'—')}</div>
      <div class="rl-icons">
        <span title="Phone">${l.phone&&l.phone!=='—'?'📱':''}  </span>
        <span title="Email">${l.email&&l.email!=='—'?'📧':''}</span>
      </div>
    </div>`).join('');
}

// Import CSV
function importCSV() { document.getElementById('csv-file')?.click(); }

function handleCSV(input) {
  const file = input.files[0];
  if (!file) return;
  document.getElementById('csv-filename').textContent = file.name;
  const reader = new FileReader();
  reader.onload = e => {
    const lines = e.target.result.split('\n').filter(Boolean);
    if (lines.length < 2) return;
    const headers = lines[0].split(',').map(h => h.trim().toLowerCase().replace(/"/g,''));
    const imported = [];
    for (let i = 1; i < lines.length; i++) {
      const cols = lines[i].split(',').map(c => c.trim().replace(/^"|"$/g,''));
      const row = {};
      headers.forEach((h,j) => row[h] = cols[j] || '');
      imported.push({
        name:     row.name || row.business || row['business name'] || '—',
        phone:    row.phone || row['phone number'] || '—',
        email:    row.email || '—',
        website:  row.website || '—',
        address:  row.address || '—',
        rating:   row.rating || '—',
        category: row.category || '—',
      });
    }
    leads.push(...imported);
    sSet({ leads });
    renderLeads(); renderHomeRecent(); updateExportCount();
    showHuntMsg(`Imported ${imported.length} leads from CSV.`, 'ok');
  };
  reader.readAsText(file);
  input.value = '';
}

// ══════════════════════════════════════════
// CAMPAIGN BUILDER (STEP 3)
// ══════════════════════════════════════════
function toggleChannel(ch) {
  if (ch === 'both') {
    channels.wa = true; channels.em = true;
    updateChannelUI();
  } else {
    channels[ch] = !channels[ch];
    updateChannelUI();
  }
  updateBothButton();
}

function updateChannelUI() {
  ['wa','em'].forEach(ch => {
    const card  = document.getElementById(`ch-${ch}`);
    const check = document.getElementById(`ch-${ch}-check`);
    const sec   = document.getElementById(`${ch}-section`);
    if (card) card.classList.toggle('on', channels[ch]);
    if (check) check.textContent = channels[ch] ? '✓' : '';
    if (sec) sec.style.display = channels[ch] ? 'block' : 'none';
  });
  const empty = document.getElementById('ch-empty');
  if (empty) empty.style.display = (channels.wa || channels.em) ? 'none' : 'flex';
}

function updateBothButton() {
  const card  = document.getElementById('ch-both');
  const check = document.getElementById('ch-both-check');
  const on    = channels.wa && channels.em;
  if (card) { card.classList.toggle('on', on); card.style.opacity = '1'; card.style.pointerEvents = 'auto'; }
  if (check) check.textContent = on ? '✓' : '';
}

// WA — DOM injection mode (no QR, no external server)
function connectWA() {
  // Try to find an existing WA Web tab; otherwise open one.
  sendBg({ action:'connectWhatsApp' }).then(r => {
    if (r?.connected) {
      waConnected = true;
      sSet({ waConnected:true });
      updateWAStatus();
      showHuntMsg('WhatsApp Web connected ✓','ok');
    } else {
      sendBg({ action:'openWhatsAppWeb' });
      showHuntMsg('Opening WhatsApp Web — please log in if needed.','inf');
      // Poll readiness every 2s for 30s
      let n = 0;
      const t = setInterval(async () => {
        n++;
        const s = await sendBg({ action:'waCheckReady' });
        if (s?.ready) {
          clearInterval(t);
          waConnected = true;
          sSet({ waConnected:true });
          updateWAStatus();
          showHuntMsg('WhatsApp Web connected ✓','ok');
        } else if (n > 15) clearInterval(t);
      }, 2000);
    }
  });
}

function disconnectWA() {
  sendBg({ action: 'disconnectWhatsApp' }).then(() => {
    waConnected = false;
    sSet({ waConnected:false });
    updateWAStatus();
  });
}

// Auto-poll status (popup is open) so user sees green badge as soon as
// WhatsApp Web is logged in.
async function pollWAStatus() {
  try {
    const s = await sendBg({ action:'waCheckReady' });
    const next = !!(s && s.ready);
    if (next !== waConnected) {
      waConnected = next;
      sSet({ waConnected: next });
      updateWAStatus();
    }
  } catch(e) {}
}
setInterval(pollWAStatus, 3000);
pollWAStatus();

// ── WA settings (toggles + ban-protection) ──────────────────
async function loadWaSettings() {
  const d = await sGet([
    'waTypingEnabled','waAlwaysOnline','waAutoRead','waLogging',
    'waMinDelaySec','waMaxDelaySec','waDailyLimit','waTypingMs'
  ]);
  const $ = id => document.getElementById(id);
  if ($('wa-typing-toggle')) $('wa-typing-toggle').checked = d.waTypingEnabled !== false;
  if ($('wa-always-online')) $('wa-always-online').checked = !!d.waAlwaysOnline;
  if ($('wa-auto-read'))     $('wa-auto-read').checked     = !!d.waAutoRead;
  if ($('wa-logging'))       $('wa-logging').checked       = d.waLogging !== false;
  if ($('wa-min-delay'))     $('wa-min-delay').value = d.waMinDelaySec || 8;
  if ($('wa-max-delay'))     $('wa-max-delay').value = d.waMaxDelaySec || 25;
  if ($('wa-daily-limit'))   $('wa-daily-limit').value = d.waDailyLimit || 80;
  syncWaLabels();
  refreshWaCounters();
}
function syncWaLabels() {
  const $ = id => document.getElementById(id);
  if ($('wa-min-delay-lbl')) $('wa-min-delay-lbl').textContent = ($('wa-min-delay').value|0) + 's';
  if ($('wa-max-delay-lbl')) $('wa-max-delay-lbl').textContent = ($('wa-max-delay').value|0) + 's';
}
async function refreshWaCounters() {
  try {
    const r = await sendBg({ action:'getWaCounters' });
    if (!r) return;
    const $ = id => document.getElementById(id);
    if ($('wa-today-sent'))  $('wa-today-sent').textContent  = r.dailyCount;
    if ($('wa-today-limit')) $('wa-today-limit').textContent = r.dailyLimit;
    if ($('wa-hour-sent'))   $('wa-hour-sent').textContent   = r.hourlyCount;
    if ($('wa-hour-limit'))  $('wa-hour-limit').textContent  = r.hourlyLimit;
  } catch(e) {}
}
function bindWaSettings() {
  const $ = id => document.getElementById(id);
  $('wa-typing-toggle')?.addEventListener('change', e => {
    sSet({ waTypingEnabled: e.target.checked, waTypingMs: e.target.checked ? 1500 : 0 });
  });
  $('wa-always-online')?.addEventListener('change', e => {
    sSet({ waAlwaysOnline: e.target.checked });
  });
  $('wa-auto-read')?.addEventListener('change', e => {
    sSet({ waAutoRead: e.target.checked });
  });
  $('wa-logging')?.addEventListener('change', e => {
    sSet({ waLogging: e.target.checked });
  });
  const minS = $('wa-min-delay'), maxS = $('wa-max-delay');
  const onDelay = () => {
    let mn = +minS.value, mx = +maxS.value;
    if (mx < mn + 2) { mx = mn + 2; maxS.value = mx; }
    syncWaLabels();
    sSet({ waMinDelaySec: mn, waMaxDelaySec: mx });
  };
  minS?.addEventListener('input', onDelay);
  maxS?.addEventListener('input', onDelay);
  $('wa-daily-limit')?.addEventListener('change', e => {
    const v = Math.max(10, Math.min(500, +e.target.value || 80));
    e.target.value = v;
    sSet({ waDailyLimit: v });
    refreshWaCounters();
  });
}
document.addEventListener('DOMContentLoaded', () => {
  loadWaSettings();
  bindWaSettings();
});
setInterval(refreshWaCounters, 5000);


function updateWAStatus() {
  const dot  = document.getElementById('wa-dot');
  const txt  = document.getElementById('wa-status-text');
  const nc   = document.getElementById('wa-not-connected');
  const con  = document.getElementById('wa-connected');
  const pl   = document.getElementById('wa-phone-lbl');
  if (dot)  dot.className = `wa-dot${waConnected?' connected':''}`;
  if (txt)  txt.textContent = waConnected ? 'Connected ✓ (WhatsApp Web)' : 'Not Connected — open WhatsApp Web';
  if (txt)  txt.style.color = waConnected ? 'var(--green)' : 'var(--w60)';
  if (nc)   nc.style.display  = waConnected ? 'none'  : 'block';
  if (con)  con.style.display = waConnected ? 'block' : 'none';
  if (pl)   pl.textContent = waConnected ? 'Sending via your WhatsApp Web session' : '';
}

// ══════════════════════════════════════════
// GMAIL — One-click OAuth via chrome.identity.launchWebAuthFlow
//   • User pastes their own OAuth Client ID (one-time)
//   • Click "Connect" → Google sign-in popup → done
//   • Refresh handled implicitly: on 401 we re-launch interactive flow
// ══════════════════════════════════════════
const GMAIL_SCOPES = [
  'https://www.googleapis.com/auth/gmail.send',
  'https://www.googleapis.com/auth/userinfo.email',
  'https://www.googleapis.com/auth/userinfo.profile'
];

function getRedirectURL() {
  // chromiumapp.org callback — must be added as Authorized redirect URI in Google Cloud Console
  return chrome.identity?.getRedirectURL ? chrome.identity.getRedirectURL() : '';
}

async function connectGmail() {
  const cidInp = document.getElementById('gmail-client-id');
  const cid = (cidInp?.value || gmailClientId || '').trim();
  if (!cid) {
    // Open advanced setup to capture Client ID
    const det = document.querySelector('#em-section details');
    if (det) { det.open = true; det.scrollIntoView({ behavior:'smooth', block:'center' }); }
    // Make sure redirect URI is shown
    updateGmailStatus();
    showCampaignMsg('👉 Paste your OAuth Client ID below, then click "Save & Connect". Add the redirect URI shown in setup to your Google Cloud OAuth client.', 'err');
    return;
  }
  await launchGmailAuth(cid, /*interactive*/ true);
}

async function saveGmailRefreshToken() {
  // Renamed UX: "Save & Connect" — uses the Client ID and triggers OAuth popup
  const cid = (document.getElementById('gmail-client-id')?.value || '').trim();
  if (!cid) { showCampaignMsg('Enter your OAuth Client ID first.', 'err'); return; }
  await sSet({ gmailClientId: cid });
  gmailClientId = cid;
  await launchGmailAuth(cid, true);
}

async function launchGmailAuth(clientId, interactive) {
  if (!chrome.identity?.launchWebAuthFlow) {
    showCampaignMsg('❌ chrome.identity unavailable in this context.', 'err'); return;
  }
  const redirect = getRedirectURL();
  const authUrl =
    'https://accounts.google.com/o/oauth2/auth' +
    '?client_id=' + encodeURIComponent(clientId) +
    '&response_type=token' +
    '&redirect_uri=' + encodeURIComponent(redirect) +
    '&scope=' + encodeURIComponent(GMAIL_SCOPES.join(' ')) +
    '&prompt=consent' +
    '&include_granted_scopes=true';

  showCampaignMsg('🔄 Opening Google sign-in…', 'ok');

  return new Promise((resolve) => {
    chrome.identity.launchWebAuthFlow({ url: authUrl, interactive }, async (responseUrl) => {
      if (chrome.runtime.lastError || !responseUrl) {
        const m = chrome.runtime.lastError?.message || 'cancelled';
        showCampaignMsg('❌ Gmail connect failed: ' + m + '. Make sure ' + redirect + ' is added as a Web app redirect URI in Google Cloud Console.', 'err');
        resolve(false); return;
      }
      // Parse access_token from fragment
      const frag = responseUrl.split('#')[1] || responseUrl.split('?')[1] || '';
      const params = new URLSearchParams(frag);
      const token = params.get('access_token');
      const expiresIn = parseInt(params.get('expires_in') || '3500', 10);
      if (!token) {
        showCampaignMsg('❌ No access_token in response.', 'err');
        resolve(false); return;
      }
      // Fetch profile (email)
      try {
        const r = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
          headers: { 'Authorization': 'Bearer ' + token }
        });
        const u = await r.json();
        gmailToken     = token;
        gmailAddr      = u.email || '';
        gmailConnected = true;
        gmailClientId  = clientId;
        await sSet({
          gmailToken:    token,
          gmailTokenExpiry: Date.now() + (expiresIn - 60) * 1000,
          gmailAddr,
          gmailConnected: true,
          gmailClientId:  clientId,
          gmailRealName:  u.name || ''
        });
        updateGmailStatus();
        showCampaignMsg('✅ Gmail connected: ' + gmailAddr, 'ok');
        resolve(true);
      } catch (e) {
        showCampaignMsg('❌ Profile fetch failed: ' + e.message, 'err');
        resolve(false);
      }
    });
  });
}

async function disconnectGmail() {
  gmailToken = ''; gmailAddr = ''; gmailConnected = false;
  await sSet({ gmailToken: '', gmailAddr: '', gmailConnected: false, gmailTokenExpiry: 0 });
  updateGmailStatus();
  showCampaignMsg('Gmail disconnected.', 'ok');
}

// Auto-refresh: if token is expired/invalid, re-launch silent flow.
async function ensureGmailToken() {
  const d = await sGet(['gmailToken', 'gmailTokenExpiry', 'gmailClientId']);
  if (d.gmailToken && d.gmailTokenExpiry && Date.now() < d.gmailTokenExpiry) {
    return d.gmailToken;
  }
  if (!d.gmailClientId) return null;
  const ok = await launchGmailAuth(d.gmailClientId, false); // silent
  if (ok) return (await sGet(['gmailToken'])).gmailToken;
  return null;
}

function updateGmailStatus() {
  const badge = document.getElementById('gmail-status-badge');
  const btn   = document.getElementById('gmail-connect-btn');
  const row   = document.getElementById('gmail-email-row');
  const dis   = document.getElementById('gmail-disconnect-btn');
  if (badge) { badge.className = `badge ${gmailConnected?'badge-gr':'badge-rd'}`; badge.textContent = gmailConnected ? '✓ Connected' : 'Not Connected'; }
  if (btn)  btn.textContent = gmailConnected ? '✓ Connected — Reconnect' : '🔗 Connect Gmail Account';
  if (row)  { row.style.display = gmailConnected ? '' : 'none'; row.textContent = `✓ Sending from: ${gmailAddr}`; }
  if (dis)  dis.style.display = gmailConnected ? 'block' : 'none';
  const cidInp = document.getElementById('gmail-client-id');
  if (cidInp && gmailClientId && !cidInp.value) cidInp.value = gmailClientId;
  const ru = document.getElementById('gmail-redirect-uri');
  if (ru) ru.textContent = getRedirectURL();
}

function copyRedirectURI() {
  const url = getRedirectURL();
  navigator.clipboard.writeText(url).then(() => {
    showCampaignMsg('✅ Redirect URI copied: ' + url, 'ok');
  }, () => {
    showCampaignMsg('Copy failed — manually select and copy the URL.', 'err');
  });
}

// Variable insertion
function insertVar(v, targetId) {
  const el = document.getElementById(targetId);
  if (!el) return;
  const start = el.selectionStart, end = el.selectionEnd;
  const val   = el.value;
  el.value = val.slice(0, start) + `{{${v}}}` + val.slice(end);
  el.selectionStart = el.selectionEnd = start + v.length + 4;
  el.focus();
  if (targetId === 'wa-msg') updateWAPreview();
  else updateEmailPreview();
}

function fillTemplate(tmpl, lead) {
  return (tmpl || '').replace(/\{\{(\w+)\}\}/g, (_, k) => lead[k] || '');
}

function updateWAPreview() {
  const tmpl = document.getElementById('wa-msg')?.value || '';
  const wrap = document.getElementById('wa-preview-wrap');
  const prev = document.getElementById('wa-preview');
  if (!tmpl.trim()) { if(wrap) wrap.style.display='none'; return; }
  if (wrap) wrap.style.display = 'block';
  const sampleLead = leads[0] || { name:'John Doe', phone:'+8801712345678', business:'Sample Business', rating:'4.5', address:'Dhaka, Bangladesh', email:'info@example.com', website:'example.com', category:'Restaurant' };
  if (prev) prev.textContent = fillTemplate(tmpl, sampleLead);
  sSet({ waMsgTemplate: tmpl });
}

function updateEmailPreview() {
  const subj = document.getElementById('email-subject')?.value || '';
  const body = document.getElementById('email-body')?.value || '';
  const wrap = document.getElementById('em-preview-wrap');
  if (!subj && !body) { if(wrap) wrap.style.display='none'; return; }
  if (wrap) wrap.style.display = 'block';
  const sample = leads[0] || { name:'John Doe', business:'Sample Business', website:'example.com', address:'Dhaka' };
  const subjEl = document.getElementById('em-preview-subject');
  const bodyEl = document.getElementById('em-preview-body');
  if (subjEl) subjEl.textContent = fillTemplate(subj, sample);
  if (bodyEl) bodyEl.textContent = fillTemplate(body, sample);
  sSet({ gmailSubject: subj, gmailBody: body });
}

// AI Suggest
async function aiSuggestWA() {
  const btn = document.querySelector('button[data-action="aiSuggestWA()"]');
  if (btn) btn.textContent = '✨ Generating…';
  const category = leads[0]?.category || 'Business';
  const prompt = `Write a short, friendly WhatsApp outreach message to a ${category} business owner. Use {{name}} for the contact name and {{business}} for business name. Keep it under 100 words, professional but warm. Return only the message text.`;
  try {
    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 200,
        messages: [{ role: 'user', content: prompt }]
      })
    });
    const d = await r.json();
    const text = d.content?.[0]?.text || '';
    if (text) {
      const el = document.getElementById('wa-msg');
      if (el) { el.value = text; updateWAPreview(); }
    }
  } catch(e) {
    showHuntMsg('AI suggestion failed. Check connection.','err');
  }
  if (btn) btn.innerHTML = '<span class="ai-icon">✨</span> AI Suggest Message';
}

async function aiSuggestEmail() {
  const btn = document.querySelector('button[data-action="aiSuggestEmail()"]');
  if (btn) btn.textContent = '✨ Generating…';
  const category = leads[0]?.category || 'Business';
  const prompt = `Write a short professional email to a ${category} business. Use {{name}} and {{business}} placeholders. Include a subject line prefixed with "Subject: ". Keep body under 80 words. Return subject line then body separated by newline.`;
  try {
    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 250,
        messages: [{ role: 'user', content: prompt }]
      })
    });
    const d = await r.json();
    const text = d.content?.[0]?.text || '';
    if (text) {
      const lines = text.split('\n').filter(Boolean);
      const subjLine = lines.find(l => l.toLowerCase().startsWith('subject:'));
      const subj = subjLine ? subjLine.replace(/^subject:\s*/i,'').trim() : '';
      const body = lines.filter(l => !l.toLowerCase().startsWith('subject:')).join('\n').trim();
      const se = document.getElementById('email-subject');
      const be = document.getElementById('email-body');
      if (se && subj) se.value = subj;
      if (be && body) { be.value = body; updateEmailPreview(); }
    }
  } catch(e) { showHuntMsg('AI suggestion failed.','err'); }
  if (btn) btn.innerHTML = '<span class="ai-icon">✨</span> AI Suggest Email';
}

// ══════════════════════════════════════════
// SEND / AUTOMATION (STEP 4)
// ══════════════════════════════════════════
function updateSendSummary() {
  const cLeads  = campaignLeads.length > 0 ? campaignLeads : leads;
  const chList  = [channels.wa && 'WhatsApp', channels.em && 'Email'].filter(Boolean);
  const waDel   = parseInt(document.getElementById('wa-delay')?.value || 10);
  const etaSec  = cLeads.length * waDel;
  document.getElementById('ss-leads').textContent    = fmtNum(cLeads.length);
  document.getElementById('ss-channels').textContent = chList.length ? chList.join(' + ') : 'None selected';
  document.getElementById('ss-eta').textContent      = etaSec > 0 ? fmtTime(etaSec) : '—';
}

function setWADelay(v) {
  document.getElementById('wa-delay-lbl').textContent = `${v}s`;
  sSet({ waDelaySec: parseInt(v) });
  updateSendSummary();
}

function setEMDelay(v) {
  document.getElementById('em-delay-lbl').textContent = `${v}s`;
  sSet({ emailDelaySec: parseInt(v) });
}

async function startCampaign() {
  if (!channels.wa && !channels.em) {
    showCampaignMsg('Please select at least one channel in Campaign Builder.','warn'); return;
  }
  // Respect folder/selection exactly — no silent fallback to all leads
  const target = campaignLeads.slice();
  if (target.length === 0) {
    showCampaignMsg('No leads in the selected folder. Add leads to this folder first.','err'); return;
  }

  if (channels.wa && !waConnected) {
    showCampaignMsg('WhatsApp not connected. Connect in Campaign Builder first.','err'); return;
  }
  if (channels.em && !gmailConnected) {
    showCampaignMsg('Gmail not connected. Connect in Campaign Builder first.','err'); return;
  }

  const waMsg   = document.getElementById('wa-msg')?.value || '';
  const emSubj  = document.getElementById('email-subject')?.value || '';
  const emBody  = document.getElementById('email-body')?.value || '';

  if (channels.wa && !waMsg.trim()) {
    showCampaignMsg('WhatsApp message template is empty.','err'); return;
  }
  if (channels.em && (!emSubj.trim() || !emBody.trim())) {
    showCampaignMsg('Email subject or body is empty.','err'); return;
  }

  campaignActive = true;
  sendStats = { sent:0, fail:0, pend: target.length, total: target.length };
  document.getElementById('send-progress').style.display = 'block';
  document.getElementById('campaign-controls').style.display = 'none';
  updateSendMetrics();

  addLog('info', `Campaign started: ${target.length} leads, channels: ${[channels.wa&&'WA',channels.em&&'Email'].filter(Boolean).join('+')}`);
  showCampaignMsg('🚀 Campaign started! Track progress in the floating panel on the active page.','ok');

  // Delegate to background
  sendBg({
    action:       'startCampaign',
    licenseKey,
    leads:        target,
    waEnabled:    channels.wa,
    emailEnabled: channels.em,
    waToken,
    waTemplate:   waMsg,
    gmailToken,
    emailSubject: emSubj,
    emailBody:    emBody,
    waDelaySec:    parseInt(document.getElementById('wa-min-delay')?.value || document.getElementById('wa-delay')?.value || 8),
    waMaxDelaySec: parseInt(document.getElementById('wa-max-delay')?.value || 25),
    waTypingMs:    document.getElementById('wa-typing-toggle')?.checked ? 1500 : 0,
    emDelaySec:    parseInt(document.getElementById('em-delay')?.value || 5),
    waAttachDataUrl: waAttachDataUrl || null,
    waAttachMeta:    waAttachMeta    || null,
    emailAttachDataUrl: emailAttachDataUrl || null,
    emailAttachMeta:    emailAttachMeta    || null,
  }).then(() => {});

  // Poll progress
  const statsPoll = setInterval(async () => {
    const d = await sGet(['campaignSent','campaignFail','campaignPend','campaignLastLog']);
    if (d.campaignSent  !== undefined) sendStats.sent = d.campaignSent;
    if (d.campaignFail  !== undefined) sendStats.fail = d.campaignFail;
    if (d.campaignPend  !== undefined) sendStats.pend = d.campaignPend;
    if (d.campaignLastLog) { addLog('ok', d.campaignLastLog); }
    updateSendMetrics();

    if (!campaignActive || sendStats.pend <= 0) {
      clearInterval(statsPoll);
      campaignActive = false;
      addLog('info', '✅ Campaign completed!');
      const sp = document.getElementById('send-progress');
      if (sp) sp.style.display = 'none';
      const cc = document.getElementById('campaign-controls');
      if (cc) cc.style.display = 'block';
    }
  }, 2000);
}

function stopCampaign() {
  campaignActive = false;
  sendBg({ action: 'stopCampaign' });
  document.getElementById('send-progress').style.display = 'none';
  document.getElementById('campaign-controls').style.display = 'block';
  addLog('info','Campaign stopped by user.');
}

function updateSendMetrics() {
  const total = sendStats.total || 1;
  const pct   = Math.min(100, ((sendStats.sent + sendStats.fail) / total) * 100);
  document.getElementById('sp-sent').textContent = sendStats.sent;
  document.getElementById('sp-fail').textContent = sendStats.fail;
  document.getElementById('sp-pend').textContent = sendStats.pend;
  document.getElementById('send-prog-fill').style.width = `${pct}%`;
}

// ══════════════════════════════════════════
// SEND OVERLAY — REMOVED (popup-within-popup gone)
// Live status now lives only in progress-panel.js (floating widget on the page)
// Stub functions kept so any legacy callers are no-ops.
// ══════════════════════════════════════════
function showSendOverlay(){}
function updateSendOverlay(){}
function hideSendOverlay(){}
function setSendOverlayCurrent(){}

// ══════════════════════════════════════════
// WA ATTACHMENT SUPPORT (image / file) — like WA Sender Pro
// ══════════════════════════════════════════
let waAttachFile = null;
let waAttachDataUrl = null;
let waAttachMeta = null;

function selectWaAttachment() {
  const inp = document.createElement('input');
  inp.type = 'file';
  inp.accept = 'image/*,.pdf,.doc,.docx,.xls,.xlsx,.txt,.zip';
  inp.style.display = 'none';
  inp.onchange = async () => {
    const f = inp.files?.[0];
    if (!f) { try { inp.remove(); } catch(_){} return; }
    waAttachFile = f;
    waAttachMeta = { name: f.name, type: f.type || 'application/octet-stream', size: f.size };
    waAttachDataUrl = await new Promise(res => {
      const fr = new FileReader();
      fr.onload = e => res(e.target.result);
      fr.readAsDataURL(f);
    });
    try { chrome.storage.local.set({ waAttachDataUrl, waAttachMeta }); } catch(_){}
    const nm = document.getElementById('wa-attach-name');
    const cl = document.getElementById('wa-attach-clear');
    if (nm) nm.textContent = f.name;
    if (cl) cl.style.display = '';
    try { inp.remove(); } catch(_){}
  };
  document.body.appendChild(inp);
  inp.click();
}

function clearWaAttachment() {
  waAttachFile = null; waAttachDataUrl = null; waAttachMeta = null;
  try { chrome.storage.local.remove(['waAttachDataUrl', 'waAttachMeta']); } catch(_){}
  const nm = document.getElementById('wa-attach-name');
  const cl = document.getElementById('wa-attach-clear');
  if (nm) nm.textContent = 'No file';
  if (cl) cl.style.display = 'none';
}

// ══════════════════════════════════════════
// EMAIL ATTACHMENT SUPPORT (image / document)
// ══════════════════════════════════════════
let emailAttachFile    = null;
let emailAttachDataUrl = null;
let emailAttachMeta    = null;

function selectEmailAttachment() {
  const inp = document.createElement('input');
  inp.type   = 'file';
  inp.accept = 'image/*,.pdf,.doc,.docx,.xls,.xlsx,.txt,.zip,.csv';
  inp.style.display = 'none';
  inp.onchange = async () => {
    const f = inp.files?.[0];
    if (!f) { try { inp.remove(); } catch(_){} return; }
    if (f.size > 20 * 1024 * 1024) {
      try { showCampaignMsg && showCampaignMsg('File too large. Gmail allows max 20MB attachments.', 'err'); } catch(_){}
      try { inp.remove(); } catch(_){}
      return;
    }
    emailAttachFile = f;
    emailAttachMeta = { name: f.name, type: f.type || 'application/octet-stream', size: f.size };
    emailAttachDataUrl = await new Promise(res => {
      const fr = new FileReader();
      fr.onload = e => res(e.target.result);
      fr.readAsDataURL(f);
    });
    try { chrome.storage.local.set({ emailAttachDataUrl, emailAttachMeta }); } catch(_){}
    const nm = document.getElementById('email-attach-name');
    const cl = document.getElementById('email-attach-clear');
    if (nm) nm.textContent = f.name;
    if (cl) cl.style.display = '';
    try { inp.remove(); } catch(_){}
  };
  document.body.appendChild(inp);
  inp.click();
}

function clearEmailAttachment() {
  emailAttachFile = null; emailAttachDataUrl = null; emailAttachMeta = null;
  try { chrome.storage.local.remove(['emailAttachDataUrl', 'emailAttachMeta']); } catch(_){}
  const nm = document.getElementById('email-attach-name');
  const cl = document.getElementById('email-attach-clear');
  if (nm) nm.textContent = 'No file selected';
  if (cl) cl.style.display = 'none';
}


function addLog(type, msg) {
  const log = document.getElementById('send-log');
  if (!log) return;
  const ts  = new Date().toLocaleTimeString('en-GB', { hour:'2-digit', minute:'2-digit', second:'2-digit' });
  const cls = { ok:'log-ok', err:'log-err', info:'log-info' }[type] || '';
  log.innerHTML += `<div class="${cls}">[${ts}] ${esc(msg)}</div>`;
  log.scrollTop  = log.scrollHeight;
}

function showCampaignMsg(msg, type='inf') {
  const box = document.getElementById('campaign-status');
  if (!box) return;
  const icon = {ok:'✅',err:'❌',inf:'ℹ️',warn:'⚠️'}[type] || 'ℹ️';
  box.className = `status-box ${type} show`;
  box.querySelector('.si').textContent = icon;
  document.getElementById('campaign-msg').textContent = msg;
  setTimeout(() => box.classList.remove('show'), 4000);
}

// ══════════════════════════════════════════
// EXPORT & CRM (STEP 5)
// ══════════════════════════════════════════
function updateExportCount() {
  const el = document.getElementById('export-count');
  if (el) el.textContent = leads.length;
}

function getExportLeads() {
  // Honor folder filter; fall back to all leads
  if (activeFolderFilter && folders[activeFolderFilter]) {
    return getFilteredLeads();
  }
  return leads;
}

function exportCSV() {
  const data = getExportLeads();
  if (!data.length) { showHuntMsg('No leads to export.','warn'); return; }
  const headers = ['Name','Phone','Email','Website','Address','Category','Rating','WhatsApp'];
  const rows = data.map(l => [
    l.name||'', l.phone||'', l.email||'', l.website||'',
    l.address||'', l.category||'', l.rating||'', l.whatsapp||l.phone||''
  ].map(v => `"${String(v).replace(/"/g,'""')}"`).join(','));
  const csv = '\uFEFF' + [headers.join(','), ...rows].join('\n');
  downloadFile(`leads_${datestamp()}.csv`, csv, 'text/csv;charset=utf-8;');
}

function exportExcel() {
  const data = getExportLeads();
  if (!data.length) { showHuntMsg('No leads to export.','warn'); return; }
  if (typeof XLSX !== 'undefined' && XLSX.writeFile) {
    try {
      const headers = ['Name','Phone','Email','Website','Address','Category','Rating','WhatsApp'];
      const aoa = [headers, ...data.map(l => [
        l.name||'', l.phone||'', l.email||'', l.website||'',
        l.address||'', l.category||'', l.rating||'', l.whatsapp||l.phone||''
      ])];
      const ws = XLSX.aoa_to_sheet(aoa);
      const wb = XLSX.book_new();
      XLSX.book_append_sheet(wb, ws, 'Leads');
      XLSX.writeFile(wb, `leads_${datestamp()}.xlsx`);
      return;
    } catch(e) { console.error('XLSX export failed', e); }
  }
  // Fallback to TSV
  const headers = ['Name','Phone','Email','Website','Address','Category','Rating','WhatsApp'];
  const tsv = [headers, ...data.map(l => [l.name,l.phone,l.email,l.website,l.address,l.category,l.rating,l.whatsapp||l.phone].map(v => v||''))].map(r => r.join('\t')).join('\n');
  downloadFile(`leads_${datestamp()}.xls`, tsv, 'application/vnd.ms-excel');
}

function exportPhoneList() {
  const data = getExportLeads();
  const list = data.map(l => l.phone).filter(p => p && p !== '—').join('\n');
  if (!list) { showHuntMsg('No phone numbers to export.','warn'); return; }
  downloadFile(`phones_${datestamp()}.txt`, list, 'text/plain');
}

function exportEmailList() {
  const data = getExportLeads();
  const list = data.map(l => l.email).filter(e => e && e !== '—' && e.includes('@')).join('\n');
  if (!list) { showHuntMsg('No emails to export.','warn'); return; }
  downloadFile(`emails_${datestamp()}.txt`, list, 'text/plain');
}

function exportWhatsAppList() {
  const data = getExportLeads();
  const list = data.map(l => (l.whatsapp || l.phone || '').replace(/\D/g,''))
    .filter(p => p && p.length >= 8).join('\n');
  if (!list) { showHuntMsg('No WhatsApp numbers to export.','warn'); return; }
  downloadFile(`whatsapp_${datestamp()}.txt`, list, 'text/plain');
}

function exportJSON() {
  if (!leads.length) { showHuntMsg('No leads to export.','warn'); return; }
  downloadFile(`leads_${datestamp()}.json`, JSON.stringify(leads, null, 2), 'application/json');
}

function copyToClipboard() {
  if (!leads.length) { showHuntMsg('No leads to copy.','warn'); return; }
  const text = leads.map(l => [l.name,l.phone,l.email,l.website].join('\t')).join('\n');
  navigator.clipboard.writeText(text).then(() => showHuntMsg(`${leads.length} leads copied to clipboard!`,'ok'));
}

async function sendWebhook() {
  const url = document.getElementById('webhook-url')?.value?.trim();
  if (!url) { showWebhookStatus('Please enter a webhook URL.','err'); return; }
  await sSet({ webhookUrl: url });
  try {
    const r = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ leads, count: leads.length, exported_at: new Date().toISOString() })
    });
    showWebhookStatus(r.ok ? `✓ Sent ${leads.length} leads to webhook!` : `Server returned ${r.status}`,'ok');
  } catch(e) {
    showWebhookStatus('Webhook failed: ' + e.message,'err');
  }
}

function showWebhookStatus(msg, type) {
  const box = document.getElementById('webhook-status');
  if (!box) return;
  box.className = `status-box ${type} show`;
  box.querySelector('.si').textContent = type === 'ok' ? '✅' : '❌';
  document.getElementById('webhook-msg').textContent = msg;
  setTimeout(() => box.classList.remove('show'), 4000);
}

function saveAllToCRM() {
  const newLeads = leads.filter(l => !crmLeads.some(c => c.phone === l.phone && c.name === l.name));
  crmLeads.push(...newLeads);
  sSet({ crmLeads });
  renderCRM();
  showHuntMsg(`${newLeads.length} leads saved to CRM.`,'ok');
}

function renderCRM() {
  const el    = document.getElementById('crm-list');
  const count = document.getElementById('crm-count');
  if (count) count.textContent = crmLeads.length;
  if (!el) return;
  if (crmLeads.length === 0) { el.innerHTML = '<div class="crm-empty">No saved leads. Export or save leads from above.</div>'; return; }
  el.innerHTML = crmLeads.slice(-20).reverse().map((l,i) => `
    <div class="crm-entry">
      <div class="crm-entry-info">
        <div class="crm-entry-name">${esc(l.name||'—')}</div>
        <div class="crm-entry-meta">${esc(l.phone||'—')} · ${esc(l.category||'Business')}</div>
      </div>
      <div class="crm-entry-actions">
        ${l.phone&&l.phone!=='—'?`<div class="crm-btn" data-action="openWA('${esc(l.phone)}')">💬</div>`:''}
        <div class="crm-btn" data-action="removeCRM(${i})">🗑</div>
      </div>
    </div>`).join('');
}

function removeCRM(i) {
  crmLeads.splice(crmLeads.length - 1 - i, 1);
  sSet({ crmLeads });
  renderCRM();
}

function openWA(phone) {
  window.open(`https://wa.me/${phone.replace(/\D/g,'')}`, '_blank');
}

// ══════════════════════════════════════════
// ACCOUNT / LICENSE PANEL
// ══════════════════════════════════════════
function openAcct() {
  // Don't open if currently on Plans tab (user should use Plans tab instead)
  if (curStep === 99) return;

  const overlay = document.getElementById('acct-overlay');
  const panel   = document.getElementById('acct-panel');
  if (overlay) overlay.classList.add('show');
  if (panel) {
    panel.style.display = 'block';
    panel.style.animation = 'slideUp .3s cubic-bezier(.16,1,.3,1) both';
  }
  loadAcctData();
}
function closeAcct() {
  document.getElementById('acct-overlay').classList.remove('show');
  document.getElementById('acct-panel').style.display = 'none';
}

async function loadAcctData() {
  const d = await sGet(['licenseKey','licenseData','creditsRemaining','pendingPaymentTxn']);

  const buySection      = document.getElementById('acct-buy-section');
  const activateSection = document.getElementById('acct-activate-section');
  const planBadge       = document.getElementById('plan-badge');
  const licKeyBox       = document.getElementById('lic-key-box');
  const pollSection     = document.getElementById('pay-poll-section');
  const paymentForm     = document.getElementById('payment-form');

  // ── CASE 1: Active license → show account info ──
  if (d.licenseKey && d.licenseData?.status === 'active') {
    if (planBadge)       { planBadge.style.display = 'flex'; }
    if (licKeyBox)       { licKeyBox.style.display = 'flex'; }
    if (buySection)      { buySection.style.display = 'none'; }
    if (activateSection) { activateSection.style.display = 'none'; }
    showActivatedState(d.licenseKey, d.licenseData, d.creditsRemaining || 0);
    return;
  }

  // ── CASE 2: Pending payment → show poll section ──
  if (d.pendingPaymentTxn) {
    if (planBadge)       { planBadge.style.display = 'none'; }
    if (licKeyBox)       { licKeyBox.style.display = 'none'; }
    if (activateSection) { activateSection.style.display = 'none'; }
    if (buySection)      { buySection.style.display = 'block'; }
    if (paymentForm)     { paymentForm.style.display = 'none'; }
    if (pollSection)     { pollSection.style.display = 'block'; }
    return;
  }

  // ── CASE 3: Fresh user → plans first (DEFAULT) ──
  if (planBadge)       { planBadge.style.display = 'none'; }
  if (licKeyBox)       { licKeyBox.style.display = 'none'; }
  if (activateSection) { activateSection.style.display = 'none'; }  // ← license input hidden
  if (buySection)      { buySection.style.display = 'block'; }       // ← plan cards shown
  if (paymentForm)     { paymentForm.style.display = 'none'; }
  if (pollSection)     { pollSection.style.display = 'none'; }

  // Show loading state while fetching plans
  const container = document.getElementById('plan-cards-container');
  if (container && (!settings.plans || settings.plans.length === 0)) {
    container.innerHTML = `
      <div style="text-align:center;padding:30px 20px">
        <div style="width:20px;height:20px;border-radius:50%;border:2px solid var(--or-glow);
                    border-top-color:var(--or);animation:spin .6s linear infinite;margin:0 auto 10px"></div>
        <div style="font-size:12px;color:var(--w60)">Loading plans…</div>
      </div>`;
    await fetchSettings();
  } else if (settings.plans && settings.plans.length > 0) {
    buildPlanCards(settings.plans);
  }
}

// Toggle: show license input if user already has a key
function showLicenseInput() {
  const buySection      = document.getElementById('acct-buy-section');
  const activateSection = document.getElementById('acct-activate-section');
  if (buySection)      buySection.style.display = 'none';
  if (activateSection) activateSection.style.display = 'block';
}
function showPlansAgain() {
  const buySection      = document.getElementById('acct-buy-section');
  const activateSection = document.getElementById('acct-activate-section');
  if (buySection)      buySection.style.display = 'block';
  if (activateSection) activateSection.style.display = 'none';
}

function showActivatedState(key, data, credits) {
  document.getElementById('acct-plan').textContent     = data.plan_name || 'Active Plan';
  document.getElementById('acct-credits').textContent  = fmtNum(credits);
  // Credits-only model — no expiry display
  const exEl = document.getElementById('acct-expiry');
  if (exEl) exEl.textContent = `${fmtNum(credits)} credits remaining`;
  const kb = document.getElementById('lic-key-box');
  if (kb) { kb.style.display = 'flex'; document.getElementById('lic-key-val').textContent = key; }
  const as = document.getElementById('acct-activate-section');
  if (as) as.style.display = 'none';
}

async function activateLicense() {
  const key = document.getElementById('lic-input')?.value?.trim()?.toUpperCase()?.replace(/[^A-Z0-9-]/g,'');
  if (!key || key.length < 8) { showLicMsg('Please enter a valid license key.','err'); return; }

  const btn = document.getElementById('lic-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Verifying…'; }

  try {
    // Verify via server-side Edge Function (no direct DB access).
    const res = await callFn('license-verify', { license_key: key });

    if (!res || res.success !== true) {
      const map = {
        license_key_not_found: 'License key not found.',
        account_suspended:     'Account suspended. Contact support.',
        payment_pending:       'Payment pending. Credits will be added within 24h.',
        connection_failed:     'Connection failed.',
        network_error:         'Connection failed.',
      };
      showLicMsg(map[res?.error] || 'Verification failed.', 'err');
      resetLicBtn();
      return;
    }

    const l = res.license;
    const lic = {
      status:            l.status,
      plan_name:         l.plan_name || l.plan_slug || 'Active',
      plan_slug:         l.plan_slug,
      credits_remaining: l.credits_remaining || 0,
      credits_total:     l.credits_total     || 0,
      credits_used:      l.credits_used      || 0,
      activated_at:      l.activated_at,
      expires_at:        l.expires_at,
      features:          l.features || [],
    };

    licenseKey  = key;
    licenseData = lic;

    await sSet({
      licenseKey: key,
      licenseData: lic,
      creditsRemaining: lic.credits_remaining,
    });

    updateCreditsDisplay(lic.credits_remaining);
    showActivatedState(key, lic, lic.credits_remaining);
    showLicMsg('License activated! 🎉','ok');

  } catch(e) {
    showLicMsg('Connection error: ' + e.message,'err');
  }
  resetLicBtn();
}

function resetLicBtn() {
  const btn = document.getElementById('lic-btn');
  if (btn) { btn.disabled = false; btn.textContent = 'Activate License'; }
}

function showLicMsg(msg, type) {
  // Try global status box first (always visible)
  const global = document.getElementById('acct-global-status');
  if (global) {
    const icons = { ok:'✅', err:'❌', inf:'ℹ️', warn:'⚠️' };
    global.className = `status-box ${type} show`;
    global.querySelector('.si').textContent = icons[type] || 'ℹ️';
    document.getElementById('acct-global-msg').textContent = msg;
    setTimeout(() => global.classList.remove('show'), 4000);
    return;
  }
  // Fallback to activate section status box
  const box = document.getElementById('lic-status');
  if (!box) return;
  box.className = `status-box ${type} show`;
  box.querySelector('.si').textContent = type === 'ok' ? '✅' : '❌';
  document.getElementById('lic-msg').textContent = msg;
}

function copyLicenseKey() {
  const key = document.getElementById('lic-key-val')?.textContent || '';
  navigator.clipboard.writeText(key).then(() => { showLicMsg('License key copied!','ok'); });
}

// Plan cards (built from API)
function buildPlanCards(plans) {
  const container = document.getElementById('plan-cards-container');
  if (!container) return;
  if (!plans || plans.length === 0) {
    container.innerHTML = `
      <div style="text-align:center;padding:30px 20px;color:var(--w60)">
        <div style="font-size:32px;margin-bottom:10px">⏳</div>
        <div style="font-size:13px">Loading plans…</div>
      </div>`;
    return;
  }

  // Apply overrides on every plan (trial credits, paid plan names/prices/badges)
  plans = plans.map(p => { applyPlanOverride(p); return p; });

  // Sort: trial first, then by sort_order
  const sorted = [...plans].sort((a, b) => {
    if (a.slug === 'trial') return -1;
    if (b.slug === 'trial') return 1;
    return (a.sort_order || 99) - (b.sort_order || 99);
  });

  const trial    = sorted.find(p => p.slug === 'trial' || p.price === 0);
  const paid     = sorted.filter(p => p.slug !== 'trial' && p.price > 0);

  container.innerHTML = `
    <!-- Welcome header -->
    <div style="text-align:center;margin-bottom:14px">
      <div style="font-family:var(--font-d);font-size:16px;font-weight:800;line-height:1.2">
        Choose your <span style="color:var(--or)">plan</span>
      </div>
      <div style="font-size:11px;color:var(--w60);margin-top:3px">
        Start free or unlock the full power of Lead Hunter Pro
      </div>
    </div>

    ${trial ? `
      <!-- Free trial highlight CTA -->
      <div data-action="selectPlan('${trial.id}','${esc(trial.name)}',${trial.price},${trial.credits})"
           id="pc-${trial.id}"
           style="background:linear-gradient(135deg,rgba(34,197,94,.12),rgba(241,98,50,.08));
                  border:1px solid rgba(34,197,94,.35);border-radius:14px;padding:14px;
                  cursor:pointer;transition:all .2s;margin-bottom:12px;
                  display:flex;align-items:center;justify-content:space-between;gap:12px">
        <div>
          <div style="display:inline-block;font-size:9px;font-weight:800;color:var(--green);
                      background:rgba(34,197,94,.15);border:1px solid rgba(34,197,94,.3);
                      padding:2px 8px;border-radius:99px;text-transform:uppercase;
                      letter-spacing:.06em;margin-bottom:6px">🎁 Free Forever-No Card</div>
          <div style="font-family:var(--font-d);font-size:14px;font-weight:800">${esc(trial.name)}</div>
          <div style="font-size:11px;color:var(--w60);margin-top:2px">
            Get ${fmtNum(trial.credits)} credits • ${trial.duration_days || 3} days • Activates instantly
          </div>
        </div>
        <div style="text-align:right">
          <div style="font-family:var(--font-d);font-size:20px;font-weight:800;color:var(--green)">FREE</div>
          <div style="font-size:10px;color:var(--w60);margin-top:2px">Try Now →</div>
        </div>
      </div>
    ` : ''}

    ${paid.length > 0 ? `
      <div style="font-size:10px;font-weight:700;color:var(--w60);text-transform:uppercase;
                  letter-spacing:.06em;margin-bottom:8px;text-align:center">
        Or upgrade to a paid plan
      </div>
      <div style="display:grid;grid-template-columns:${paid.length === 2 ? '1fr 1fr' : paid.length === 3 ? '1fr 1fr 1fr' : '1fr 1fr'};gap:6px;margin-bottom:6px">
        ${paid.map(p => `
          <div data-action="selectPlan('${p.id}','${esc(p.name)}',${p.price},${p.credits})"
               id="pc-${p.id}"
               style="padding:12px 10px;border-radius:12px;background:var(--gb);
                      border:1px solid ${p.badge === 'popular' ? 'var(--or-glow)' : 'var(--gbr)'};
                      cursor:pointer;transition:all .2s;text-align:center;position:relative">
            ${p.badge ? `<div style="position:absolute;top:-7px;left:50%;transform:translateX(-50%);
                                     font-size:9px;font-weight:700;color:#fff;
                                     background:var(--or);padding:2px 8px;border-radius:99px;
                                     text-transform:uppercase;letter-spacing:.05em;white-space:nowrap">${esc(p.badge)}</div>` : ''}
            <div style="font-family:var(--font-d);font-size:13px;font-weight:700;margin-top:${p.badge ? '4px' : '0'}">${esc(p.name)}</div>
            <div style="font-family:var(--font-d);font-size:20px;font-weight:800;color:var(--or);margin-top:6px;line-height:1">${fmtNum(p.credits)}</div>
            <div style="font-size:9px;color:var(--w60);text-transform:uppercase;letter-spacing:.05em;margin-top:2px;margin-bottom:6px">Credits</div>
            <div style="font-size:15px;font-weight:800">৳${fmtNum(p.price)}</div>
            ${p.duration_days ? `<div style="font-size:9px;color:var(--w60);margin-top:2px">${p.duration_days} days</div>` : '<div style="font-size:9px;color:#c084fc;margin-top:2px;font-weight:700">✨ Lifetime</div>'}
            ${p.save_text ? `<div style="font-size:9px;color:var(--green);margin-top:4px;font-weight:700">${esc(p.save_text)}</div>` : ''}
          </div>`).join('')}
      </div>
    ` : ''}
  `;
}

function selectPlan(id, name, price, credits) {
  selectedPlan = { id, name, price, credits };
  document.querySelectorAll('[id^="pc-"]').forEach(el => {
    el.style.borderColor = 'var(--gbr)';
    el.style.background  = 'var(--gb)';
  });
  const sel = document.getElementById(`pc-${id}`);
  if (sel) { sel.style.borderColor = 'var(--or)'; sel.style.background = 'var(--or-dim)'; }

  if (price === 0) {
    // Free trial — auto-activate
    activateFreeTrial(id, name, credits);
    return;
  }

  // Show payment form
  const pf = document.getElementById('payment-form');
  if (pf) {
    pf.style.display = 'block';
    document.getElementById('pay-amount').textContent = `৳${fmtNum(price)}`;
    document.getElementById('pay-amt-txt').textContent = `৳${fmtNum(price)}`;
    updatePayMethodDisplay();
    pf.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }
}

// ── Auto-activate free trial ──────────────────
async function activateFreeTrial(planId, planName, credits) {
  // Trials are now issued server-side and require name + WhatsApp number
  // (for the one-trial-per-phone abuse guard). The account screen has no
  // such inputs, so route the user into the onboarding flow which does.
  showLicMsg('Opening trial signup…','inf');
  try {
    if (typeof obInit === 'function') {
      // Jump to the onboarding pricing step where name/phone are collected
      if (typeof goStep === 'function') goStep(99);
      obInit();
      if (typeof obShowPricing === 'function') obShowPricing();
      return;
    }
    // Fallback: open onboarding page in a new tab
    chrome.tabs.create({ url: chrome.runtime.getURL('onboarding.html') });
  } catch(e) {
    showLicMsg('Please use the trial signup screen.','err');
    console.error('[trial]', e);
  }
}

// (legacy trial flow removed — trials now via create-trial Edge Function)


function selectPayMethod(tab) {
  document.querySelectorAll('.ptab').forEach(t => t.classList.remove('on'));
  tab.classList.add('on');
  selectedMethod = tab.dataset.method;
  updatePayMethodDisplay();
}

function updatePayMethodDisplay() {
  const nums = {
    bkash:  settings.bkash_number  || '01XXXXXXXXX',
    nagad:  settings.nagad_number  || '01XXXXXXXXX',
    rocket: settings.rocket_number || '01XXXXXXXXX',
    bank:   settings.bank_account  || 'Contact support',
  };
  const labels = { bkash:'bKash', nagad:'Nagad', rocket:'Rocket', bank:'Bank Transfer' };
  const num = nums[selectedMethod] || '01XXXXXXXXX';
  ['pay-number','pay-num-txt'].forEach(id => { const el = document.getElementById(id); if(el) el.textContent = num; });
  const mn = document.getElementById('pay-method-name');
  if (mn) mn.textContent = labels[selectedMethod] || 'bKash';
}

function copyPayNumber() {
  const num = document.getElementById('pay-number')?.textContent || '';
  navigator.clipboard.writeText(num).then(() => showLicMsg('Number copied!','ok'));
}

async function submitPayment() {
  if (!selectedPlan) { showPayMsg('Please select a plan first.','err'); return; }
  const name  = document.getElementById('pay-name')?.value?.trim();
  const phone = document.getElementById('pay-phone')?.value?.trim();
  const txn   = document.getElementById('pay-txn')?.value?.trim();
  if (!phone || phone.length < 10) { flashInput('pay-phone'); showPayMsg('Enter your phone number.','err'); return; }
  if (!txn   || txn.length < 5)    { flashInput('pay-txn');   showPayMsg('Enter your Transaction ID.','err'); return; }

  const btn = document.getElementById('pay-submit-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Submitting…'; }

  try {
    // Submit via server-side Edge Function. The server validates the plan,
    // forces status:'pending', and guards against duplicate TrxIDs.
    const res = await callFn('submit-payment', {
      customer_name:  name,
      customer_phone: phone,
      plan_id:        selectedPlan.id,
      payment_method: selectedMethod,
      transaction_id: txn,
    });

    if (!res || res.success !== true) {
      const msg = res?.error === 'duplicate'
        ? (res.status === 'approved' ? 'This TrxID was already approved.' : 'This TrxID is already under review.')
        : res?.error === 'invalid_plan' ? 'Invalid plan selected.'
        : res?.error === 'missing_fields' ? 'Please fill all fields.'
        : 'Submission failed. Please try again.';
      showPayMsg(msg, 'err');
      if(btn){btn.disabled=false;btn.textContent='Submit Payment';}
      return;
    }

    pendingTxnId = txn;
    await sSet({ pendingPaymentTxn: txn, pendingPlanName: selectedPlan.name });
    document.getElementById('payment-form').style.display = 'none';
    document.getElementById('pay-poll-section').style.display = 'block';
    showPayMsg('Payment submitted! ✓','ok');

  } catch(e) {
    showPayMsg('Connection error. Please try again.','err');
  }
  if (btn) { btn.disabled = false; btn.textContent = 'Submit Payment'; }
}

async function checkPaymentStatus() {
  const txn = pendingTxnId || (await sGet(['pendingPaymentTxn'])).pendingPaymentTxn;
  if (!txn) return;

  const btn = document.querySelector('button[data-action="checkPaymentStatus()"]');
  if (btn) { btn.disabled = true; btn.textContent = '⏳ Checking…'; }

  try {
    const res = await callFn('check-payment', { transaction_id: txn });
    if (!res || res.success !== true) { showLicMsg('Could not check status.','err'); return; }
    if (res.status === 'pending') {
      showLicMsg('Still pending. Admin will verify within 24 hours.','warn');
      if (btn) { btn.disabled = false; btn.textContent = '🔄 Check Payment Status'; }
      return;
    }

    const p = { status: res.status, license_key: res.license_key, credits: res.license?.credits_total, reject_reason: res.reason };

    if (p.status === 'approved') {
      // ── Auto-activate using the license returned by the server ──
      const licKey  = res.license_key || null;
      const userRow = res.license || null;

      if (userRow) {
        const lic = {
          status:            userRow.status,
          plan_name:         userRow.plan_name || userRow.plan_slug || 'Pro',
          plan_slug:         userRow.plan_slug,
          credits_remaining: userRow.credits_remaining || 0,
          credits_total:     userRow.credits_total     || 0,
          credits_used:      userRow.credits_used      || 0,
          activated_at:      userRow.activated_at,
          expires_at:        userRow.expires_at,
          features:          userRow.features || [],
        };
        licenseKey  = licKey;
        licenseData = lic;
        await sSet({ licenseKey: licKey, licenseData: lic, creditsRemaining: lic.credits_remaining, pendingPaymentTxn: null });
        updateCreditsDisplay(lic.credits_remaining);

        // Switch UI to activated state
        const planBadge  = document.getElementById('plan-badge');
        const licKeyBox  = document.getElementById('lic-key-box');
        const buySection = document.getElementById('acct-buy-section');
        const pollSection= document.getElementById('pay-poll-section');
        if (planBadge)  planBadge.style.display  = 'flex';
        if (licKeyBox)  licKeyBox.style.display   = 'flex';
        if (buySection) buySection.style.display  = 'none';
        if (pollSection)pollSection.style.display = 'none';
        showActivatedState(licKey, lic, lic.credits_remaining);
        showLicMsg(`🎉 Activated! ${fmtNum(lic.credits_remaining)} credits added.`, 'ok');
      } else {
        // Approved but no license minted yet — still show success
        await sSet({ pendingPaymentTxn: null });
        showLicMsg(`✅ Payment approved! Credits will appear shortly.`,'ok');
        setTimeout(() => refreshCredits(), 2000);
      }

    } else if (p.status === 'rejected') {
      await sSet({ pendingPaymentTxn: null });
      const reason = p.reject_reason || 'Contact support for details.';
      showLicMsg(`❌ Rejected: ${reason}`, 'err');

      // Go back to plan cards
      const pollSection = document.getElementById('pay-poll-section');
      const buySection  = document.getElementById('acct-buy-section');
      if (pollSection) pollSection.style.display = 'none';
      if (buySection)  buySection.style.display  = 'block';

    } else {
      showLicMsg('Still pending. Admin will verify within 24 hours.','warn');
    }
  } catch(e) {
    showLicMsg('Connection error.','err');
  }

  if (btn) { btn.disabled = false; btn.textContent = '🔄 Check Payment Status'; }
}

function showPayMsg(msg, type) {
  const box = document.getElementById('pay-status');
  if (!box) return;
  box.className = `status-box ${type} show`;
  box.querySelector('.si').textContent = type === 'ok' ? '✅' : type === 'err' ? '❌' : '⏳';
  document.getElementById('pay-msg').textContent = msg;
}

// ══════════════════════════════════════════
// CREDITS
// ══════════════════════════════════════════
function updateCreditsDisplay(cr) {
  const el = document.getElementById('credit-count');
  if (el) el.textContent = cr !== undefined && cr !== null ? fmtNum(cr) : '—';
}

async function refreshCredits() {
  if (!licenseKey) return;
  try {
    const res = await callFn('license-verify', { license_key: licenseKey });
    if (!res || res.success !== true) return;
    const l = res.license;
    const lic = {
      status:            l.status,
      plan_name:         l.plan_name || l.plan_slug || 'Active',
      plan_slug:         l.plan_slug,
      credits_remaining: l.credits_remaining || 0,
      credits_total:     l.credits_total     || 0,
      credits_used:      l.credits_used      || 0,
      activated_at:      l.activated_at,
      expires_at:        l.expires_at,
      features:          l.features || [],
    };
    await sSet({ creditsRemaining: lic.credits_remaining, licenseData: lic });
    updateCreditsDisplay(lic.credits_remaining);
    licenseData = lic;
  } catch(e) { /* ignore */ }
}

// ══════════════════════════════════════════
// UTILITY FUNCTIONS
// ══════════════════════════════════════════
function esc(str) {
  return String(str || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function fmtNum(n) { return Number(n || 0).toLocaleString(); }
function fmtTime(s) {
  if (s < 60) return `${s}s`;
  if (s < 3600) return `${Math.round(s/60)}m`;
  return `${(s/3600).toFixed(1)}h`;
}
function datestamp() {
  return new Date().toISOString().slice(0,10).replace(/-/g,'');
}
function csvCell(v) {
  const s = String(v||'');
  return s.includes(',') || s.includes('"') || s.includes('\n') ? `"${s.replace(/"/g,'""')}"` : s;
}
function downloadFile(filename, content, mime) {
  const blob = new Blob([content], { type: mime });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href = url; a.download = filename;
  document.body.appendChild(a); a.click();
  document.body.removeChild(a); URL.revokeObjectURL(url);
}
function flashInput(id) {
  const el = document.getElementById(id);
  if (!el) return;
  el.classList.add('error');
  el.focus();
  setTimeout(() => el.classList.remove('error'), 1500);
}
function toggleEl(id) {
  const el = document.getElementById(id);
  if (el) { el.classList.toggle('on'); saveToggleState(id, el.classList.contains('on')); }
}
function toggleElState(id, state) {
  const el = document.getElementById(id);
  if (el) { if (state) el.classList.add('on'); else el.classList.remove('on'); }
}
async function saveToggleState(id, val) {
  const map = {
    'tog-phone':    'skipNoPhone',
    'tog-email':    'skipNoEmail',
    'tog-website':  'skipNoWebsite',
    'tog-find-email': 'findEmailFromWeb',
    
  };
  if (map[id]) await sSet({ [map[id]]: val });
}

// Auto-format license key input
const licInput = document.getElementById('lic-input');
if (licInput) {
  licInput.addEventListener('input', function() {
    let v = this.value.replace(/[^A-Z0-9a-z]/g,'').toUpperCase();
    v = v.replace(/(.{4})/g,'$1-').slice(0,19);
    this.value = v;
  });
}

// ══════════════════════════════════════════
// STORAGE CHANGE LISTENER
// ══════════════════════════════════════════
if (typeof chrome !== 'undefined' && chrome.storage) {
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    if (changes.creditsRemaining) updateCreditsDisplay(changes.creditsRemaining.newValue);
    if (changes.leads && changes.leads.newValue) {
      leads = changes.leads.newValue;
      if (curStep === 2) renderLeads();
      renderHomeRecent();
      updateExportCount();
    }
    if (changes.waConnected) {
      waConnected = changes.waConnected.newValue;
      waToken     = changes.waToken?.newValue || waToken;
      updateWAStatus();
    }
  });
}

// ══════════════════════════════════════════
// LEAD FOLDERS  (C3-B)
// ══════════════════════════════════════════
function renderFolderSelect() {
  const sel = document.getElementById('folder-select');
  if (!sel) return;
  const ids = Object.keys(folders);
  const allCount = (typeof getUnfolderedLeads === 'function') ? getUnfolderedLeads().length : leads.length;
  let html = `<option value="">📁 All Leads (${allCount})</option>`;
  ids.forEach(id => {
    const f = folders[id];
    const c = (f.leadIds || []).length;
    html += `<option value="${id}"${activeFolderFilter===id?' selected':''}>📁 ${esc(f.name)} (${c})</option>`;
  });
  sel.innerHTML = html;
}

function onFolderChange() {
  const sel = document.getElementById('folder-select');
  activeFolderFilter = sel?.value || '';
  sSet({ activeFolderFilter });
  renderLeads();
  updateExportCount();
}

function newFolder() {
  const name = prompt('Folder name:');
  if (!name || !name.trim()) return;
  const id = 'f_' + Date.now();
  folders[id] = { id, name: name.trim(), leadIds: [] };
  sSet({ folders });
  renderFolderSelect();
  renderCampaignFolderSelect();
}

function moveSelectedToFolder() {
  if (selectedLeads.size === 0) { alert('Select leads first.'); return; }
  const ids = Object.keys(folders);
  if (ids.length === 0) { alert('Create a folder first.'); return; }
  ensureLeadIds();
  let ov = document.getElementById('move-folder-overlay');
  if (ov) ov.remove();
  ov = document.createElement('div');
  ov.id = 'move-folder-overlay';
  ov.style.cssText = 'position:fixed;inset:0;z-index:9998;background:rgba(8,10,15,.85);backdrop-filter:blur(6px);display:flex;align-items:center;justify-content:center;padding:14px';
  const opts = ids.map(id => `<option value="${id}">📁 ${esc(folders[id].name)} (${(folders[id].leadIds||[]).length})</option>`).join('');
  ov.innerHTML = `
    <div style="width:100%;max-width:320px;background:linear-gradient(160deg,#1a1f2e,#0f1320);border:1px solid var(--or-glow);border-radius:14px;padding:16px;box-shadow:0 30px 80px rgba(0,0,0,.6)">
      <div style="font-weight:800;font-size:13px;color:#fff;margin-bottom:4px">↗ Move ${selectedLeads.size} lead(s)</div>
      <div style="font-size:11px;color:var(--w60);margin-bottom:10px">Choose destination folder</div>
      <select id="move-target-folder" style="width:100%;padding:9px 10px;border-radius:9px;background:#1a1a1a;border:1px solid var(--gbr);color:#fff;font-size:12px;font-weight:600;outline:none;margin-bottom:12px">${opts}</select>
      <div style="display:flex;gap:8px">
        <button id="mv-cancel" style="flex:1;padding:9px;border-radius:9px;border:1px solid var(--gbr);background:transparent;color:#fff;font-weight:600;font-size:12px;cursor:pointer">Cancel</button>
        <button id="mv-ok" style="flex:1;padding:9px;border-radius:9px;border:none;background:var(--or);color:#fff;font-weight:700;font-size:12px;cursor:pointer">✓ Move</button>
      </div>
    </div>`;
  document.body.appendChild(ov);
  ov.querySelector('#mv-cancel').onclick = () => ov.remove();
  ov.querySelector('#mv-ok').onclick = () => {
    const fid = ov.querySelector('#move-target-folder').value;
    if (!fid || !folders[fid]) { ov.remove(); return; }
    Object.keys(folders).forEach(other => {
      if (other === fid) return;
      folders[other].leadIds = (folders[other].leadIds || []).filter(lid => !selectedLeads.has(lid));
    });
    const set = new Set(folders[fid].leadIds || []);
    selectedLeads.forEach(lid => set.add(lid));
    folders[fid].leadIds = Array.from(set);
    sSet({ folders, leads });
    const moved = selectedLeads.size;
    selectedLeads.clear();
    renderFolderSelect();
    renderCampaignFolderSelect();
    renderLeads();
    updateBulkBar();
    ov.remove();
    showHuntMsg(`✅ Moved ${moved} lead(s) to "${folders[fid].name}".`,'ok');
  };
}

// ✅ Ensure every lead has a stable persistent _id (fixes folder membership for scraped leads)
function ensureLeadIds() {
  let changed = false;
  leads.forEach((l, i) => {
    if (!l._id) {
      l._id = 'l_' + Date.now().toString(36) + '_' + i + '_' + Math.random().toString(36).slice(2,6);
      changed = true;
    }
  });
  if (changed) sSet({ leads });
}

// ✅ Download selected leads as CSV (works even if no folder is set)
function downloadSelected() {
  if (selectedLeads.size === 0) { alert('Select leads first.'); return; }
  const data = getFilteredLeads().filter(l => selectedLeads.has(l._id));
  if (!data.length) { alert('No leads in current selection.'); return; }
  const headers = ['Name','Phone','Email','Website','Address','Category','Rating','WhatsApp'];
  const rows = data.map(l => [
    l.name||'', l.phone||'', l.email||'', l.website||'',
    l.address||'', l.category||'', l.rating||'', l.whatsapp||l.phone||''
  ].map(v => `"${String(v).replace(/"/g,'""')}"`).join(','));
  const csv = '\uFEFF' + [headers.join(','), ...rows].join('\n');
  downloadFile(`selected_leads_${datestamp()}.csv`, csv, 'text/csv;charset=utf-8;');
}

// ✅ Render folder selector inside Campaign / Send panels
function renderCampaignFolderSelect() {
  const sel = document.getElementById('campaign-folder');
  if (!sel) return;
  const ids = Object.keys(folders);
  const unfCount = (typeof getUnfolderedLeads === 'function') ? getUnfolderedLeads().length : leads.length;
  let html = `<option value="">📁 All Leads — unfoldered (${unfCount})</option>`;
  ids.forEach(id => {
    const f = folders[id];
    const c = (f.leadIds || []).length;
    html += `<option value="${id}">📁 ${esc(f.name)} (${c})</option>`;
  });
  sel.innerHTML = html;
  if (activeFolderFilter && folders[activeFolderFilter]) sel.value = activeFolderFilter;
  onCampaignFolderChange();
}

function onCampaignFolderChange() {
  const sel = document.getElementById('campaign-folder');
  const fid = sel?.value || '';
  if (fid && folders[fid]) {
    const ids = new Set(folders[fid].leadIds || []);
    // Only match by _id (never fall back to phone/name)
    campaignLeads = leads.filter(l => l._id && ids.has(l._id));
  } else {
    // No folder selected → use unfoldered leads
    campaignLeads = (typeof getUnfolderedLeads === 'function') ? getUnfolderedLeads() : leads.slice();
  }
  updateSendSummary();
  const lbl = document.getElementById('campaign-folder-count');
  if (lbl) lbl.textContent = `${campaignLeads.length} lead(s) targeted`;
}

// ══════════════════════════════════════════
// IMPORT LEADS (CSV / XLSX)  (C3-A)
// ══════════════════════════════════════════
function openImportPanel() {
  const p = document.getElementById('import-panel');
  if (p) p.style.display = 'block';
  importedRows = [];
  const btn = document.getElementById('import-btn');
  if (btn) btn.style.display = 'none';
  const prev = document.getElementById('import-preview');
  if (prev) { prev.style.display = 'none'; prev.innerHTML = ''; }
  const msg = document.getElementById('import-msg'); if (msg) msg.textContent = '';
  const fn = document.getElementById('import-filename'); if (fn) fn.textContent = 'No file selected';
  // Populate target folder dropdown
  const tgt = document.getElementById('import-target-folder');
  if (tgt) {
    const ids = Object.keys(folders);
    let html = `<option value="">All Leads (no folder)</option>`;
    ids.forEach(id => {
      const f = folders[id];
      const c = (f.leadIds || []).length;
      html += `<option value="${id}"${activeFolderFilter===id?' selected':''}>📁 ${esc(f.name)} (${c})</option>`;
    });
    tgt.innerHTML = html;
  }
  setupImportDropZone();
}

// ✅ Reliable file picker for Chrome extension popup — fresh input each time
function openImportFilePicker() {
  const inp = document.createElement('input');
  inp.type = 'file';
  inp.accept = '.csv,.xlsx,.xls';
  inp.style.display = 'none';
  inp.onchange = () => {
    if (inp.files && inp.files[0]) handleImportFile(inp);
    setTimeout(() => { try { inp.remove(); } catch(_){} }, 100);
  };
  document.body.appendChild(inp);
  inp.click();
}

let _importDropWired = false;
function setupImportDropZone() {
  if (_importDropWired) return;
  const dz = document.getElementById('import-drop-zone');
  if (!dz) return;
  _importDropWired = true;
  ['dragenter','dragover'].forEach(ev => dz.addEventListener(ev, e => {
    e.preventDefault(); e.stopPropagation();
    dz.style.background = 'rgba(241,98,50,.18)';
    dz.style.borderColor = 'var(--or)';
  }));
  ['dragleave','drop'].forEach(ev => dz.addEventListener(ev, e => {
    e.preventDefault(); e.stopPropagation();
    dz.style.background = 'rgba(0,0,0,.25)';
    dz.style.borderColor = 'var(--or-glow)';
  }));
  dz.addEventListener('drop', e => {
    const file = e.dataTransfer?.files?.[0];
    if (!file) return;
    const inp = document.getElementById('import-file');
    if (inp) {
      // assign via DataTransfer so handleImportFile reads it
      const dt = new DataTransfer();
      dt.items.add(file);
      inp.files = dt.files;
      handleImportFile(inp);
    }
  });
}
function closeImportPanel() {
  const p = document.getElementById('import-panel');
  if (p) p.style.display = 'none';
}

function parseCSVText(text) {
  const lines = text.replace(/\r/g,'').split('\n').filter(l => l.trim().length);
  if (lines.length < 2) return [];
  const splitRow = (line) => {
    const out = []; let cur = ''; let inQ = false;
    for (let i = 0; i < line.length; i++) {
      const ch = line[i];
      if (ch === '"') { if (inQ && line[i+1] === '"') { cur += '"'; i++; } else inQ = !inQ; }
      else if (ch === ',' && !inQ) { out.push(cur); cur = ''; }
      else cur += ch;
    }
    out.push(cur);
    return out;
  };
  const headers = splitRow(lines[0]).map(h => h.trim().toLowerCase());
  return lines.slice(1).map(line => {
    const cols = splitRow(line);
    const o = {};
    headers.forEach((h,i) => o[h] = (cols[i] || '').trim());
    return o;
  });
}

// Minimal XLSX (.xlsx) reader — extracts sheet1 cells as objects.
// Requires Chrome 115+ (DecompressionStream 'deflate-raw').
async function parseXLSXFile(file) {
  const buf = new Uint8Array(await file.arrayBuffer());
  const files = await unzipXLSX(buf);
  // Locate sheet1.xml (may be in xl/worksheets/sheet1.xml)
  const sheetEntry = Object.keys(files).find(n => /xl\/worksheets\/sheet1\.xml$/i.test(n));
  if (!sheetEntry) throw new Error('sheet1.xml not found inside .xlsx');
  const sheetXml = new TextDecoder().decode(files[sheetEntry]);
  // Shared strings (optional)
  let shared = [];
  const ssEntry = Object.keys(files).find(n => /xl\/sharedStrings\.xml$/i.test(n));
  if (ssEntry) {
    const ssXml = new TextDecoder().decode(files[ssEntry]);
    shared = Array.from(ssXml.matchAll(/<si[^>]*>([\s\S]*?)<\/si>/g)).map(m => {
      // concat all <t> nodes (handles rich text)
      return Array.from(m[1].matchAll(/<t[^>]*>([\s\S]*?)<\/t>/g))
        .map(t => decodeXmlEntities(t[1])).join('');
    });
  }
  // Parse rows
  const rowMatches = Array.from(sheetXml.matchAll(/<row[^>]*>([\s\S]*?)<\/row>/g));
  const rows = rowMatches.map(rm => {
    const row = [];
    const cellMatches = Array.from(rm[1].matchAll(/<c\b([^>]*)>([\s\S]*?)<\/c>/g));
    cellMatches.forEach(cm => {
      const attrs = cm[1];
      const inner = cm[2];
      const refMatch = attrs.match(/r="([A-Z]+)\d+"/);
      const colIdx = refMatch ? colLetterToIndex(refMatch[1]) : row.length;
      const tMatch = attrs.match(/t="([^"]+)"/);
      const type = tMatch ? tMatch[1] : 'n';
      let val = '';
      const vM = inner.match(/<v[^>]*>([\s\S]*?)<\/v>/);
      const isM = inner.match(/<is[^>]*>([\s\S]*?)<\/is>/);
      if (type === 's' && vM) {
        val = shared[parseInt(vM[1], 10)] || '';
      } else if (type === 'inlineStr' && isM) {
        val = Array.from(isM[1].matchAll(/<t[^>]*>([\s\S]*?)<\/t>/g))
          .map(t => decodeXmlEntities(t[1])).join('');
      } else if (vM) {
        val = decodeXmlEntities(vM[1]);
      }
      while (row.length < colIdx) row.push('');
      row[colIdx] = val;
    });
    return row;
  });
  // First non-empty row = headers
  const firstIdx = rows.findIndex(r => r.some(c => String(c).trim() !== ''));
  if (firstIdx < 0) return [];
  const headers = rows[firstIdx].map(h => String(h || '').trim().toLowerCase());
  return rows.slice(firstIdx + 1)
    .filter(r => r.some(c => String(c).trim() !== ''))
    .map(r => {
      const o = {};
      headers.forEach((h, i) => { if (h) o[h] = String(r[i] || '').trim(); });
      return o;
    });
}

function colLetterToIndex(letters) {
  let n = 0;
  for (let i = 0; i < letters.length; i++) n = n * 26 + (letters.charCodeAt(i) - 64);
  return n - 1;
}
function decodeXmlEntities(s) {
  return String(s)
    .replace(/&lt;/g, '<').replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"').replace(/&apos;/g, "'")
    .replace(/&#(\d+);/g, (_, d) => String.fromCharCode(+d))
    .replace(/&amp;/g, '&');
}

// ZIP central-directory parser + per-entry deflate inflater (DecompressionStream).
async function unzipXLSX(bytes) {
  const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  // Find End-of-Central-Directory record (search backwards for 0x06054b50)
  let eocd = -1;
  for (let i = bytes.length - 22; i >= Math.max(0, bytes.length - 65557); i--) {
    if (dv.getUint32(i, true) === 0x06054b50) { eocd = i; break; }
  }
  if (eocd < 0) throw new Error('Invalid .xlsx (EOCD not found)');
  const cdEntries = dv.getUint16(eocd + 10, true);
  const cdOffset  = dv.getUint32(eocd + 16, true);
  const out = {};
  let p = cdOffset;
  for (let i = 0; i < cdEntries; i++) {
    if (dv.getUint32(p, true) !== 0x02014b50) throw new Error('Bad central dir signature');
    const method     = dv.getUint16(p + 10, true);
    const compSize   = dv.getUint32(p + 20, true);
    const nameLen    = dv.getUint16(p + 28, true);
    const extraLen   = dv.getUint16(p + 30, true);
    const commentLen = dv.getUint16(p + 32, true);
    const localOff   = dv.getUint32(p + 42, true);
    const name = new TextDecoder().decode(bytes.subarray(p + 46, p + 46 + nameLen));
    p += 46 + nameLen + extraLen + commentLen;
    // Read local header
    const lhNameLen  = dv.getUint16(localOff + 26, true);
    const lhExtraLen = dv.getUint16(localOff + 28, true);
    const dataStart  = localOff + 30 + lhNameLen + lhExtraLen;
    const compData   = bytes.subarray(dataStart, dataStart + compSize);
    let raw;
    if (method === 0) {
      raw = compData;
    } else if (method === 8) {
      // deflate-raw
      const ds = new DecompressionStream('deflate-raw');
      const stream = new Blob([compData]).stream().pipeThrough(ds);
      raw = new Uint8Array(await new Response(stream).arrayBuffer());
    } else {
      continue; // unsupported method
    }
    out[name] = raw;
  }
  return out;
}

async function handleImportFile(input) {
  const file = input.files?.[0];
  if (!file) return;
  const fn = document.getElementById('import-filename'); if (fn) fn.textContent = file.name;
  const msg = document.getElementById('import-msg');
  try {
    let rows = [];
    if (file.name.match(/\.(xlsx|xls)$/i)) {
      rows = await parseXLSXFile(file);
    } else {
      const text = await file.text();
      rows = parseCSVText(text);
    }
    importedRows = rows;
    const prev = document.getElementById('import-preview');
    if (prev) {
      prev.style.display = 'block';
      const sample = rows.slice(0,5).map(r =>
        `<div style="padding:3px 0;border-bottom:1px solid var(--gbr)">
          <strong>${esc(r.name||r.business||'—')}</strong> · ${esc(r.phone||'')} · ${esc(r.email||'')}
         </div>`).join('');
      prev.innerHTML = `<div style="margin-bottom:4px;color:var(--or);font-weight:700">${rows.length} rows found · preview (first 5)</div>${sample}`;
    }
    const btn = document.getElementById('import-btn');
    if (btn) btn.style.display = 'block';
    if (msg) msg.textContent = '';
  } catch (e) {
    if (msg) msg.textContent = '❌ Parse error: ' + e.message;
  } finally {
    input.value = '';
  }
}

function confirmImport() {
  if (!importedRows.length) return;
  const existingPhones = new Set(leads.map(l => (l.phone||'').replace(/\D/g,'')).filter(Boolean));
  let added = 0;
  const newIds = [];
  importedRows.forEach((r, i) => {
    const phoneNorm = (r.phone || r['phone number'] || '').replace(/\D/g,'');
    if (phoneNorm && existingPhones.has(phoneNorm)) return;
    const lead = {
      name:     r.name || r.business || r['business name'] || '—',
      phone:    r.phone || r['phone number'] || '—',
      email:    r.email || '—',
      website:  r.website || r.web || '—',
      address:  r.address || '—',
      category: r.category || '—',
      rating:   r.rating || '—',
      whatsapp: r.whatsapp || phoneNorm || '',
      source:   'imported',
      importedAt: Date.now(),
      _id:      'imp_' + Date.now() + '_' + i,
    };
    leads.push(lead);
    newIds.push(lead._id);
    if (phoneNorm) existingPhones.add(phoneNorm);
    added++;
  });
  // ✅ Folder-aware import: prefer the import-panel target folder; fall back to active filter
  const tgtSel = document.getElementById('import-target-folder');
  const targetFid = tgtSel ? tgtSel.value : (activeFolderFilter || '');
  let movedToFolder = '';
  if (targetFid && folders[targetFid]) {
    const set = new Set(folders[targetFid].leadIds || []);
    newIds.forEach(id => set.add(id));
    folders[targetFid].leadIds = Array.from(set);
    movedToFolder = folders[targetFid].name;
    sSet({ leads, folders });
  } else {
    sSet({ leads });
  }
  renderLeads();
  renderHomeRecent();
  renderFolderSelect();
  if (typeof renderCampaignFolderSelect === 'function') renderCampaignFolderSelect();
  updateExportCount();
  const msg = document.getElementById('import-msg');
  if (msg) msg.textContent = movedToFolder
    ? `✅ Imported ${added} leads into folder "${movedToFolder}" (${importedRows.length - added} duplicates skipped).`
    : `✅ Imported ${added} new leads (${importedRows.length - added} duplicates skipped).`;
  importedRows = [];
  setTimeout(closeImportPanel, 1800);
}

// ══════════════════════════════════════════
// BOOT — License Gate
// ══════════════════════════════════════════
document.addEventListener('DOMContentLoaded', async () => {

  const stored = await sGet(['licenseKey', 'licenseData', 'creditsRemaining']);

  const hasActiveLicense = stored.licenseKey
    && stored.licenseData?.status === 'active';

  if (!hasActiveLicense) {
    // No license → go to Plans tab
    renderStepNav();
    updateFooter();
    goStep(99);  // Plans panel
    return;
  }

  // License found → show main dashboard
  licenseKey  = stored.licenseKey;
  licenseData = stored.licenseData;
  renderStepNav();
  updateFooter();
  init();
});

if (typeof chrome !== 'undefined' && chrome.runtime) {
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.action === 'onboardingComplete') {
      renderStepNav();
      updateFooter();
      init();
    }
  });
}

// ══════════════════════════════════════════
// EVENT DELEGATION — replaces all onclick="" HTML attributes
// MV3 CSP does not allow inline event handlers
// ══════════════════════════════════════════
document.addEventListener('click', function(e) {
  const el = e.target.closest('[data-action]');
  if (!el) return;
  e.preventDefault();

  const raw = el.getAttribute('data-action') || '';
  // Special raw cases (must run BEFORE the regex match — they contain
  // nested parens like document.getElementById('x').click())
  if (raw === "document.getElementById('csv-file').click()") {
    const f = document.getElementById('csv-file'); if (f) { f.value = ''; f.click(); } return;
  }
  if (raw === "document.getElementById('import-file').click()") {
    const f = document.getElementById('import-file'); if (f) { f.value = ''; f.click(); } return;
  }
  if (raw === "document.getElementById('payment-form').style.display='none'") {
    const pf = document.getElementById('payment-form'); if(pf) pf.style.display='none'; return;
  }
  if (raw === "showLicenseInput();return false;") { showLicenseInput(); return; }
  if (raw === "showPlansAgain();return false;")   { showPlansAgain();   return; }

  // Parse function name and args (supports quoted strings containing commas / parens)
  const openIdx = raw.indexOf('(');
  const closeIdx = raw.lastIndexOf(')');
  if (openIdx < 0 || closeIdx < openIdx) return;
  const fnName  = raw.slice(0, openIdx).trim();
  const argsRaw = raw.slice(openIdx + 1, closeIdx);

  // Tokenize args respecting quotes
  let args = [];
  if (argsRaw.trim()) {
    const tokens = [];
    let cur = '', inStr = null, depth = 0;
    for (let i = 0; i < argsRaw.length; i++) {
      const ch = argsRaw[i];
      if (inStr) {
        cur += ch;
        if (ch === inStr && argsRaw[i-1] !== '\\') inStr = null;
      } else if (ch === "'" || ch === '"') { inStr = ch; cur += ch; }
      else if (ch === '(') { depth++; cur += ch; }
      else if (ch === ')') { depth--; cur += ch; }
      else if (ch === ',' && depth === 0) { tokens.push(cur); cur = ''; }
      else cur += ch;
    }
    if (cur.trim() !== '' || tokens.length > 0) tokens.push(cur);
    args = tokens.map(a => {
      a = a.trim();
      if ((a.startsWith("'") && a.endsWith("'")) || (a.startsWith('"') && a.endsWith('"'))) {
        return a.slice(1, -1).replace(/\\(['"\\])/g, '$1');
      }
      if (a === 'this') return el;
      if (a === 'true') return true;
      if (a === 'false') return false;
      if (a === 'null') return null;
      const n = Number(a);
      return (a !== '' && !isNaN(n)) ? n : a;
    });
  }

  // Resolve function
  const parts = fnName.split('.');
  let fn = window;
  for (const p of parts) { fn = fn?.[p]; }
  if (typeof fn === 'function') fn(...args);
});

// Also handle oninput and onchange events that were in HTML
document.addEventListener('input', function(e) {
  const el = e.target;
  if (el.id === 'max-slider') {
    const lbl = document.getElementById('max-lbl');
    if(lbl) lbl.textContent = el.value;
  }
  if (el.id === 'delay-slider') setDelay(el.value);
  if (el.id === 'wa-delay')     setWADelay(el.value);
  if (el.id === 'em-delay')     setEMDelay(el.value);
  if (el.id === 'leads-search') filterLeads();
  if (el.id === 'wa-msg')       updateWAPreview();
  if (el.id === 'email-subject') updateEmailPreview();
  if (el.id === 'email-body')    updateEmailPreview();
  // Plans panel license key formatter
  if (el.id === 'ob-lic-input') {
    let v = el.value.replace(/[^A-Z0-9a-z]/g,'').toUpperCase();
    v = v.startsWith('LHP') ? 'LHP-' + v.slice(3).replace(/(.{4})/g,'$1-').slice(0,14) : v.replace(/(.{4})/g,'$1-').slice(0,19);
    el.value = v.replace(/-+$/,'');
  }
});

document.addEventListener('change', function(e) {
  const el = e.target;
  if (el.id === 'country') sSet({ country: el.value });
  if (el.id === 'csv-file') handleCSV(el);
  if (el.id === 'import-file') handleImportFile(el);
  if (el.id === 'campaign-folder') onCampaignFolderChange();
  if (el.id === 'folder-select')   onFolderChange();
  if (el.id === 'move-target-folder') { /* dialog only — handled on confirm */ }
});
