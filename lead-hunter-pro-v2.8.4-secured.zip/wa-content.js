// ════════════════════════════════════════════════════════════════
// LEAD HUNTER PRO — WhatsApp Web Content Script
// Runs inside web.whatsapp.com — handles DOM injection, send,
// always-online, auto-read, ready detection, floating badge.
// ════════════════════════════════════════════════════════════════
'use strict';

(() => {
  if (window.__LHP_WA_INJECTED__) return;
  window.__LHP_WA_INJECTED__ = true;

  const SELECTORS = {
    chatInput: [
      'div[aria-label*="Add a caption" i][contenteditable="true"]',
      '[data-testid*="caption" i] div[contenteditable="true"]',
      'footer div[contenteditable="true"][data-tab]',
      'footer div[contenteditable="true"]',
      'div[contenteditable="true"][data-tab="10"]',
      'div[title="Type a message"]',
      '[data-testid="conversation-compose-box-input"]'
    ],
    sendBtn: [
      'span[data-icon="send"]',
      'span[data-icon="wds-ic-send-filled"]',
      'button[aria-label="Send"]',
      'div[role="button"][aria-label="Send"]',
      '[data-testid="send"]'
    ],
    paneSide: '#pane-side, [data-testid="chat-list"]',
    invalidModal: '[data-animate-modal-popup="true"]'
  };

  const sleep = (ms) => new Promise(r => setTimeout(r, ms));
  const lastDigits = (v, n = 7) => String(v || '').replace(/\D/g, '').slice(-n);

  function log(...a) { console.log('%c[LHP-WA]', 'color:#25D366;font-weight:bold', ...a); }
  function isVisible(el) {
    if (!el || !el.isConnected) return false;
    const r = el.getBoundingClientRect();
    const st = getComputedStyle(el);
    return r.width > 0 && r.height > 0 && st.visibility !== 'hidden' && st.display !== 'none';
  }
  function textOf(el) {
    return String(el?.innerText || el?.textContent || el?.getAttribute?.('aria-label') || el?.getAttribute?.('title') || '').replace(/\s+/g, ' ').trim();
  }
  function clickElement(el) {
    if (!el) return false;
    const target = el.closest?.('button, [role="button"], [role="row"], [role="listitem"], [data-testid="cell-frame-container"]') || el;
    try {
      target.scrollIntoView?.({ block:'center', inline:'nearest' });
      target.dispatchEvent(new MouseEvent('mousedown', { bubbles:true, cancelable:true, view:window }));
      target.dispatchEvent(new MouseEvent('mouseup', { bubbles:true, cancelable:true, view:window }));
      target.dispatchEvent(new MouseEvent('click', { bubbles:true, cancelable:true, view:window }));
      return true;
    } catch(e) {
      try { target.click(); return true; } catch(_) { return false; }
    }
  }
  function key(el, keyName, code = keyName, keyCode = 0) {
    const target = el || document.activeElement || document.body;
    ['keydown', 'keyup'].forEach(type => target.dispatchEvent(new KeyboardEvent(type, {
      key:keyName, code, keyCode, which:keyCode, bubbles:true, cancelable:true
    })));
  }
  function queryVisible(selectors, root = document) {
    for (const sel of selectors) {
      const nodes = Array.from(root.querySelectorAll(sel));
      const found = nodes.find(isVisible);
      if (found) return found;
    }
    return null;
  }
  async function waitForVisible(selectors, root = document, attempts = 24, delay = 250) {
    for (let i = 0; i < attempts; i++) {
      const el = queryVisible(selectors, root);
      if (el) return el;
      await sleep(delay);
    }
    return null;
  }
  async function setSearchText(el, value) {
    if (!el) return false;
    const text = String(value || '');
    clickElement(el);
    el.focus?.();
    await sleep(80);
    try { document.execCommand('selectAll', false, null); document.execCommand('delete', false, null); } catch(_) {}

    if ('value' in el) {
      const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
      try { setter ? setter.call(el, text) : (el.value = text); } catch(_) { el.value = text; }
      el.dispatchEvent(new Event('input', { bubbles:true }));
      el.dispatchEvent(new Event('change', { bubbles:true }));
    } else {
      try {
        const dt = new DataTransfer();
        dt.setData('text/plain', text);
        el.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles:true, cancelable:true }));
      } catch(_) {}
      await sleep(120);
      const current = textOf(el).replace(/\D/g, '');
      if (text && !current.includes(lastDigits(text, 5))) {
        try { document.execCommand('insertText', false, text); } catch(_) {}
      }
      await sleep(120);
      const afterInsert = textOf(el).replace(/\D/g, '');
      if (text && !afterInsert.includes(lastDigits(text, 5))) {
        try { el.textContent = text; } catch(_) {}
      }
      el.dispatchEvent(new InputEvent('input', { bubbles:true, inputType:'insertText', data:text }));
    }
    if (text) {
      key(el, ' ', 'Space', 32);
      await sleep(40);
      key(el, 'Backspace', 'Backspace', 8);
    }
    return true;
  }

  // ── floating badge ────────────────────────────────────────────
  function injectBadge() {
    if (document.getElementById('lhp-wa-badge')) return;
    const el = document.createElement('div');
    el.id = 'lhp-wa-badge';
    el.style.cssText = `
      position:fixed;bottom:14px;right:14px;z-index:2147483647;
      background:linear-gradient(135deg,#128C7E,#25D366);color:#fff;
      font:600 12px/1.2 -apple-system,Segoe UI,sans-serif;
      padding:8px 12px;border-radius:20px;
      box-shadow:0 4px 14px rgba(0,0,0,.25);cursor:default;
      display:flex;align-items:center;gap:6px;user-select:none;`;
    el.innerHTML = `<span style="width:8px;height:8px;border-radius:50%;background:#fff;display:inline-block"></span>Lead Hunter Pro · <span id="lhp-wa-badge-state">Loading…</span>`;
    document.documentElement.appendChild(el);
  }
  function setBadge(state) {
    const s = document.getElementById('lhp-wa-badge-state');
    if (s) s.textContent = state;
  }

  function isLoggedIn() {
    return !!document.querySelector(SELECTORS.paneSide);
  }

  // ── chat helpers ──────────────────────────────────────────────
  function findChatInput() {
    for (const sel of SELECTORS.chatInput) {
      const el = document.querySelector(sel);
      if (el) return el;
    }
    return null;
  }
  function findSendBtn() {
    for (const sel of SELECTORS.sendBtn) {
      const el = document.querySelector(sel);
      if (el) return el.closest('button, div[role="button"]') || el;
    }
    return null;
  }
  function checkInvalidModal() {
    const modal = document.querySelector(SELECTORS.invalidModal);
    if (!modal) return false;
    const txt = (modal.innerText || '').toLowerCase();
    if (txt.includes('not on whatsapp') || txt.includes('phone number shared')
        || txt.includes('invalid') || txt.includes('shared via url')) {
      const btn = modal.querySelector('button');
      if (btn) btn.click();
      return true;
    }
    return false;
  }

  function checkPhoneNotOnWhatsApp() {
    const modalText = document.body.innerText || '';
    return modalText.includes('not registered') ||
           modalText.includes('Phone number shared') ||
           modalText.includes('not on WhatsApp');
  }

  function findSideSearchInput() {
    return queryVisible([
      '#side input[type="text"]',
      '#side [role="textbox"][contenteditable="true"]',
      '#side div[contenteditable="true"][data-tab]',
      'input[placeholder*="Search" i]',
      '[aria-label*="Search" i][contenteditable="true"]',
      'div[data-testid="chat-list-search-input"]'
    ]);
  }

  // Find the open "+ New chat" panel container (NOT the left sidebar).
  function findNewChatPanel() {
    // Look for any visible header containing exactly "New chat" outside #side / #pane-side.
    const candidates = Array.from(document.querySelectorAll('header, h1, h2, span, div'));
    for (const el of candidates) {
      if (!isVisible(el)) continue;
      const t = (el.textContent || '').trim();
      if (!/^new chat$/i.test(t)) continue;
      if (el.closest('#side') || el.closest('#pane-side')) continue;
      // walk up to find the panel container
      let p = el;
      for (let i = 0; i < 8 && p && p.parentElement; i++) p = p.parentElement;
      return p || el;
    }
    // fallback: explicit aria-labelled search
    const explicit = document.querySelector('[aria-label="Search name or number" i], [aria-label*="Search name or number" i]');
    if (explicit && isVisible(explicit) && !explicit.closest('#side') && !explicit.closest('#pane-side')) {
      let p = explicit;
      for (let i = 0; i < 8 && p && p.parentElement; i++) p = p.parentElement;
      return p;
    }
    return null;
  }

  function findNewChatInput() {
    const panel = findNewChatPanel();
    if (!panel) return null;
    const inputs = Array.from(panel.querySelectorAll([
      '[aria-label*="Search name or number" i]',
      '[role="textbox"][contenteditable="true"]',
      'div[contenteditable="true"][data-tab]',
      'input[type="text"]',
      'input[placeholder*="Search" i]',
      'div[data-testid="new-chat-search-input"]'
    ].join(',')));
    return inputs.find(el => isVisible(el) && !el.closest('footer')
      && !el.closest('#side') && !el.closest('#pane-side')) || null;
  }

  function isBadResultRow(row) {
    const t = textOf(row).toLowerCase();
    if (!t) return true;
    return t.includes('new group') || t.includes('new contact') || t === 'new chat' || t.includes('new community')
        || t.includes('contacts on whatsapp') || t.includes('no chats') || t.includes('no results')
        || t.includes('searching') || t.includes('invite to whatsapp');
  }

  function findBestResultRow(clean, scopeSelector, allowFirstVisible = true) {
    const scopes = scopeSelector ? Array.from(document.querySelectorAll(scopeSelector)) : [document];
    const tail = lastDigits(clean);
    const rows = [];
    for (const scope of scopes) {
      rows.push(...Array.from(scope.querySelectorAll([
        '[data-testid="cell-frame-container"]',
        '[role="listitem"]',
        '[role="row"]',
        '[role="button"]'
      ].join(','))));
    }
    const valid = rows.filter(row => isVisible(row) && !isBadResultRow(row));
    const exact = valid.find(row => {
      const compact = textOf(row).replace(/\D/g, '');
      return compact.includes(clean) || (tail && compact.includes(tail));
    });
    if (exact) return exact;
    const chatWith = valid.find(row => /chat|message|whatsapp/i.test(textOf(row)));
    if (chatWith) return chatWith;
    return allowFirstVisible ? valid[0] || null : null;
  }

  async function clickResultAndWait(row, attempts = 40) {
    if (!row) return false;
    clickElement(row);
    const opened = await waitForChatInput(attempts);
    return !!opened.ok;
  }

  async function openNewChatPanel() {
    // If panel is already open, return its scoped input.
    if (findNewChatPanel()) {
      const existing = findNewChatInput();
      if (existing) return existing;
    }

    const newChatSelectors = [
      'button[aria-label="New chat" i]',
      '[aria-label="New chat" i]',
      '[title="New chat" i]',
      'span[data-icon="new-chat-outline"]',
      'span[data-icon="new-chat"]',
      'span[data-icon="chat-plus"]',
      'span[data-icon="plus-rounded"]',
      '[data-testid="new-chat-btn"]',
      'button[title*="New chat" i]',
      '[aria-label*="New chat" i]',
    ];
    let btn = null;
    for (const sel of newChatSelectors) {
      const els = Array.from(document.querySelectorAll(sel));
      const el = els.find(e => isVisible(e) && !e.closest('#pane-side'));
      if (el) { btn = el; break; }
    }
    if (btn) {
      // Walk up to a clickable ancestor (button / role=button / li).
      let target = btn;
      for (let i = 0; i < 6 && target.parentElement; i++) {
        const tag = target.tagName;
        const role = target.getAttribute && target.getAttribute('role');
        if (tag === 'BUTTON' || tag === 'LI' || role === 'button') break;
        target = target.parentElement;
      }
      clickElement(target);
    }

    // Poll up to ~3s for the New-chat panel to actually appear.
    for (let i = 0; i < 24; i++) {
      await sleep(125);
      if (findNewChatPanel()) break;
    }
    return findNewChatInput();
  }

  // ✅ DOM-only navigation. New-chat panel FIRST (works for unsaved numbers).
  async function navigateToChat(phone) {
    const clean = String(phone || '').replace(/\D/g, '');
    if (!clean) return { ok:false, reason:'Empty phone' };
    const tail = lastDigits(clean, 7);

    // ── Quick pre-check: if number is already an open/visible row in #pane-side, click it.
    try {
      const existingRows = Array.from(document.querySelectorAll('#pane-side [role="listitem"], #pane-side [role="row"], #pane-side [data-testid="cell-frame-container"]'));
      const hit = existingRows.find(row => {
        if (!isVisible(row) || isBadResultRow(row)) return false;
        const compact = textOf(row).replace(/\D/g, '');
        return tail && compact.includes(tail);
      });
      if (hit && await clickResultAndWait(hit, 24)) return { ok:true };
    } catch(_) {}

    // ── PRIMARY PATH: + New chat panel ──
    log('Opening New Chat panel for:', clean);
    let newChatInput = await openNewChatPanel();

    if (newChatInput) {
      const tries = [clean];
      for (const query of tries) {
        await setSearchText(newChatInput, query);
        await sleep(2600);
        if (checkInvalidModal() || checkPhoneNotOnWhatsApp()) {
          return { ok:false, reason:'Number not on WhatsApp' };
        }
        const panel = findNewChatPanel() || document;
        // Prefer "Chat with +X" affordance for unsaved numbers — scoped to panel.
        const allRows = Array.from(panel.querySelectorAll('[role="listitem"], [role="row"], [role="button"], [data-testid="cell-frame-container"]'))
          .filter(r => isVisible(r) && !isBadResultRow(r) && !r.closest('#pane-side'));
        const chatWith = allRows.find(r => {
          const t = textOf(r).toLowerCase();
          const aria = (r.getAttribute('aria-label') || '').toLowerCase();
          return t.startsWith('chat with') || aria.startsWith('chat with') || /message\s+\+?\d/.test(t);
        });
        let row = chatWith;
        if (!row) {
          row = allRows.find(r => {
            const compact = textOf(r).replace(/\D/g, '');
            return tail && compact.includes(tail);
          }) || allRows.find(r => /\+?\d{6,}/.test(textOf(r)));
        }
        if (await clickResultAndWait(row, 50)) return { ok:true };

        key(newChatInput, 'Enter', 'Enter', 13);
        const opened = await waitForChatInput(24);
        if (opened.ok) return { ok:true };
      }
      try { key(newChatInput, 'Escape', 'Escape', 27); } catch(_) {}
    }

    // ── FALLBACK: sidebar search (for saved contacts) ──
    log('New-chat path failed — trying sidebar search for:', clean);
    let searchInput = findSideSearchInput();
    if (!searchInput) {
      const ic = document.querySelector('span[data-icon="search"], span[data-icon="search-refreshed"]');
      if (ic && isVisible(ic)) clickElement(ic);
      await sleep(400);
      searchInput = findSideSearchInput();
    }
    if (searchInput) {
      await setSearchText(searchInput, clean);
      await sleep(2200);
      const row = findBestResultRow(clean, '#pane-side, #side', false);
      if (await clickResultAndWait(row, 36)) return { ok:true };
      try { await setSearchText(searchInput, ''); key(searchInput, 'Escape', 'Escape', 27); } catch(_) {}
    }

    // URL/anchor navigation intentionally removed: it caused web.whatsapp.com
    // to reload/blank-out. Rely on PATH A + B (pure DOM) only.
    log('Both DOM paths failed for:', clean);
    return { ok:false, reason:'Could not open chat via search or new-chat' };
  }

  async function waitForChatInput(maxAttempts = 30) {
    for (let i = 0; i < maxAttempts; i++) {
      if (checkInvalidModal()) return { ok:false, reason:'Not on WhatsApp' };
      if (checkPhoneNotOnWhatsApp()) return { ok:false, reason:'Number not on WhatsApp' };
      const el = findChatInput();
      if (el) { await sleep(400); return { ok:true, el }; }
      await sleep(500);
    }
    return { ok:false, reason:'Chat input did not load' };
  }

  async function typeMessage(el, text) {
    el.focus();
    // Click to ensure focus
    el.dispatchEvent(new MouseEvent('mousedown', { bubbles:true }));
    el.dispatchEvent(new MouseEvent('mouseup', { bubbles:true }));
    el.dispatchEvent(new MouseEvent('click', { bubbles:true }));

    // Paste via DataTransfer + ClipboardEvent
    try {
      const dt = new DataTransfer();
      dt.setData('text/plain', text);
      el.dispatchEvent(new ClipboardEvent('paste', {
        clipboardData: dt, bubbles:true, cancelable:true
      }));
    } catch(e) { /* ignore */ }

    await sleep(250);

    // Fallback / trigger React: insertText, then dummy char trick
    const cur = el.innerText || el.textContent || '';
    if (!cur.trim()) {
      try { document.execCommand('insertText', false, text); } catch(e) {}
    }
    await sleep(120);
    try {
      document.execCommand('insertText', false, ' ');
      await sleep(40);
      document.execCommand('delete', false, null);
    } catch(e) {}
    el.dispatchEvent(new InputEvent('input', { bubbles:true, inputType:'insertText' }));
    await sleep(120);
  }

  async function clickSend(el) {
    const btn = findSendBtn();
    if (btn) {
      btn.click();
      return true;
    }
    // Fallback Enter key
    el.dispatchEvent(new KeyboardEvent('keydown', {
      key:'Enter', code:'Enter', keyCode:13, which:13, bubbles:true, cancelable:true
    }));
    return true;
  }

  function findPreviewOverlay() {
    // The media-preview overlay that mounts after a file is attached.
    return document.querySelector('div[data-animate-modal-popup="true"], div[role="application"] [data-animate-modal-body="true"]')
        || document.querySelector('[data-testid="media-composer"]')
        || null;
  }
  function findCaptionInput(scope = document) {
    const sels = [
      'div[aria-label*="caption" i][contenteditable="true"]',
      '[data-testid*="caption" i] div[contenteditable="true"]',
      'div[contenteditable="true"][data-tab]'
    ];
    for (const sel of sels) {
      const nodes = Array.from(scope.querySelectorAll(sel));
      const el = nodes.find(isVisible);
      if (el) return el;
    }
    return null;
  }
  async function waitForPreviewOverlay(maxAttempts = 30) {
    for (let i = 0; i < maxAttempts; i++) {
      const ov = findPreviewOverlay();
      if (ov) { await sleep(300); return ov; }
      // Some WA builds don't wrap preview in modal — fall back to caption input presence
      const cap = findCaptionInput();
      if (cap) return cap.closest('[data-animate-modal-popup], div[role="application"], footer') || document.body;
      await sleep(300);
    }
    return null;
  }
  async function waitForPreviewClosed(maxAttempts = 40) {
    for (let i = 0; i < maxAttempts; i++) {
      if (!findPreviewOverlay() && !findCaptionInput()) return true;
      await sleep(250);
    }
    return false;
  }

  function setReactFiles(input, fileList) {
    try {
      const desc = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'files');
      if (desc && desc.set) { desc.set.call(input, fileList); return; }
    } catch(_){}
    try { Object.defineProperty(input, 'files', { value: fileList, configurable: true }); }
    catch(_) { try { input.files = fileList; } catch(__){} }
  }

  function logAttachStatus(reason) {
    try { chrome.storage.local.set({ campaignLastLog: '📎 attach: ' + reason }); } catch(_){}
  }

  function findFooter() {
    return document.querySelector('footer') ||
           document.querySelector('[data-testid="conversation-footer"]') ||
           document.querySelector('div[role="application"] footer') ||
           document.body;
  }

  function findClipButton() {
    const footer = findFooter();
    const sels = [
      'button[aria-label="Attach" i]',
      'div[role="button"][aria-label="Attach" i]',
      'button[title="Attach" i]',
      'div[title="Attach" i]',
      'span[data-icon="plus-rounded-light"]',
      'span[data-icon="plus-rounded"]',
      'span[data-icon="plus"]',
      'span[data-icon="attach-menu-plus"]',
      'span[data-icon="attach"]',
      'span[data-icon="clip"]',
      '[data-testid="clip"]',
      '[data-testid="conversation-clip"]',
    ];
    for (const sel of sels) {
      const nodes = Array.from(footer.querySelectorAll(sel))
        .concat(Array.from(document.querySelectorAll(sel)));
      for (const n of nodes) {
        if (!isVisible(n)) continue;
        const clickable = n.closest('button, div[role="button"], [aria-label]') || n;
        return clickable;
      }
    }
    return null;
  }

  async function openAttachMenu() {
    // Returns true if menu detected open
    const isMenuOpen = () =>
      !!document.querySelector('[data-testid="attach-menu"], div[role="application"] [role="menu"], ul[aria-label*="attach" i], li[data-animate-attach-image]');
    if (isMenuOpen()) return true;
    for (let attempt = 0; attempt < 3; attempt++) {
      const btn = findClipButton();
      if (!btn) { await sleep(300); continue; }
      try { btn.click(); } catch(_){ clickElement(btn); }
      for (let i = 0; i < 10; i++) {
        await sleep(200);
        if (isMenuOpen()) return true;
      }
    }
    return isMenuOpen();
  }

  async function tryPasteFileIntoInput(file) {
    const input = findChatInput();
    if (!input) return false;
    try { input.focus(); } catch(_){}
    try {
      const dt = new DataTransfer();
      dt.items.add(file);
      const ev = new ClipboardEvent('paste', {
        clipboardData: dt, bubbles: true, cancelable: true
      });
      input.dispatchEvent(ev);
    } catch(_) { return false; }
    // Wait for preview
    for (let i = 0; i < 12; i++) {
      await sleep(200);
      if (findPreviewOverlay() || findCaptionInput()) return true;
    }
    return false;
  }

  async function attachFileToChat(attachDataUrl, attachMeta, captionText) {
    try {
      const res  = await fetch(attachDataUrl);
      const blob = await res.blob();
      const fileType = attachMeta.type || blob.type || '';
      const isImage = /^image\//i.test(fileType);
      const isVideo = /^video\//i.test(fileType);
      const wantPhotos = isImage || isVideo;
      const file = new File([blob], attachMeta.name || 'file', { type: fileType || 'application/octet-stream' });

      let previewReady = false;

      // ── Path A: paste-into-chat-input (fastest, no menu needed) ──
      previewReady = await tryPasteFileIntoInput(file);

      // ── Path B: clip-menu → submenu → hidden file input ──
      if (!previewReady) {
        const menuOpened = await openAttachMenu();
        if (!menuOpened) {
          logAttachStatus('clip/menu not found');
          return { ok:false, reason:'attach menu not found' };
        }

        // submenu match (aria-label OR title OR text)
        const subWanted = wantPhotos
          ? /photos?\s*(?:&|and)?\s*videos?|photo|image|video|gallery/i
          : /document|file/i;
        let subClicked = false;
        for (let pass = 0; pass < 8 && !subClicked; pass++) {
          const candidates = Array.from(document.querySelectorAll(
            'li, [role="menuitem"], button, div[role="button"], [data-testid*="attach" i]'
          ));
          for (const node of candidates) {
            if (!isVisible(node)) continue;
            const aria = (node.getAttribute('aria-label') || '') + ' ' + (node.getAttribute('title') || '');
            const t = (textOf(node) || '') + ' ' + aria;
            if (subWanted.test(t)) {
              clickElement(node);
              subClicked = true;
              await sleep(400);
              break;
            }
          }
          if (!subClicked) await sleep(200);
        }

        // hidden file input — poll up to 3s
        let fileInput = null;
        for (let i = 0; i < 15 && !fileInput; i++) {
          const inputs = Array.from(document.querySelectorAll('input[type="file"]'));
          const visibleOrAny = inputs;
          if (wantPhotos) {
            fileInput = visibleOrAny.find(inp => /image|video/i.test(inp.accept || ''))
                     || (subClicked ? null : visibleOrAny[visibleOrAny.length - 1]);
          } else {
            fileInput = visibleOrAny.find(inp => !/image|video/i.test(inp.accept || '') && (inp.accept || '') !== '')
                     || visibleOrAny.find(inp => !(inp.accept || ''))
                     || visibleOrAny[visibleOrAny.length - 1];
          }
          if (!fileInput) await sleep(200);
        }
        if (!fileInput) {
          logAttachStatus('file input not found');
          return { ok:false, reason:'attach input not found' };
        }

        // Inject the file with React-aware setter
        const dt = new DataTransfer();
        dt.items.add(file);
        setReactFiles(fileInput, dt.files);
        fileInput.dispatchEvent(new Event('input',  { bubbles:true }));
        fileInput.dispatchEvent(new Event('change', { bubbles:true }));
      }

      // 5) Wait for the preview overlay
      const overlay = await waitForPreviewOverlay(40);
      if (!overlay) {
        logAttachStatus('preview did not open');
        return { ok:false, reason:'preview overlay did not open' };
      }
      await sleep(600);

      // 6) Type the caption inside the preview's caption editor
      if (captionText && captionText.length) {
        const scope = (overlay instanceof Element ? overlay : document);
        let captionEl = findCaptionInput(scope) || findCaptionInput(document);
        for (let i = 0; i < 10 && !captionEl; i++) {
          await sleep(250);
          captionEl = findCaptionInput(scope) || findCaptionInput(document);
        }
        if (captionEl) {
          await typeMessage(captionEl, captionText);
          await sleep(300);
        }
      }

      // 7) Click the Send button INSIDE the preview overlay
      let sendBtn = null;
      const scopeForSend = (overlay instanceof Element ? overlay : document);
      const sendSels = [
        'div[role="button"][aria-label="Send" i]',
        'button[aria-label="Send" i]',
        'div[role="button"][aria-label*="Send" i]',
        'button[aria-label*="Send" i]',
        'span[data-icon="wds-ic-send-filled"]',
        'span[data-icon="send"]',
      ];
      for (let i = 0; i < 16 && !sendBtn; i++) {
        for (const sel of sendSels) {
          const el = scopeForSend.querySelector(sel) || document.querySelector(sel);
          if (el && isVisible(el)) { sendBtn = el.closest('button, div[role="button"]') || el; break; }
        }
        if (!sendBtn) await sleep(250);
      }
      if (!sendBtn) {
        logAttachStatus('send button missing');
        return { ok:false, reason:'preview send button not found' };
      }
      try { sendBtn.click(); } catch(_) { clickElement(sendBtn); }

      // 8) Wait until the preview overlay closes (i.e., upload kicked off)
      await waitForPreviewClosed(40);
      await sleep(1500);
      logAttachStatus('sent ✓');
      return { ok:true };
    } catch (e) {
      logAttachStatus('error: ' + (e.message || 'unknown'));
      return { ok:false, reason: e.message || 'attach error' };
    }
  }

  async function sendMessage({ phone, text, typingMs = 1500, attachDataUrl = null, attachMeta = null }) {
    try {
      if (!isLoggedIn()) return { success:false, reason:'Not logged in' };
      const nav = await navigateToChat(phone);
      if (!nav.ok) return { success:false, reason:nav.reason || 'Could not open chat' };
      const w = await waitForChatInput(60);
      if (!w.ok) return { success:false, reason:w.reason };
      let input = w.el;

      // typing simulation
      const typeDelay = Math.max(400, Math.floor(typingMs));
      await sleep(typeDelay);

      if (checkInvalidModal()) return { success:false, reason:'Not on WhatsApp' };

      // ── Path 1: attachment + (optional) caption — handled entirely inside attachFileToChat
      if (attachDataUrl && attachMeta) {
        const a = await attachFileToChat(attachDataUrl, attachMeta, text || '');
        if (!a.ok) return { success:false, reason: a.reason || 'attach failed' };
        await sleep(1500);
        try {
          document.body.dispatchEvent(new KeyboardEvent('keydown', {
            key:'Escape', code:'Escape', keyCode:27, which:27, bubbles:true
          }));
        } catch(_){}
        return { success:true };
      }

      // ── Path 2: plain text message
      await typeMessage(input, text);
      await sleep(300);
      if (checkInvalidModal()) return { success:false, reason:'Not on WhatsApp' };
      const ok = await clickSend(input);
      if (!ok) return { success:false, reason:'Send button not found' };
      await sleep(1800);
      try {
        document.body.dispatchEvent(new KeyboardEvent('keydown', {
          key:'Escape', code:'Escape', keyCode:27, which:27, bubbles:true
        }));
      } catch(_){}
      return { success:true };
    } catch (e) {
      return { success:false, reason: e.message || 'send error' };
    }
  }

  // ── Always Online & Auto-Read (best-effort, MAIN-world via injected script) ──
  function injectMainWorldHelper() {
    if (document.getElementById('lhp-wa-main')) return;
    const s = document.createElement('script');
    s.id = 'lhp-wa-main';
    s.textContent = `
      (function(){
        if (window.__LHP_MAIN__) return;
        window.__LHP_MAIN__ = true;
        window.__lhpKeepOnline = function(){
          try {
            const Store = window.Store;
            if (Store && Store.PresenceUtils && Store.PresenceUtils.sendPresenceAvailable) {
              Store.PresenceUtils.sendPresenceAvailable();
            } else if (Store && Store.Presence && Store.Presence.sendPresenceAvailable) {
              Store.Presence.sendPresenceAvailable();
            }
          } catch(e){}
        };
        window.__lhpMarkRead = function(){
          try {
            const Store = window.Store;
            if (!Store || !Store.Chat) return;
            const chats = Store.Chat.getModelsArray ? Store.Chat.getModelsArray() : [];
            chats.forEach(c => { if (c.unreadCount > 0) { try { Store.SendSeen?.sendSeen?.(c, false); } catch(e){} } });
          } catch(e){}
        };
      })();
    `;
    (document.head || document.documentElement).appendChild(s);
  }

  let onlineTimer = null;
  let readTimer = null;
  function setAlwaysOnline(on) {
    if (onlineTimer) { clearInterval(onlineTimer); onlineTimer = null; }
    if (!on) return;
    injectMainWorldHelper();
    const ping = () => {
      const s = document.createElement('script');
      s.textContent = 'try{window.__lhpKeepOnline && window.__lhpKeepOnline();}catch(e){}';
      document.documentElement.appendChild(s); s.remove();
    };
    ping();
    onlineTimer = setInterval(ping, 20000);
  }
  function setAutoRead(on) {
    if (readTimer) { clearInterval(readTimer); readTimer = null; }
    if (!on) return;
    injectMainWorldHelper();
    const tick = () => {
      const s = document.createElement('script');
      s.textContent = 'try{window.__lhpMarkRead && window.__lhpMarkRead();}catch(e){}';
      document.documentElement.appendChild(s); s.remove();
    };
    tick();
    readTimer = setInterval(tick, 8000);
  }

  // Restore toggles from storage
  chrome.storage.local.get(['waAlwaysOnline','waAutoRead'], d => {
    if (d.waAlwaysOnline) setAlwaysOnline(true);
    if (d.waAutoRead)     setAutoRead(true);
  });
  chrome.storage.onChanged.addListener((chg, area) => {
    if (area !== 'local') return;
    if ('waAlwaysOnline' in chg) setAlwaysOnline(!!chg.waAlwaysOnline.newValue);
    if ('waAutoRead'     in chg) setAutoRead(!!chg.waAutoRead.newValue);
  });

  // ── Boot ─────────────────────────────────────────────────────
  function extAlive() {
    try { return !!(chrome && chrome.runtime && chrome.runtime.id); } catch(_) { return false; }
  }
  function boot() {
    injectBadge();
    let timer = null;
    const update = () => {
      if (!extAlive()) {
        if (timer) { clearInterval(timer); timer = null; }
        return;
      }
      const ready = isLoggedIn();
      setBadge(ready ? '✓ Connected' : 'Please log in');
      try {
        const p = chrome.runtime.sendMessage({
          action: 'WA_STATUS_PUSH', ready, url: location.href
        });
        if (p && typeof p.catch === 'function') p.catch(() => {});
      } catch (_) {
        if (timer) { clearInterval(timer); timer = null; }
      }
    };
    update();
    timer = setInterval(update, 5000);
  }

  // ── Message router from background ────────────────────────────
  chrome.runtime.onMessage.addListener((msg, sender, reply) => {
    if (!msg || !msg.action) return;
    switch (msg.action) {
      case 'WA_CHECK_READY':
        try { reply({ ready: isLoggedIn(), url: location.href }); } catch(_){}
        return true;
      case 'WA_SEND_MESSAGE':
        sendMessage({ phone: msg.phone, text: msg.text, typingMs: msg.typingMs, attachDataUrl: msg.attachDataUrl || null, attachMeta: msg.attachMeta || null })
          .then((res) => {
            // Always write result to storage so background gets it even
            // if the message channel has closed (tab reload, SPA nav, etc.)
            if (msg.jobId) {
              try {
                chrome.storage.local.set({
                  ['waJobResult_' + msg.jobId]: {
                    success: !!res.success,
                    reason:  res.reason || null,
                    ts: Date.now()
                  }
                });
              } catch(_){}
            }
            try { reply(res); } catch(_){}
          })
          .catch((err) => {
            const res = { success:false, reason: (err && err.message) || 'send error' };
            if (msg.jobId) {
              try {
                chrome.storage.local.set({
                  ['waJobResult_' + msg.jobId]: { ...res, ts: Date.now() }
                });
              } catch(_){}
            }
            try { reply(res); } catch(_){}
          });
        return true;
      case 'WA_SET_ALWAYS_ONLINE':
        setAlwaysOnline(!!msg.enabled); reply({ ok:true }); return;
      case 'WA_SET_AUTO_READ':
        setAutoRead(!!msg.enabled); reply({ ok:true }); return;
    }
  });

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
