// ════════════════════════════════════════════════════════════════
// LEAD HUNTER PRO — Floating Campaign Progress Panel
// Injected on any tab via chrome.scripting.executeScript when a
// campaign starts. Sticky, draggable, minimizable, persistent.
// Reads live stats from chrome.storage.local (set by background
// startCampaignLoop). Survives popup close.
// ════════════════════════════════════════════════════════════════
(() => {
  'use strict';
  if (window.__LHP_PANEL_INJECTED__) {
    // Already injected — just ensure visible
    const ex = document.getElementById('lhp-campaign-panel');
    if (ex) ex.style.display = '';
    return;
  }
  window.__LHP_PANEL_INJECTED__ = true;

  const ID = 'lhp-campaign-panel';

  // ── DOM ──────────────────────────────────────────────────────
  const wrap = document.createElement('div');
  wrap.id = ID;
  wrap.setAttribute('data-lhp', '1');
  wrap.style.cssText = `
    all: initial;
    position: fixed; z-index: 2147483647;
    top: 80px; right: 24px;
    width: 320px; max-width: 92vw;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    color: #fff;
  `;

  wrap.innerHTML = `
    <style>
      #${ID} * { box-sizing: border-box; font-family: inherit; }
      #${ID} .lhp-card {
        background: linear-gradient(160deg,#1a1f2e,#0f1320);
        border: 1px solid rgba(255,140,0,.45);
        border-radius: 14px;
        box-shadow: 0 24px 60px rgba(0,0,0,.55), 0 0 0 1px rgba(255,140,0,.08);
        overflow: hidden;
      }
      #${ID} .lhp-head {
        display:flex; align-items:center; gap:10px;
        padding: 11px 13px;
        cursor: move; user-select: none;
        background: linear-gradient(90deg, rgba(255,140,0,.15), transparent);
        border-bottom: 1px solid rgba(255,255,255,.06);
      }
      #${ID} .lhp-icon {
        width: 30px; height: 30px; border-radius: 50%;
        background: linear-gradient(135deg,#25d366,#128c7e);
        display:flex; align-items:center; justify-content:center;
        font-size: 16px;
      }
      #${ID} .lhp-title { font-weight:800; font-size:12px; }
      #${ID} .lhp-sub   { font-size:10px; color: rgba(255,255,255,.55); }
      #${ID} .lhp-body  { padding: 13px; }
      #${ID} .lhp-bar   {
        height:8px; background:#0a0d14; border-radius:5px; overflow:hidden;
        margin-bottom: 12px;
      }
      #${ID} .lhp-fill  {
        height:100%; width:0%;
        background: linear-gradient(90deg, #25d366, #ff8c00);
        transition: width .35s ease;
      }
      #${ID} .lhp-grid  {
        display:grid; grid-template-columns:repeat(3,1fr);
        gap:7px; margin-bottom:11px;
      }
      #${ID} .lhp-stat {
        text-align:center; padding:8px 4px; border-radius:8px;
      }
      #${ID} .lhp-stat .n { font-size:17px; font-weight:800; }
      #${ID} .lhp-stat .l { font-size:9px; text-transform:uppercase; color: rgba(255,255,255,.55); margin-top:2px; }
      #${ID} .lhp-s-ok  { background: rgba(37,211,102,.10); border:1px solid rgba(37,211,102,.30); }
      #${ID} .lhp-s-ok .n  { color:#25d366; }
      #${ID} .lhp-s-er  { background: rgba(255,80,80,.10); border:1px solid rgba(255,80,80,.30); }
      #${ID} .lhp-s-er .n  { color:#ff5050; }
      #${ID} .lhp-s-pn  { background: rgba(255,140,0,.10); border:1px solid rgba(255,140,0,.30); }
      #${ID} .lhp-s-pn .n  { color:#ff8c00; }
      #${ID} .lhp-now {
        font-size:11px; padding:8px 10px;
        background:#0a0d14; border:1px solid rgba(255,255,255,.06);
        border-radius:8px; min-height:32px; line-height:1.4;
        color: rgba(255,255,255,.75);
        word-break: break-word;
        margin-bottom: 11px;
      }
      #${ID} .lhp-actions { display:flex; gap:6px; }
      #${ID} button {
        flex:1; padding:9px 10px; border-radius:8px; border:none;
        font-weight:700; font-size:11px; cursor:pointer;
      }
      #${ID} .lhp-btn-stop  { background:#ff5050; color:#fff; }
      #${ID} .lhp-btn-pause { background:#ff8c00; color:#000; }
      #${ID} .lhp-btn-min   { background:transparent; color:#fff; border:1px solid rgba(255,255,255,.18); flex:0 0 auto; padding:9px 12px; }
      #${ID} .lhp-pill {
        display:none; align-items:center; gap:8px;
        padding:8px 14px; border-radius:30px;
        background: linear-gradient(135deg,#128c7e,#25d366);
        color:#fff; font-size:11px; font-weight:700;
        cursor: move; user-select:none;
        box-shadow: 0 8px 20px rgba(0,0,0,.4);
      }
      #${ID}.minimized .lhp-card { display:none; }
      #${ID}.minimized .lhp-pill { display:flex; }
      #${ID} .lhp-dot {
        width:8px; height:8px; border-radius:50%;
        background:#fff; animation: lhp-pulse 1.4s infinite;
      }
      @keyframes lhp-pulse { 0%,100%{opacity:1} 50%{opacity:.35} }
    </style>

    <div class="lhp-card">
      <div class="lhp-head" id="lhp-drag">
        <div class="lhp-icon">🚀</div>
        <div style="flex:1; min-width:0;">
          <div class="lhp-title" id="lhp-title">Lead Hunter — Campaign</div>
          <div class="lhp-sub"   id="lhp-sub">Preparing…</div>
        </div>
        <div style="font-size:11px; font-weight:800; color:#ff8c00;" id="lhp-pct">0%</div>
        <button id="lhp-close" title="Close panel"
          style="background:transparent; border:1px solid rgba(255,255,255,.25);
                 border-radius:50%; width:22px; height:22px; color:rgba(255,255,255,.7);
                 font-size:13px; font-weight:700; cursor:pointer; display:flex;
                 align-items:center; justify-content:center; line-height:1;
                 padding:0; flex-shrink:0; margin-left:4px;">✕</button>
      </div>
      <div class="lhp-body">
        <div class="lhp-bar"><div class="lhp-fill" id="lhp-fill"></div></div>
        <div class="lhp-grid">
          <div class="lhp-stat lhp-s-ok"><div class="n" id="lhp-sent">0</div><div class="l">Sent</div></div>
          <div class="lhp-stat lhp-s-er"><div class="n" id="lhp-fail">0</div><div class="l">Failed</div></div>
          <div class="lhp-stat lhp-s-pn"><div class="n" id="lhp-pend">0</div><div class="l">Pending</div></div>
        </div>

        <!-- Channel breakdown rows (visible only when both channels active) -->
        <div id="lhp-wa-row" style="display:none; margin-bottom:8px;
          background:rgba(37,211,102,.07); border:1px solid rgba(37,211,102,.25);
          border-radius:9px; padding:8px 12px;">
          <div style="font-size:10px; color:rgba(37,211,102,.8); font-weight:700; margin-bottom:5px;">📱 WhatsApp</div>
          <div style="display:flex; gap:12px;">
            <div style="text-align:center; flex:1;">
              <div id="lhp-wa-sent" style="font-size:16px; font-weight:800; color:#25d366;">0</div>
              <div style="font-size:9px; color:rgba(255,255,255,.5); text-transform:uppercase; margin-top:1px;">Sent</div>
            </div>
            <div style="width:1px; background:rgba(255,255,255,.08);"></div>
            <div style="text-align:center; flex:1;">
              <div id="lhp-wa-fail" style="font-size:16px; font-weight:800; color:#ff5050;">0</div>
              <div style="font-size:9px; color:rgba(255,255,255,.5); text-transform:uppercase; margin-top:1px;">Failed</div>
            </div>
          </div>
        </div>

        <div id="lhp-em-row" style="display:none; margin-bottom:8px;
          background:rgba(66,133,244,.07); border:1px solid rgba(66,133,244,.25);
          border-radius:9px; padding:8px 12px;">
          <div style="font-size:10px; color:rgba(66,133,244,.9); font-weight:700; margin-bottom:5px;">📧 Email</div>
          <div style="display:flex; gap:12px;">
            <div style="text-align:center; flex:1;">
              <div id="lhp-em-sent" style="font-size:16px; font-weight:800; color:#4285f4;">0</div>
              <div style="font-size:9px; color:rgba(255,255,255,.5); text-transform:uppercase; margin-top:1px;">Sent</div>
            </div>
            <div style="width:1px; background:rgba(255,255,255,.08);"></div>
            <div style="text-align:center; flex:1;">
              <div id="lhp-em-fail" style="font-size:16px; font-weight:800; color:#ff5050;">0</div>
              <div style="font-size:9px; color:rgba(255,255,255,.5); text-transform:uppercase; margin-top:1px;">Failed</div>
            </div>
          </div>
        </div>
        <div class="lhp-now" id="lhp-now"><span style="color:#ff8c00">●</span> Starting queue…</div>
        <div class="lhp-actions">
          <button class="lhp-btn-stop"  id="lhp-stop">⏹ Stop</button>
          <button class="lhp-btn-min"   id="lhp-min" title="Minimize">—</button>
          <button class="lhp-btn-close" id="lhp-close-action" title="Close panel"
            style="background:rgba(255,255,255,.08); color:rgba(255,255,255,.7);
                   border:1px solid rgba(255,255,255,.2); flex:0 0 auto; padding:9px 12px;">✕</button>
        </div>
      </div>
    </div>
    <div class="lhp-pill" id="lhp-pill">
      <span class="lhp-dot"></span>
      <span id="lhp-pill-txt">Campaign 0%</span>
    </div>
  `;
  document.documentElement.appendChild(wrap);

  // ── Drag (head + pill) with persisted position ───────────────
  function makeDraggable(handle) {
    let sx=0, sy=0, ox=0, oy=0, dragging=false, moved=false;
    handle.addEventListener('mousedown', (e) => {
      dragging = true; moved = false;
      const r = wrap.getBoundingClientRect();
      wrap.style.left = r.left + 'px';
      wrap.style.top  = r.top  + 'px';
      wrap.style.right = 'auto';
      sx=e.clientX; sy=e.clientY; ox=r.left; oy=r.top;
      e.preventDefault();
    });
    window.addEventListener('mousemove', (e) => {
      if (!dragging) return;
      moved = true;
      const w = wrap.offsetWidth, h = wrap.offsetHeight;
      let nx = ox + (e.clientX - sx);
      let ny = oy + (e.clientY - sy);
      nx = Math.max(0, Math.min(window.innerWidth  - w, nx));
      ny = Math.max(0, Math.min(window.innerHeight - h, ny));
      wrap.style.left = nx + 'px';
      wrap.style.top  = ny + 'px';
    });
    window.addEventListener('mouseup', () => {
      if (!dragging) return;
      dragging = false;
      if (moved) {
        try {
          chrome.storage.local.set({
            lhpPanelPos: { left: wrap.style.left, top: wrap.style.top }
          });
        } catch(e){}
      }
    });
  }
  makeDraggable(document.getElementById('lhp-drag'));
  makeDraggable(document.getElementById('lhp-pill'));

  // Restore position
  try {
    chrome.storage.local.get(['lhpPanelPos','lhpPanelMin'], (d) => {
      if (d.lhpPanelPos && d.lhpPanelPos.left) {
        wrap.style.left = d.lhpPanelPos.left;
        wrap.style.top  = d.lhpPanelPos.top;
        wrap.style.right = 'auto';
      }
      if (d.lhpPanelMin) wrap.classList.add('minimized');
    });
  } catch(e){}

  // Pill toggle (click → restore). Use mouseup so drag doesn't toggle.
  document.getElementById('lhp-pill').addEventListener('click', (e) => {
    wrap.classList.remove('minimized');
    try { chrome.storage.local.set({ lhpPanelMin:false }); } catch(_){}
  });
  document.getElementById('lhp-min').addEventListener('click', () => {
    wrap.classList.add('minimized');
    try { chrome.storage.local.set({ lhpPanelMin:true }); } catch(_){}
  });
  document.getElementById('lhp-stop').addEventListener('click', () => {
    if (!confirm('Stop the running campaign?')) return;
    try { chrome.runtime.sendMessage({ action: 'stopCampaign' }); } catch(e){}
    document.getElementById('lhp-now').innerHTML =
      '<span style="color:#ff5050">⏹</span> Stopping…';
  });

  // ── Close button (header ✕) — dismiss panel without stopping campaign
  const closeBtn = document.getElementById('lhp-close');
  if (closeBtn) {
    closeBtn.onclick = () => {
      wrap.style.display = 'none';
      window.__LHP_PANEL_INJECTED__ = false;
    };
  }
  const closeActionBtn = document.getElementById('lhp-close-action');
  if (closeActionBtn) {
    closeActionBtn.onclick = () => {
      wrap.remove();
      window.__LHP_PANEL_INJECTED__ = false;
    };
  }

  // ── Live updates from chrome.storage.local ───────────────────
  const $ = (id) => document.getElementById(id);
  function render(d) {
    const sent  = Number(d.campaignSent  || 0);
    const fail  = Number(d.campaignFail  || 0);
    const pend  = Number(d.campaignPend  || 0);
    const total = sent + fail + pend;
    const done  = sent + fail;
    const pct   = total ? Math.min(100, Math.round((done/total)*100)) : 0;
    $('lhp-sent').textContent = sent;
    $('lhp-fail').textContent = fail;
    $('lhp-pend').textContent = pend;
    $('lhp-pct').textContent  = pct + '%';
    $('lhp-fill').style.width = pct + '%';
    $('lhp-pill-txt').textContent = `Campaign ${pct}% · ${sent}✓ ${fail}✗`;

    // Channel breakdown — show two boxes when both channels active
    const channels = d.campaignChannels || { wa:false, em:false };
    const bothActive = !!(channels.wa && channels.em);
    const waRow = document.getElementById('lhp-wa-row');
    const emRow = document.getElementById('lhp-em-row');
    if (bothActive) {
      if (waRow) {
        waRow.style.display = '';
        document.getElementById('lhp-wa-sent').textContent = Number(d.campaignWaSent || 0);
        document.getElementById('lhp-wa-fail').textContent = Number(d.campaignWaFail || 0);
      }
      if (emRow) {
        emRow.style.display = '';
        document.getElementById('lhp-em-sent').textContent = Number(d.campaignEmSent || 0);
        document.getElementById('lhp-em-fail').textContent = Number(d.campaignEmFail || 0);
      }
    } else {
      if (waRow) waRow.style.display = 'none';
      if (emRow) emRow.style.display = 'none';
    }

    if (d.campaignLastLog) {
      $('lhp-now').innerHTML = '<span style="color:#ff8c00">●</span> ' +
        String(d.campaignLastLog).replace(/[<>]/g,'');
    }
    if (total > 0 && pend === 0) {
      $('lhp-sub').textContent = 'Completed';
      $('lhp-now').innerHTML = '<span style="color:#25d366">✓</span> Campaign finished — ' +
        sent + ' sent, ' + fail + ' failed.';
      $('lhp-stop').textContent = '✓ Close';
      $('lhp-stop').onclick = () => { wrap.remove(); window.__LHP_PANEL_INJECTED__ = false; };
    } else if (total > 0) {
      $('lhp-sub').textContent = `Sending ${done} / ${total}`;
    }
  }

  try {
    const KEYS = ['campaignSent','campaignFail','campaignPend','campaignLastLog',
      'campaignWaSent','campaignWaFail','campaignEmSent','campaignEmFail','campaignChannels'];
    chrome.storage.local.get(KEYS, render);
    chrome.storage.onChanged.addListener((chg, area) => {
      if (area !== 'local') return;
      if (KEYS.some(k => k in chg)) {
        chrome.storage.local.get(KEYS, render);
      }
    });
  } catch(e){}

  // Allow background to push title/subtitle
  try {
    chrome.runtime.onMessage.addListener((msg) => {
      if (!msg) return;
      if (msg.action === 'LHP_PANEL_META') {
        if (msg.title) $('lhp-title').textContent = msg.title;
        if (msg.sub)   $('lhp-sub').textContent   = msg.sub;
      }
      if (msg.action === 'LHP_PANEL_HIDE') {
        wrap.remove(); window.__LHP_PANEL_INJECTED__ = false;
      }
    });
  } catch(e){}
})();
